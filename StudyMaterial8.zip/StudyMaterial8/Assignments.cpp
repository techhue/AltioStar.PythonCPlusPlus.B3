

DAY 04 : ASSIGNMENTS
________________________________________________________________

1. Reading Assignments

	|-- StudyMaterial4
    
	    Reading Assignment I 							[ MUST ]
			
			The C Programming Language, 2nd Edition
				By Brian Kernigham and Dennis Ritchie
			
			Study Following Chapters
			
			1. Chapter 4 : Functions And Program Structure
			2. Chapter 5 : Pointers And Arrays
			3. Chapter 6 : Structures

			Experiment Code Examples In Book

	    Reading Assignment II 							[ MUST ]
			Thinking In C++, Volume I, 2nd Edition
				By Bruce Eckel

			Study Following Chapters
			
			1. Chapter 2: Making And Using Objects

			Experiment Code Examples In Book

2.  Experiment And Revise Code Examples
    
    |-- StudyMaterial4
	    |-- CPlusPlusCode
	    |   |-- 02.GetttingStartedC++.cpp
	    |   |-- Assignments.cpp
	    |   |-- Hello.c
	    |   |-- Hello.cpp
	    |   |-- SomeData.txt
	    |   `-- SomeDataDuplicate.txt
	    `-- References
	        `-- ThinkingInC++.V1.2E.pdf


DAY 05 : ASSIGNMENTS
________________________________________________________________

1. Reading Assignments

    |-- StudyMaterial5       

	    Reading Assignment III 							[ MUST ]
			
			The C Programming Language, 2nd Edition
				By Brian Kernigham and Dennis Ritchie
			
			Study Following Chapters
			
			1. Chapter 4 : Functions And Program Structure
			2. Chapter 5 : Pointers And Arrays
			3. Chapter 6 : Structures

			Experiment Code Examples In Book

	    Reading Assignment IV 							[ MUST ]
			Thinking In C++, Volume I, 2nd Edition
				By Bruce Eckel

			Study Following Chapters
			
			1. Chapter 2: Making And Using Objects
			2. Chapter 3: The C In C++
			3. Chapter 4: Data Abstraction

			Experiment Code Examples In Book


2.  Experiment, Revise Code and Practice Examples
    
    |-- StudyMaterial5

		|-- 02.GetttingStartedC++.cpp
		|-- 03.CandC++AllCodeSamples.cpp
		|-- 03.CandC++Relationship.cpp
		|-- 04.DataAbstractions.cpp
		|-- Assignments.cpp
		|-- Hello.c
		|-- Hello.cpp
		|-- SomeData.txt
		|-- SomeDataDuplicate.txt
		|-- Sum.c
		|-- Sum.c~
		|-- SumSubmitted.c
		|-- WhatIsDataType.txt
		|-- commandLineArgs.cpp
		|-- printBinary.cpp
		|-- printBinary.h
		|-- require.h
		`-- wordsList.txt


DAY 06 : ASSIGNMENTS
________________________________________________________________


1. Reading Assignments

    |-- StudyMaterial6       

    Reading Assignment V 							[ MUST ]
		Thinking In C++, Volume I, 2nd Edition
			By Bruce Eckel

		Study Following Chapters
		
		1. Chapter 4: Data Abstraction
		2. Chapter 5: Hiding The Implementation
		3. Chapter 6: Intialisation And Cleanup
		4. Chapter 7: Function Overloading And Default Arguments

		Experiment Code Examples In Book


2.  Experiment, Revise Code and Practice Examples
    
    |-- StudyMaterial6

		|-- CPP02
		|   |-- Borland.makefile
		|   |-- CallHello.cpp
		|   |-- Concat.cpp
		|   |-- Declare.cpp
		|   |-- FillString.cpp
		|   |-- Fillvector.cpp
		|   |-- GetWords.cpp
		|   |-- Hello.cpp
		|   |-- HelloStrings.cpp
		|   |-- Intvector.cpp
		|   |-- Microsoft.makefile
		|   |-- Numconv.cpp
		|   |-- Scopy.cpp
		|   |-- Stream2.cpp
		|   |-- all.makefile
		|   `-- gcc.makefile

		|-- CPP03
		|   |-- AllDefinitions.cpp
		|   |-- ArgsToInts.cpp
		|   |-- ArrayAddresses.cpp
		|   |-- ArrayArguments.cpp
		|   |-- ArrayIdentifier.cpp
		|   |-- Arrays.cpp
		|   |-- Assert.cpp
		|   |-- AutoIncrement.cpp
		|   |-- Basic.cpp
		|   |-- Bitwise.cpp
		|   |-- Boolean.cpp
		|   |-- Borland.makefile
		|   |-- CastFromVoidPointer.cpp
		|   |-- CatsInHats.cpp
		|   |-- Charlist.cpp
		|   |-- CommaOperator.cpp
		|   |-- CommandLineArgs.cpp
		|   |-- ComplicatedDefinitions.cpp
		|   |-- DynamicDebugFlags.cpp
		|   |-- Enum.cpp
		|   |-- FileStatic.cpp
		|   |-- FileStatic2.cpp
		|   |-- FloatingAsBinary.cpp
		|   |-- Forward.cpp
		|   |-- FunctionCallCast.cpp
		|   |-- FunctionTable.cpp
		|   |-- Global.cpp
		|   |-- Global2.cpp
		|   |-- Guess.cpp
		|   |-- Guess2.cpp
		|   |-- Ifthen.cpp
		|   |-- Mathops.cpp
		|   |-- Menu.cpp
		|   |-- Menu2.cpp
		|   |-- Microsoft.makefile
		|   |-- OnTheFly.cpp
		|   |-- PassAddress.cpp
		|   |-- PassByValue.cpp
		|   |-- PassReference.cpp
		|   |-- Pitfall.cpp
		|   |-- PointerArithmetic.cpp
		|   |-- PointerIncrement.cpp
		|   |-- PointerIncrement2.cpp
		|   |-- PointerToFunction.cpp
		|   |-- PointersAndBrackets.cpp
		|   |-- Return.cpp
		|   |-- Rotation.cpp
		|   |-- Scope.cpp
		|   |-- SelfReferential.cpp
		|   |-- SimpleCast.cpp
		|   |-- SimpleStruct.cpp
		|   |-- SimpleStruct2.cpp
		|   |-- SimpleStruct3.cpp
		|   |-- Specify.cpp
		|   |-- Static.cpp
		|   |-- StringizingExpressions.cpp
		|   |-- StructArray.cpp
		|   |-- Union.cpp
		|   |-- VoidPointer.cpp
		|   |-- YourPets1.cpp
		|   |-- YourPets2.cpp
		|   |-- all.makefile
		|   |-- const_cast.cpp
		|   |-- gcc.makefile
		|   |-- gotoKeyword.cpp
		|   |-- printBinary.cpp
		|   |-- printBinary.h
		|   |-- reinterpret_cast.cpp
		|   |-- sizeof.cpp
		|   |-- sizeofOperator.cpp
		|   `-- static_cast.cpp
		|-- CPP04
		|   |-- Borland.makefile
		|   |-- CLib.cpp
		|   |-- CLib.h
		|   |-- CLibTest.cpp
		|   |-- CppLib.cpp
		|   |-- CppLib.h
		|   |-- CppLibTest.cpp
		|   |-- Microsoft.makefile
		|   |-- Scoperes.cpp
		|   |-- Simple.h
		|   |-- Sizeof.cpp
		|   |-- Stack.cpp
		|   |-- Stack.h
		|   |-- StackTest.cpp
		|   |-- all.makefile
		|   `-- gcc.makefile
		|-- CPP05
		|   |-- Borland.makefile
		|   |-- Class.cpp
		|   |-- Friend.cpp
		|   |-- Handle.cpp
		|   |-- Handle.h
		|   |-- Microsoft.makefile
		|   |-- NestFriend.cpp
		|   |-- Private.cpp
		|   |-- Public.cpp
		|   |-- Stack2.h
		|   |-- Stash.h
		|   |-- UseHandle.cpp
		|   |-- all.makefile
		|   `-- gcc.makefile
		|-- CPP06
		|   |-- AutoDefaultConstructor.cpp
		|   |-- Borland.makefile
		|   |-- Constructor1.cpp
		|   |-- DefineInitialize.cpp
		|   |-- Microsoft.makefile
		|   |-- Multiarg.cpp
		|   |-- Nojump.cpp
		|   |-- Stack3.cpp
		|   |-- Stack3.h
		|   |-- Stack3Test.cpp
		|   |-- Stash2.cpp
		|   |-- Stash2.h
		|   |-- Stash2Test.cpp
		|   |-- all.makefile
		|   `-- gcc.makefile
		|-- CPP07
		|   |-- AnonymousUnion.cpp
		|   |-- Borland.makefile
		|   |-- Def.cpp
		|   |-- Mem.cpp
		|   |-- Mem.h
		|   |-- Mem2.h
		|   |-- MemTest.cpp
		|   |-- Microsoft.makefile
		|   |-- Stash3.cpp
		|   |-- Stash3.h
		|   |-- Stash3Test.cpp
		|   |-- SuperVar.cpp
		|   |-- UnionClass.cpp
		|   |-- Use.cpp
		|   |-- all.makefile
		|   `-- gcc.makefile
    

3. Revision Assignments

    |-- StudyMaterial6       

	    Reading Assignment III 							[ MUST ]
			
			The C Programming Language, 2nd Edition
				By Brian Kernigham and Dennis Ritchie
			
			Study Following Chapters
			
			1. Chapter 4 : Functions And Program Structure
			2. Chapter 5 : Pointers And Arrays
			3. Chapter 6 : Structures
			4. Chapter 7 : Unions 
			Experiment Code Examples In Book

	    Reading Assignment IV 							[ MUST ]

			Thinking In C++, Volume I, 2nd Edition
				By Bruce Eckel

			Study Following Chapters
			
			1. Chapter 2: Making And Using Objects
			2. Chapter 3: The C In C++
			3. Chapter 4: Data Abstraction

			Experiment Code Examples In Book


DAY 07 : ASSIGNMENTS
________________________________________________________________

1. Reading Assignments

    |-- StudyMaterial8       


	    Reading Assignment VII 							[ MUST ]
			Thinking In C++, Volume I, 2nd Edition
				By Bruce Eckel

			Study Following Chapters
			
			1. Chapter 08: Constants
			2. Chapter 09: Inline Functions
			3. Chapter 10: Name Control

	    Revision Assignment VI 							[ MUST ]
			Thinking In C++, Volume I, 2nd Edition
				By Bruce Eckel

			Study Following Chapters
			
			1. Chapter 4: Data Abstraction
			2. Chapter 5: Hiding The Implementation
			3. Chapter 6: Intialisation And Cleanup
			4. Chapter 7: Function Overloading And Default Arguments

		Experiment Code Examples In Book


2.  Experiment And Revise Code Examples
    
    |-- StudyMaterial8

		|-- CPP08
		|   |-- Borland.makefile
		|   |-- BuiltInTypeConstructors.cpp
		|   |-- Castaway.cpp
		|   |-- ConstInitialization.cpp
		|   |-- ConstMember.cpp
		|   |-- ConstPointer.cpp
		|   |-- ConstPointers.cpp
		|   |-- ConstReturnValues.cpp
		|   |-- ConstTemporary.cpp
		|   |-- Constag.cpp
		|   |-- Constval.cpp
		|   |-- EncapsulatingTypes.cpp
		|   |-- EnumHack.cpp
		|   |-- Microsoft.makefile
		|   |-- Mutable.cpp
		|   |-- PointerAssignment.cpp
		|   |-- Quoter.cpp
		|   |-- Safecons.cpp
		|   |-- StringStack.cpp
		|   |-- Volatile.cpp
		|   |-- all.makefile
		|   `-- gcc.makefile

		|-- CPP09
		|   |-- Access.cpp
		|   |-- Borland.makefile
		|   |-- Cpptime.cpp
		|   |-- Cpptime.h
		|   |-- ErrTest.cpp
		|   |-- EvaluationOrder.cpp
		|   |-- Hidden.cpp
		|   |-- Inline.cpp
		|   |-- MacroSideEffects.cpp
		|   |-- Microsoft.makefile
		|   |-- Noinsitu.cpp
		|   |-- Rectangle.cpp
		|   |-- Rectangle2.cpp
		|   |-- Stack4.h
		|   |-- Stack4Test.cpp
		|   |-- Stash4.cpp
		|   |-- Stash4.h
		|   |-- Stash4Test.cpp
		|   |-- all.makefile
		|   `-- gcc.makefile
		
		|-- CPP10
		|   |-- Arithmetic.cpp
		|   |-- BobsSuperDuperLibrary.cpp
		|   |-- Borland.makefile
		|   |-- Continuation.cpp
		|   |-- Dependency1.h
		|   |-- Dependency1StatFun.cpp
		|   |-- Dependency1StatFun.h
		|   |-- Dependency2.h
		|   |-- Dependency2StatFun.cpp
		|   |-- Dependency2StatFun.h
		|   |-- FriendInjection.cpp
		|   |-- Header1.h
		|   |-- Header2.h
		|   |-- Initializer.cpp
		|   |-- Initializer.h
		|   |-- Initializer2.cpp
		|   |-- InitializerDefs.cpp
		|   |-- Local.cpp
		|   |-- LocalExtern.cpp
		|   |-- LocalExtern2.cpp
		|   |-- Microsoft.makefile
		|   |-- MyLib.cpp
		|   |-- NamespaceInt.h
		|   |-- NamespaceMath.h
		|   |-- NamespaceOverriding1.cpp
		|   |-- NamespaceOverriding2.h
		|   |-- Oof.cpp
		|   |-- Out.cpp
		|   |-- OverridingAmbiguity.cpp
		|   |-- ScopeResolution.cpp
		|   |-- SimpleStaticMemberFunction.cpp
		|   |-- Singleton.cpp
		|   |-- StaticArray.cpp
		|   |-- StaticDestructors.cpp
		|   |-- StaticMemberFunctions.cpp
		|   |-- StaticObjectArrays.cpp
		|   |-- StaticObjectsInFunctions.cpp
		|   |-- StaticVariablesInfunctions.cpp
		|   |-- Statinit.cpp
		|   |-- Technique2.cpp
		|   |-- Technique2b.cpp
		|   |-- UnnamedNamespaces.cpp
		|   |-- UsingDeclaration.h
		|   |-- UsingDeclaration1.cpp
		|   |-- UsingDeclaration2.cpp
		|   |-- all.makefile
		|   `-- gcc.makefile

    

DAY 08 : ASSIGNMENTS
________________________________________________________________

1. Reading Assignments

    |-- StudyMaterial8       

2.  Experiment And Revise Code Examples
    
    |-- StudyMaterial8

3.  Practice Code Examples

    |-- StudyMaterial8
    
