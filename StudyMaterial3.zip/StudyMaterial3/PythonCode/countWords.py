

# EXPERIMENT FOLLOWING CODE BY TYPING LINE BY LINE ON PYTHON SHELL

#   >>>>>>> MOMENT COMPLETED, RAISE YOUR HAND!!!  <<<<<<<<<


# To Run This Program Give Following Command
# python3 countWords.py [SPACE SEPERATED FILE LIST]
# e.g.
# python3 countWords.py wordsList.txt 
# python3 countWords.py wordsList.txt wordsList1.txt 

import string
import sys


# sys.argv Will Gives List Of Command Line Arguments 
print(sys.argv)

# python countWords.py wordsList1.txt
# ['countWords.py', 'wordsList1.txt'] 
#       0 index           1 index

# python countWords.py wordsList1.txt wordsList.txt
# ['countWords.py', 'wordsList1.txt', 'wordsList.txt']
#       0 index           1 index         2 index


# IF I RUN THIS COMMAND
# python countWords.py wordsList1.txt wordsList.txt

fileNames = sys.argv[1:]
wordsCount = {}

for filename in fileNames:
	openedFile = open(filename)
	lines = openedFile.readlines()
	# print("Lines In File Are:")
	# print(lines)
	for line in lines:
		words = line.split() # Split Based On WhiteSpace Characters
		# print("Words In Each Line Are:")
		# print(words)
		for word in words:
			# Removing Leading And Training Whitespace Characters
			word = word.strip() 
			if len(word) >= 2:
				wordsCount[word] = wordsCount.get(word, 0) + 1

for word in sorted(wordsCount):
	print(" '{0}' Occurs {1} Times".format(word, wordsCount[word]))

print(wordsCount)

