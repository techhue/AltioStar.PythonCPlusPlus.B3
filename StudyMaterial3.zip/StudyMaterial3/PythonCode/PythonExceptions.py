
# Following Code Throws Runtime Exception Or Error
def playWithRunTimeError():
  number = 10
  divisor = 0
  result = number/divisor
  print(result)    

def playWithRunTimeErrorAgain():
  fileName = "DingDong.txt"
  inFile = open("DingDong.txt")
  print("Opening File Successful: {0}".format(fileName))


def playWithTryExceptSuccess():
  number = 10
  divisor = 2
  # To Handle Runtime Exceptions Use try-except Construct
  try:
    result = number/divisor
    print(result)    
  except ZeroDivisionError: # Handling Exception ZeroDivisionError
    print("Divisor Value Is: ", divisor)


def playWithTryExceptFailure():
  number = 10
  divisor = 0

  try:   # To Handle Runtime Exceptions Use try-except Construct
    result = number/divisor # Will Throw Exception ZeroDivisionError
    print(result)    
  except ZeroDivisionError: # Handling Exception ZeroDivisionError
    print("Division By Zero Not Allowed - Divisor Value: ", divisor)


def playWithTryExceptSuccessAgain():
  filename = "wordsList.txt"

  try: 
    inFile = open(filename)
    print("Opening File Successful: ", filename)
  except FileNotFoundError:
    print("File Doesn't Exists : ", filename)


def playWithTryExceptFailureAgain():
  filename = "DingDong.txt"

  try:
  
    inFile = open(filename)
    print("Opening File Successful: ", filename)
  
  except FileNotFoundError:
    print("File Doesn't Exists : ", filename)


# print("\nFunction: playWithRunTimeError")
# playWithRunTimeError()

# print("\nFunction: playWithRunTimeErrorAgain")
# playWithRunTimeErrorAgain()

print("\nFunction: playWithTryExceptSuccess")
playWithTryExceptSuccess()

print("\nFunction: playWithTryExceptFailure")
playWithTryExceptFailure()

print("\nFunction: playWithTryExceptSuccessAgain")
playWithTryExceptSuccessAgain()

print("\nFunction: playWithTryExceptFailureAgain")
playWithTryExceptFailureAgain()
