
Python 3.8.10 (default, Sep 28 2021, 16:10:42) 
[GCC 9.3.0] on linux
Type "help", "copyright", "credits" or "license" for more information.

>>> 
>>> 
>>> 
>>> numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
>>> 
>>> squaresSet = set()
>>> for number in numbers:
...     squaresSet.add( number * number )
... 
>>> print(squaresSet)
{64, 1, 4, 36, 100, 9, 16, 49, 81, 25}
>>> 
>>> 
>>> squaresSetAgain = { number * number for number in numbers }
>>> print(squaresSetAgain)
{64, 1, 4, 36, 100, 9, 16, 49, 81, 25}
>>> 
>>> 
>>> 
>>> 
>>> def sum(a, b):
...     return a + b
... 
>>> sum(10, 20)
30
>>> 
>>> sum(100, 20)
120
>>> 
>>> 
>>> sumLambda = lambda x, y: x + y
>>> 
>>> sumLambda(10, 20)
30
>>> sumLambda(100, 20)
120
>>> 
>>> sumLambdaAgain = lambda x = 1, y = 1: x + y
>>> 
>>> sumLambdaAgain()
2
>>> 
>>> squareLambda = lambda x : x * x
>>> 
>>> squareLambda(10)
100
>>> squareLambda(9)
81
>>> 
>>> def square(x):
...     return x * x
... 
>>> square(10)
100
>>> square(9)
81
>>> 
>>> type(square)
<class 'function'>
>>> 
>>> type(squareLambda)
<class 'function'>
>>> 
>>> 
>>> type(square)
<class 'function'>
>>> 
>>> def average(*values):
...     sum = 0
...     for value in values:
...             sum = sum + value
... 
>>> 
>>> values = (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
>>> 
>>> 
>>> sum(values)
55
>>> 
>>> 
>>> sum(values) / len(values)
5.5
>>> 
>>> def chooseStepAgain(forward):
...     # Local Function
...     #               Function Defined Inside A Function
...     # def moveBackward(steps):
...     #       steps = steps - 1
...     #       return steps
...     moveBackward = lambda steps: steps - 1
...     # Local Function
...     # def moveForward(steps):
...     #       steps = steps + 1
...     #       return steps
...     moveForward = lambda steps: steps + 1
...     if(forward == True):
...             return moveForward   # Returning Lambda Expression
...     else:
...             return moveBackward  # Returning Lambda Expression
... 
>>> 
>>> 
>>> doMagic = chooseStepAgain(True)
>>> print ( doMagic(10) ) # 11
11
>>> print ( doMagic(11) ) # 12
12
>>> 
>>> doMagic = chooseStepAgain(False)
>>> print ( doMagic(10) ) # 9
9
>>> print ( doMagic(11) ) # 10
10
>>> 
>>> 
>>> doMagicAgain = chooseStepAgain(True)
>>> 
>>> 
>>> doMagicAgain(90)
91
>>> 
>>> doMagicAgain(91)
92
>>> 
>>> doMagicAgain = chooseStepAgain(False)
>>> 
>>> 
>>> 
>>> 
>>> def chooseStep(forward, changeSteps):
...     moveBackward    = lambda steps: steps - changeSteps()
...     moveForward     = lambda steps: steps + changeSteps()
...     if(forward == True):
...             return moveForward   # Returning Lambda Expression
...     else:
...             return moveBackward  # Returning Lambda Expression
... 
>>> 
>>> 
>>> moveTwoSteps        = lambda : 2
>>> moveThreeSteps      = lambda : 3
>>> 
>>> moveFiveSteps    = lambda : 5
>>> 
>>> doMagic = chooseStep(True, moveTwoSteps)
>>> 
>>> 
>>> doMagic(80)
82
>>> 
>>> doMagic(82)
84
>>> 

#_____________________________________________________________

thon 3.8.10 (default, Sep 28 2021, 16:10:42) 
[GCC 9.3.0] on linux
Type "help", "copyright", "credits" or "license" for more information.
>>> 
>>> 
>>> 
>>> 
>>> def decoratorGift( gift, message ):
...     # Local Function
...     def wrappedGift(): # Gift Wrapper
...             print("Wrapping Gift!") # Decoration
...             gift()
...             print("Decorating Gift")  # Decoration
...             print(message)                  # Decoration
...     return wrappedGift      # Returning Wrapped/Decorated Gift
... 
>>> 
>>> 
>>> def birthdayGift():
...     print("Birthday Gift!!!")
... 
>>> birthdayGift()
Birthday Gift!!!
>>> 
>>> doMagic = decoratorGift( birthdayGift, "Happy Birthay Gabbar Singh" )
>>> 
>>> doMagic(
... 
... 
KeyboardInterrupt
>>> doMagic
<function decoratorGift.<locals>.wrappedGift at 0x7f30ddf2b700>
>>> 
>>> 
>>> doMagic()
Wrapping Gift!
Birthday Gift!!!
Decorating Gift
Happy Birthay Gabbar Singh
>>> 
>>> 
>>> 
>>> birthdayGift = decoratorGift( birthdayGift, "Happy Birthay Gabbar Singh" )
>>> 
>>> birthdayGift
<function decoratorGift.<locals>.wrappedGift at 0x7f30ddf2b790>
>>> 
>>> 
>>> birthdayGift()
Wrapping Gift!
Birthday Gift!!!
Decorating Gift
Happy Birthay Gabbar Singh
>>> 
>>> 
>>> def fourGenerator():
...     x = 0                                    
...     while x < 4:
...         print("Before Yield : Value Of x =", x)
...         yield x                              
...         print("After  Yield : Value Of x =", x)
...         x = x + 1    
... 
>>> 
>>> 
>>> 
>>> fourGen = fourGenerator()
>>> 
>>> fourGen
<generator object fourGenerator at 0x7f30ddf2f890>
>>> 
>>> next(fourGen)
Before Yield : Value Of x = 0
0
>>> 
>>> next(fourGen)
After  Yield : Value Of x = 0
Before Yield : Value Of x = 1
1
>>> next(fourGen)
After  Yield : Value Of x = 1
Before Yield : Value Of x = 2
2
>>> 
>>> next(fourGen)
After  Yield : Value Of x = 2
Before Yield : Value Of x = 3
3
>>> next(fourGen)
After  Yield : Value Of x = 3
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
StopIteration
>>> 
>>> 
>>> 
>>> 
>>> 
>>> quit()

#_____________________________________________________________

#_____________________________________________________________

#_____________________________________________________________

#_____________________________________________________________

#_____________________________________________________________

#_____________________________________________________________

