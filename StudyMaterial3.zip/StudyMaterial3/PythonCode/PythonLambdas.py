
# EXPERIMENT FOLLOWING CODE BY TYPING LINE BY LINE ON PYTHON SHELL

#   >>>>>>> MOMENT COMPLETED, RAISE YOUR HAND!!!  <<<<<<<<<

def sum(a, b):
	return a + b

def sub(a, b):
	return a - b

def mul(a, b):
	return a * b 

# Higher Order Functions
# 		Functions Which Takes Functions As Argumentt
# Hence calculator is Higher Order Function
def calculator(a, b, operation):
	return operation(a, b)

# Passing Function sum As Argument To calculator Function
result = calculator(30, 20, sum)
print(result) # 50

# Passing Function sub As Argument To calculator Function
result = calculator(30, 20, sub)
print(result) # 10

# Passing Function mul As Argument To calculator Function
result = calculator(30, 20, mul)
print(result) # 600

#____________________________________________________________
#
# Lambda Expressions Also Called Anonymous Functions
#____________________________________________________________


def sum(a, b):
    return a + b

print( sum(10, 20) )  # 30

# Above sum Function Can Be Written Using Lambda Expression
sumLambda = lambda x, y: x + y
print( sumLambda(10, 20) )  # 30

def square(a):
    return a * a

square(4) # 16
square(8) # 64

# Above square Function Can Be Written Using Lambda Expression
squareLambda = lambda x: x * x
print( squareLambda(4) ) # 16
print( squareLambda(8) ) # 64


sumLambda = lambda x, y: x + y
subLambda = lambda x, y: x - y
mulLambda = lambda x, y: x * y

# Higher Order Functions
# 		Functions Which Takes Functions/Lambdas As Argumentt
# Hence calculator is Higher Order Function
def calculator(a, b, operation):
	return operation(a, b)

# Passing Lambda Expression sumLamdba 
# As Argument To calculator Function
result = calculator(30, 20, sumLambda)
print(result) # 50

# Passing Lambda Expression subLamdba 
# As Argument To calculator Function
result = calculator(30, 20, subLambda)
print(result) # 10

# Passing Lambda Expression mulLambda 
# As Argument To calculator Function
result = calculator(30, 20, mulLambda)
print(result) # 600

#____________________________________________________________


squareLambda = lambda x : x * x 
cubeLambda   = lambda x : x * x * x
powerLambda  = lambda x, y: x ** y

print( squareLambda(10) )
print( squareLambda(25) )
print( cubeLambda(10) )
print( cubeLambda(9) )

print( powerLambda(9, 2) )
print( powerLambda(2, 10) )

#____________________________________________________________


#_________________________________________________
# Higher Order Functions
# 		Functions Which Can Return Function
# Hence chooseStep is Higher Order Function
#_________________________________________________

def chooseStepAgain(forward):
	# Local Function
	#		Function Defined Inside A Function	
	# def moveBackward(steps):
	# 	steps = steps - 1
	# 	return steps

	moveBackward = lambda steps: steps - 1
	# Local Function
	# def moveForward(steps):
	# 	steps = steps + 1
	# 	return steps
	
	moveForward = lambda steps: steps + 1
	
	if(forward == True):
		return moveForward   # Returning Lambda Expression
	else:
		return moveBackward  # Returning Lambda Expression

doMagic = chooseStepAgain(True)
print ( doMagic(10) ) # 11
print ( doMagic(11) ) # 12

doMagic = chooseStepAgain(False)
print ( doMagic(10) ) # 9
print ( doMagic(11) ) # 10


#_________________________________________________
# Higher Order Functions
#		Functions Takes Function As Argument And Retuns Function
#_________________________________________________

def chooseStep(forward, changeSteps):
	moveBackward 	= lambda steps: steps - changeSteps()
	moveForward 	= lambda steps: steps + changeSteps()
	if(forward == True):
		return moveForward   # Returning Lambda Expression
	else:
		return moveBackward  # Returning Lambda Expression

moveTwoSteps 	= lambda : 2
moveThreeSteps 	= lambda : 3
moveFiveSteps	= lambda : 5

doMagic = chooseStep(True, moveTwoSteps)
print ( doMagic(10) ) 
print ( doMagic(11) ) 

doMagic = chooseStep(True, moveThreeSteps)
print ( doMagic(10) ) 
print ( doMagic(11) ) 

doMagic = chooseStep(True, moveFiveSteps)
print ( doMagic(10) )
print ( doMagic(11) ) 

doMagic = chooseStep(False, moveTwoSteps)
print ( doMagic(10) ) 
print ( doMagic(11) ) 

doMagic = chooseStep(False, moveThreeSteps)
print ( doMagic(10) ) 
print ( doMagic(11) )

doMagic = chooseStep(False, moveFiveSteps)
print ( doMagic(10) )
print ( doMagic(11) )

