

# EXPERIMENT FOLLOWING CODE BY TYPING LINE BY LINE ON PYTHON SHELL

#   >>>>>>> MOMENT COMPLETED, RAISE YOUR HAND!!!  <<<<<<<<<

# ____________________________________________________________
#
#     PROGRAM 1 : noblanks.py
# ____________________________________________________________


"""
Reads in text files and writes corresponding .nb files with no blank
lines.
"""

import os
import sys


def read_data(filename):
    lines = []
    fh = None
    # try-except-finally Construct
    try:
        fh = open(filename, encoding="utf8")
        for line in fh:
            if line.strip():
                lines.append(line)
    except (IOError, OSError) as err:
        print(err)
        raise OSError
        # return []

    finally: # Finally Block Code Will Always Run
        if fh is not None:
            fh.close()
        print("Hit Finally -> Read Data Function")
    return lines


def write_data(lines, filename):
    fh = None
    try:
        fh = open(filename, "w", encoding="utf8")
        for line in lines:
            fh.write(line)
    except EnvironmentError as err:
        print(err)
        raise IOError
    finally:
        if fh is not None:
            fh.close()
        print("Hit Finally -> Write Data Function")

def startFunction():
    if len(sys.argv) < 2:
        print("usage: noblanks.py infile1 [infile2 [... infileN]]")
        sys.exit()

    try:
        print("Main Function")

        for filename in sys.argv[1:]:
            lines = read_data(filename)
            if lines:
                write_data(lines, os.path.splitext(filename)[0] + ".nb")
    except IOError:
        print("Main Function: Exception from Read Data")
    except OSError:
        print("Main Function: Exception from Write Data")
    finally:
        print("Hit Finally -> Main Function")

startFunction()

