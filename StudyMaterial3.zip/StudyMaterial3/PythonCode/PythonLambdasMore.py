
#____________________________________________________________
#
#		LAMBDA WITH VARIABLE NUMBER OF POISITONAL ARGUMENTS
#____________________________________________________________


def average(*values):
	sum = 0
	for value in values:
		sum = sum + value
	result = sum / len(values)
	return result

print("\nFunction : average()")
print(average(1, 2, 3, 4, 5, 6, 7, 8, 9, 10))
print(average(1, 2, 3, 4, 5, 6))
print(average(1, 2, 3, 4))


averageLambda = lambda *values:  sum(values) / len(values)

print("\nLambda : averageLambda()")
print(averageLambda(1, 2, 3, 4, 5, 6, 7, 8, 9, 10))
print(averageLambda(1, 2, 3, 4, 5, 6))
print(averageLambda(1, 2, 3, 4))

