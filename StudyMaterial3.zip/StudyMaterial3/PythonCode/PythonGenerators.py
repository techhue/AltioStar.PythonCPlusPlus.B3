

def numbersGiver(start = 0 , end = 10):
	number = start
	limit = end
	numbers = []
	while number < limit:
		numbers.append(number)
		number = number + 1
	return numbers


# Generators Are Special Functions Which Yield/Generates Values On Demand
def numbersGenerator(start, end):
	limit = end
	number = start
	while number < limit:
		yield number # After Yeilding Number Execution Stops
					 # It Will Continue In Next Iteration
		number = number + 1
				

# Generators Are Special Functions Which Yield Values On Demand
def numbersInfiniteGenerator(start):
	number = start
	while True:
		yield number
		number = number + 1

#________________________________________________

# Generator Function To Generate Values On Demand
def fourGenerator():
    x = 0                                    
    while x < 4:
        print("Before Yield : Value Of x =", x)
        yield x                              
        print("After  Yield : Value Of x =", x)
        x = x + 1                               

fourG = fourGenerator()

next(fourG)
# Before Yield : Value Of x = 0
# 0

next(fourG)
# After  Yield : Value Of x = 0
# Before Yield : Value Of x = 1
# 1

next(fourG)
# After  Yield : Value Of x = 1
# Before Yield : Value Of x = 2
# 2

next(fourG)
# After  Yield : Value Of x = 2
# Before Yield : Value Of x = 3
# 3

# next(fourG)
# After  Yield : Value Of x = 3

for number in fourGenerator():
    print(number)

# Output Will Be
# Before Yield : Value Of x = 0
# 0
# After  Yield : Value Of x = 0
# Before Yield : Value Of x = 1
# 1
# After  Yield : Value Of x = 1
# Before Yield : Value Of x = 2
# 2
# After  Yield : Value Of x = 2
# Before Yield : Value Of x = 3
# 3
# After  Yield : Value Of x = 3

2 in fourGenerator()

# Output Will Be
# in generator, x = 0
# in generator, x = 1
# in generator, x = 2
# True

5 in fourGenerator()

# Output Will Be
# in generator, x = 0
# in generator, x = 1
# in generator, x = 2
# in generator, x = 3
# False

if __name__ == '__main__':

	print("\nCalling Function : numbersGiver")
	numbers = numbersGiver()
	print(numbers)


	print("\nCalling Function : numbersGenerator")
	numbersAgain = numbersGenerator(0, 10)
	print(numbersAgain)
	type(numbersAgain)

	next(numbersAgain)
	for number in numbersAgain:
		print(number)


	print("\nCalling Function : numbersInfiniteGenerator")
	infiniteGenerator = numbersInfiniteGenerator(0)
	print(infiniteGenerator)
	type(infiniteGenerator)

	print(next(infiniteGenerator))
	print(next(infiniteGenerator))
	print(next(infiniteGenerator))
	print(next(infiniteGenerator))
	print(next(infiniteGenerator))
	print(next(infiniteGenerator))
	print(next(infiniteGenerator))
	print(next(infiniteGenerator))
	print(next(infiniteGenerator))
	print(next(infiniteGenerator))
	print(next(infiniteGenerator))
	print(next(infiniteGenerator))
	print(next(infiniteGenerator))
	print(next(infiniteGenerator))
	print(next(infiniteGenerator))
	print(next(infiniteGenerator))

