
# EXPERIMENT FOLLOWING CODE, MOMENT DONE, RAISE YOUR HAND!!!

#__________________________________________________________-
#                   PYTHON TUPLES
#__________________________________________________________-

# Python Tuple Is Collection Of Ordered Data
# point is a Tuple Having Two Members 10 and 20. In Tuple Order Matters
point = (10, 20)
type(point)

point[0] # Accessing First Element
point[1] # Accessing Second Element

# Creating Tuple Of Tuples
# Tuples Can Store Heterogeneous Ordered Data
something = ( "Ding", "Dong", 100, 199, (1000, 2000), 90.89)
print(something) # ('Ding', 'Dong', 100, 199, (1000, 2000), 90.89)
len(something) #6

point # (10, 20)
len(point) # 2

something[0] # 'Ding'
something[1] # 'Dong'
something[2] # 100
something[3] # 199
something[4] # (1000, 2000)
something[5] # 90.89

something[0] # 'Ding'
something[0][0] #'D'
something[0][1] #'i'
something[0][2] # 'n'
something[4] # (1000, 2000)
something[4][0]
1000
something[4][2]
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
IndexError: tuple index out of range

something[4][1] # 2000


point
(10, 20)

point[0]  #10

# Tuple Are Immutable In Nature
# You Can't Change Tuple Members
point[0] = 100
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: 'tuple' object does not support item assignment


# Strings Are Immutable In Nature
# You Can't Change String Members

greeting        # 'Hello World!'
greeting[0]     # 'H'
greeting[0] = 'K'
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: 'str' object does not support item assignment


something
('Ding', 'Dong', 100, 199, (1000, 2000), 90.89)
greeting
'Hello World!'

# String Concatenation Using + Operator
# It Will Create New String After Concatenating
greetingNew = greeting + " Asywarya!"
greetingNew  # 'Hello World! Asywarya!'

tuple1 = (10, 20, 30)
tuple2 = (100, 200)

# Tuple Concatenation Using + Operator
# It Will Create New Tuple After Concatenating
tuple3  = tuple1 + tuple2
tuple3  # (10, 20, 30, 100, 200)

tuple4 = ( tuple1, tuple2, greeting, something)
tuple4
((10, 20, 30), (100, 200), 'Hello World!', ('Ding', 'Dong', 100, 199, (1000, 2000), 90.89))

tuple4[0]
(10, 20, 30)
tuple4[1]
(100, 200)
tuple4[2]
'Hello World!'
tuple4[2][2]
'l'

tuple4[3]
('Ding', 'Dong', 100, 199, (1000, 2000), 90.89)

tuple4[3][0]
'Ding'

tuple4[3][0][1]
'i'

# Looping On Tuple
#   In Each Iteration Next Element In Tuple Is Picked
#   And Assigned To item.
for item in tuple4:
    print(item)

(10, 20, 30)
(100, 200)
Hello World!
('Ding', 'Dong', 100, 199, (1000, 2000), 90.89)

numbers = (1, 2, 3, 4, 5, 6, 7, 8, 90)

# Using Slicing And Striding Operator
# Picking Slice From Tuple From Index 0 to 5 Both Including
numbers[0:6] # (1, 2, 3, 4, 5, 6)

# Picking Slice From Tuple From Index 3 to 5 Both Inclusive
numbers[3:6]
(4, 5, 6)

# Reading Tuple From Right To Left
# Last Element In Tuple
numbers[-1]  # 90

# Second Last Element In Tuple
numbers[-2]  # 8

# Third Last Element In Tuple
numbers[-3]  # 7

# Using Slicing And Striding Operator
#[Start : End : Steps/Stride ]
# In Following Code 
# Start Index = 0   [ Inclusive ]
# End Index = 6     [ Exclusive ]
# Steps/Stride  = 2 , i.e. Indexes Are Increased By Steps = 2
numbers[0:6:2] # (1, 3, 5)


point = (10, 20)

# Tuple Unpacking
# point Tuple Have 2 Elements. 
# These Two elements Are Unpacked On a and b Respectively
a, b = point
print(a)   # 10
print(b)    # 20

point5 = (10, 20, 30, 40, 99)

# Tuple Unpacking
# point Tuple Have 5 Elements. 
# These 5 Elements Are Unpacked On a, b, c, d and e Respectively
a, b, c, d, e = point5
print(a)    # 10
print(b)    # 20
print(c)    # 30
print(d)    # 40
print(e)    # 99


# Tuple Unpacking
# point Tuple Have 5 Elements. 
# These 5 Elements Are Unpacked On a, b Respectively
# Where a Will Get First Element and Rest All Will Be Assigned To b
a, *b = point5
print(a)  # 10
print(b)  # [20, 30, 40, 99]

# Tuple Unpacking
# point Tuple Have 5 Elements. 
# These 5 Elements Are Unpacked On a, b Respectively
# Where a Will Get First Element, c Will Get Last Element
# Rest All Will Be Assigned To b
a, *b, c = point5
print(a) # 10
print(b) # [20, 30, 40]
print(c) # 99

# Swapping Values Using Tuple Unpacking
aa = 1000
bb = 2000
bb, aa = (aa, bb)
print(bb) # 1000
print(aa) # 2000


# Looping On Tuple Of Tuples
points = ( (10, 20),  (100, 200), (99, 88), (0, 0), (10, 10) )
# In Each Iteration point Will Be Assigned Tuple Values From points Tuple
for point in points:
    print(point)

# Loop Output Will Be
# (10, 20)
# (100, 200)
# (99, 88)
# (0, 0)
# (10, 10)

# Looping On Tuple Of Tuples
# Along With Upacking Elements Of Two Elements Tuple
for xCoordinate, yCoordinate in points:
    print(xCoordinate)
    print(yCoordinate)

# Loop Output Will Be
# 10
# 20
# 100
# 200
# 99
# 88
# 0
# 0
# 10
# 10

for xCoordinate, yCoordinate in points:
    print( " X Coordinate = {0} and Y Cooridnate = {1}".format(xCoordinate, yCoordinate) )

# Loop Output Will Be
#  X Coordinate = 10 and Y Cooridnate = 20
#  X Coordinate = 100 and Y Cooridnate = 200
#  X Coordinate = 99 and Y Cooridnate = 88
#  X Coordinate = 0 and Y Cooridnate = 0
#  X Coordinate = 10 and Y Cooridnate = 10


#__________________________________________________________-
#                PYTHON LIST
#__________________________________________________________-


# Python Lists Are MUTABLE IN NATURE
numbersAgain = [10, 20, 30, 40, 50, 60, 70, 80, 99]
numbers = (1, 2, 3, 4, 5, 6, 7, 8, 90)

type(numbersAgain)  # <class 'list'>
type(numbers)       # <class 'tuple'>

# Looping On List
for number in numbersAgain:
    print(number)

# Loop Output Will Be
# 10
# 20
# 30
# 40
# 50
# 60
# 70
# 80
# 99
numbersAgain[0]     # 10
numbersAgain[1]     # 20

# Using Slicing And Striding Operator
#[Start : End : Steps/Stride ]
# In Following Code 
# Start Index   = 2   [ Included ]
# End Index     = 8   [ Excluded ]
# Steps/Stride  = 1 , i.e. Default Value, Indexes Are Increased By Steps = 1
numbersAgain[2: 8]      # [30, 40, 50, 60, 70, 80]

# Using Slicing And Striding Operator
#[Start : End : Steps/Stride ]
# In Following Code 
# Start Index   = 2   [ Included ]
# End Index     = 8   [ Excluded ]
# Steps/Stride  = 2 , i.e. Indexes Are Increased By Steps = 2
numbersAgain[2: 8: 2]   # [30, 50, 70]

# Creating List Of Heterogenous Data
nestedList = [ numbers, numbersAgain, something, greeting ]
print(nestedList) # [(1, 2, 3, 4, 5, 6, 7, 8, 90), [10, 20, 30, 40, 50, 60, 70, 80, 99], ('Ding', 'Dong', 100, 199, (1000, 2000), 90.89), 'Hello World!']

print(nestedList[0])  # (1, 2, 3, 4, 5, 6, 7, 8, 90)
print(nestedList[1])  # [10, 20, 30, 40, 50, 60, 70, 80, 99]
print(nestedList[2])  # ('Ding', 'Dong', 100, 199, (1000, 2000), 90.89)
print(nestedList[3])  # 'Hello World!'

# Last Element In List
print(nestedList[-1])       # 'Hello World!'

# Last Element In List
print(numbersAgain[-1])     # 99

# Second Last Element In Tuple
print(numbersAgain[-2])     # 80

# Lists Are MUTABLE
print(numbersAgain)         # [10, 20, 30, 40, 50, 60, 70, 80, 99]
# Updating List Member At Index 0
numbersAgain[0] = 1000
print(numbersAgain)         # [1000, 20, 30, 40, 50, 60, 70, 80, 99]

# Tuples Are IMMUTABLE
print(numbers)              # (1, 2, 3, 4, 5, 6, 7, 8, 90)

# Updating Tuple Member At Index 0 : YOU CAN'T CHANGE TUPLE MEMBERS
numbers[0] = 1000
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: 'tuple' object does not support item assignment

# Accessing List Members Using Index Operator []
nestedList = [(1, 2, 3, 4, 5, 6, 7, 8, 90), [1000, 20, 30, 40, 50, 60, 70, 80, 99], ('Ding', 'Dong', 100, 199, (1000, 2000), 90.89), 'Hello World!']
print(nestedList[2])            # ('Ding', 'Dong', 100, 199, (1000, 2000), 90.89)
print(nestedList[2][1])         # 'Dong'
print(nestedList[2][1][1])      # 'o'

nestedList[4]
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
IndexError: list index out of range

print(nestedList[3])        # 'Hello World!'
print(nestedList[3][1])     # 'e'
print(nestedList[2][1])     # 'Dong'

# List Unpacking
numbersAgain = [1000, 20, 30, 40, 50, 60, 70, 80, 99]

# List  Unpacking
# numbersAgain List Have 9 Elements. 
# These 9 Elements Are Unpacked On first, last Respectively
# Where first Will Get First Element and Rest All Will Be Assigned To last
first, *rest = numbersAgain
print(first)   # 1000
print(rest)    # [20, 30, 40, 50, 60, 70, 80, 99]

# List Unpacking
# numbersAgain Tuple Have 9 Elements. 
# These 9 Elements Are Unpacked On first, rest, secondLast, last Respectively
# Where first Will Get First Element, last Will Get Last Element, secondLast Will Get Second Element
# Rest All Will Be Assigned To rest
first, *rest, secondLast, last  = numbersAgain
print(first)        # 1000
print(last)         # 99
print(secondLast)   # 80
print(rest)         # [20, 30, 40, 50, 60, 70]



numbers = (1, 2, 3, 4, 5, 6, 7, 8, 90)

# Operations/Functions Supported By Tuple
dir(numbers)
['__add__', '__class__', '__contains__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__getnewargs__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__rmul__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__', 'count', 'index']

# Counting Element Value 8 Exists How Many Times In Tuple
numbers.count(8) # 1
# Location of Element Value 8 In Tuple. It Will Return Index Of Value In Tuple
numbers.index(8) # 7

# Operations/Functions Supported By List
dir(list)
['__add__', '__class__', '__contains__', '__delattr__', '__delitem__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__gt__', '__hash__', '__iadd__', '__imul__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__reversed__', '__rmul__', '__setattr__', '__setitem__', '__sizeof__', '__str__', '__subclasshook__', 'append', 'clear', 'copy', 'count', 'extend', 'index', 'insert', 'pop', 'remove', 'reverse', 'sort']

numbersAgain = [1000, 20, 30, 40, 50, 60, 70, 80, 99]

# WIll Append Element Value 999 In List At The End
numbersAgain.append(999)
print(numbersAgain)     # [1000, 20, 30, 40, 50, 60, 70, 80, 99, 999]

# WIll Pop/Remove Last Element From The List End And Returns It
numbersAgain.pop()      # 999
print(numbersAgain)     # [1000, 20, 30, 40, 60, 70, 80, 99]

# WIll Remove Element With Value 50 From The List
numbersAgain.remove(50)
print(numbersAgain)     # [1000, 20, 30, 40, 60, 70, 80, 99]

# WIll Remove Element With Value 888 In The List At Index 3
numbersAgain.insert(3, 888)
print(numbersAgain)     #  [1000, 20, 30, 888, 40, 60, 70, 80, 99]

numbersAgain.reverse()
print(numbersAgain)     # [99, 80, 70, 60, 40, 888, 30, 20, 1000]

# Sorting In Acending Order
numbersAgain.sort()
print(numbersAgain)     # [20, 30, 40, 60, 70, 80, 99, 888, 1000]

# List Concatenation
# It Will Create New List After Adding Elements From Both Lists
numbersAgain = numbersAgain + [9000, 8000]
print(numbersAgain)     # [20, 30, 40, 60, 70, 80, 99, 888, 1000, 9000, 8000]


#__________________________________________________________-
#                   PYTHON SETS
#__________________________________________________________-

# Sets In Python
# Sets In Pythhon Are Mathematical Sets
#       Order Doesn't Matters
#       Elements Should Be Unique i.e. Duplicates Are Not Allowed

s = { 10, 20, "Ding", "Dong", 30, 20,  10}
print(s)            # {'Dong', 'Ding', 10, 20, 30}
print( type(s))     # <class 'set'>

setA = { 10, 20, "Ding", "Dong", 30, 20,  10}
print(setA)         # {'Dong', 'Ding', 10, 20, 30}

setB = { 100, 200, "Ping", 10, 20, "Ding" }
print(setB)         # {100, 200, 'Ding', 10, 20, 'Ping'}

# Unions Of Two Sets SetA and SetB
setA.union(setB)    # {'Dong', 100, 200, 'Ding', 10, 20, 'Ping', 30}

# Intersections Of Two Sets SetA and SetB
setA.intersection(setB)
{'Ding', 10, 20}

# Difference Of Two Sets SetA and SetB
setA.difference(setB)     # {'Dong', 30}

# Iterating/Looping On Sets
#       Elements Order Doesn't Matter
#       i.e. You Can't Predict What Will Be Elements Order In Set
for item in setA:
    print(item)

# Looping Output Is
# Dong
# Ding
# 10
# 20
# 30

# Iterating/Looping On Sets
#       Elements Order Doesn't Matter
#       i.e. You Can't Predict What Will Be Elements Order In Set
for item in setB:
    print(item)
# Looping Output Is

# 100
# 200
# Ding
# 10
# 20
# Ping


setD = { 10, 20, 30, 30, "Ding"}

print(setD)     # {'Ding', 10, 20, 30}
len(setD)       # 4
dir(setD)       # ['__and__', '__class__', '__contains__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__gt__', '__hash__', '__iand__', '__init__', '__init_subclass__', '__ior__', '__isub__', '__iter__', '__ixor__', '__le__', '__len__', '__lt__', '__ne__', '__new__', '__or__', '__rand__', '__reduce__', '__reduce_ex__', '__repr__', '__ror__', '__rsub__', '__rxor__', '__setattr__', '__sizeof__', '__str__', '__sub__', '__subclasshook__', '__xor__', 'add', 'clear', 'copy', 'difference', 'difference_update', 'discard', 'intersection', 'intersection_update', 'isdisjoint', 'issubset', 'issuperset', 'pop', 'remove', 'symmetric_difference', 'symmetric_difference_update', 'union', 'update']

# Sets Are Mutable In Python
setD.add("Dong")
print(setD)    # {'Ding', 10, 'Dong', 20, 30}

setD.add(99.89)
print(setD)     # {99.89, 'Ding', 10, 'Dong', 20, 30}

setD.remove(10)
print(setD)         # {99.89, 'Ding', 'Dong', 20, 30}
print(setD.pop())   # 99.89


setD.pop()          # 'Ding'
setD.pop()          # 'Dong'
print(setD)         # {20, 30}

# Python Set Does't Maintain Order
#       Python Set Is A Mathematical Set
setD.add("Dong")
setD.add("Ding")
print(setD)         # {'Ding', 'Dong', 20, 30}

setD.add(99.99)
print(setD)         # {99.99, 'Ding', 'Dong', 20, 30}

# Python Set Does't Allow Duplicates
#       Python Set Is A Mathematical Set
setD.add("Dong")
print(setD)         # {99.99, 'Ding', 'Dong', 20, 30}

# Python Set Does't Support Subscript/Indexing Operator []
setD[0]
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: 'set' object is not subscriptable



setA = {'Dong', 1000, 'Ding', 10, 20, 30}
print(setA)         # {'Dong', 1000, 'Ding', 10, 20, 30}
setB = { 100, 200, "Ping", 10, 20, "Ding" }
print(setB)         # {100, 200, 'Ding', 10, 20, 'Ping'}

setC = {'Dong', 1000, 'Ding', 10, 20, 30, "Ting", "Tong", 1000 }
print(setC)  # {'Dong', 'Ting', 1000, 'Ding', 10, 'Tong', 20, 30}

setA.issubset(setC)
True

setA.issubset(setB)
False

# Two Sets Equality Test
setA = {'Dong', 1000, 'Ding', 10, 20, 30}
setB = {100, 200, 'Ding', 10, 20, 'Ping'}

setA == setB  # False

setC = {'Dong', 1000, 'Ding', 10, 20, 30}
setA == setC   # True


#__________________________________________________________-
#                 PYTHON FROZEN SETS
#__________________________________________________________-


# Python Frozen Sets Are Immutable In Nature
frozenSetA = frozenset()

# Creating A Frozen Set From A Mutable Set A
frozenSetA = frozenset( setA )
print(frozenSetA)  # frozenset({'Dong', 20, 1000, 'Ding', 10, 30})

dir(frozenSetA)   # ['__and__', '__class__', '__contains__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__ne__', '__new__', '__or__', '__rand__', '__reduce__', '__reduce_ex__', '__repr__', '__ror__', '__rsub__', '__rxor__', '__setattr__', '__sizeof__', '__str__', '__sub__', '__subclasshook__', '__xor__', 'copy', 'difference', 'intersection', 'isdisjoint', 'issubset', 'issuperset', 'symmetric_difference', 'union']


#__________________________________________________________-
#                 PYTHON DICTIONARIES
#__________________________________________________________-


#Python Dictionary: 
#      It's A Set Of Elements 
#      Where Each Element Is A Tuple With Two Elements i.e. (Key, Value)
#      Dictionary Doesn't Maintain Order 
#      Keys Are Unique In Dictionary

ageNameDictionary = { 20: "Lewis Carol", 25: "Alice", 15: "Ram Singh", 40: "Gabbar Singh", 60: "Thakkur" }

print(ageNameDictionary) # {20: 'Lewis Carol', 25: 'Alice', 15: 'Ram Singh', 40: 'Gabbar Singh', 60: 'Thakkur'}

# Quering Dictionary With Keys. 
# It Returns Value For Key If Key Exists
print(ageNameDictionary[20]) # 'Lewis Carol'
print(ageNameDictionary[40]) # 'Gabbar Singh'

# If Key Doesn't Exists In Dictionary, Than It Gives KeyError
print(ageNameDictionary[44])
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
KeyError: 44

# Getting List Of All Keys In The Dictionary
print(ageNameDictionary.keys())  # dict_keys([20, 25, 15, 40, 60])

# Getting List Of All Values In The Dictionary
print(ageNameDictionary.values())
# dict_values(['Lewis Carol', 'Alice', 'Ram Singh', 'Gabbar Singh', 'Thakkur'])

# Getting List Of All (Key, Value) Tuples In The Dictionary
print(ageNameDictionary.items())
dict_items([(20, 'Lewis Carol'), (25, 'Alice'), (15, 'Ram Singh'), (40, 'Gabbar Singh'), (60, 'Thakkur')])

# Looping On List Of Keys In Dictionary
for key in ageNameDictionary.keys():
    print(key)

# Loop Output Will Be
# 20
# 25
# 15
# 40
# 60

# Looping On List Of Values In Dictionary
for values in ageNameDictionary.values():
    print(values)

# Loop Output Will Be
# Lewis Carol
# Alice
# Ram Singh
# Gabbar Singh
# Thakkur

# Looping On List Of Tuples i.e. (Key, Value) In Dictionary
for item in ageNameDictionary.items():
    print(item)

# Loop Output Will Be
# (20, 'Lewis Carol')
# (25, 'Alice')
# (15, 'Ram Singh')
# (40, 'Gabbar Singh')
# (60, 'Thakkur')


# Looping On List Of Tuples i.e. (Key, Value) In Dictionary
# As Well As Unpacking Tuple (Key, Value) On key And value Variables
for key, value in ageNameDictionary.items():
    print(" For Key = {0} and Value = {1}".format(key, value))

# Loop Output Will Be
 # For Key = 20 and Value = Lewis Carol
 # For Key = 25 and Value = Alice
 # For Key = 15 and Value = Ram Singh
 # For Key = 40 and Value = Gabbar Singh
 # For Key = 60 and Value = Thakkur

print( type(ageNameDictionary) ) # <class 'dict'>


# If Key Already Exists
#       Than With Assignment Statement We Can Modify Key Value
# Modify Already Existing Key Value
# i.e. For Key 25 Value Is Changed From "Alice" To "Alice Thomson"
ageNameDictionary[25] = 'Alice Thomson'

print(ageNameDictionary)
# {20: 'Lewis Carol', 25: 'Alice Thomson', 15: 'Ram Singh', 40: 'Gabbar Singh', 60: 'Thakkur'}

# If Key Already DOESNOT Exists 
#       Than With Assignment Statement We Add New Key And Value
ageNameDictionary[44] = 'Sholay'

print(ageNameDictionary)
# {20: 'Lewis Carol', 25: 'Alice Thomson', 15: 'Ram Singh', 40: 'Gabbar Singh', 60: 'Thakkur', 44: 'Sholay'}

print( dir(dict) )
# ['__class__', '__contains__', '__delattr__', '__delitem__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__reversed__', '__setattr__', '__setitem__', '__sizeof__', '__str__', '__subclasshook__', 'clear', 'copy', 'fromkeys', 'get', 'items', 'keys', 'pop', 'popitem', 'setdefault', 'update', 'values']


# Can Access Key's Value 
#       Using Subscript Operator [Key] or get(Key) Function
# If Key Already Exists It Will Return Value
print( ageNameDictionary[25] )       # 'Alice Thomson'
print( ageNameDictionary.get(25))    # 'Alice Thomson'


# Can Access Key's Value 
#       Using Subscript Operator [Key] or get(Key) Function
# If Key DOESNOT Exists 
#       Using Subscript Operator [Key] Will Give KeyError
#       Using get(Key) Function Will Return None

# If Key DOESNOT Exists 
#       Using Subscript Operator [Key] Will Give KeyError
print( ageNameDictionary[50] )
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
KeyError: 50

# If Key DOESNOT Exists 
#       Using get(Key) Function Will Return None
print( ageNameDictionary.get(50) )

# If Key DOESNOT Exists 
#       Using get(Key, DefaultValue) Function Will Return DefaultValue
print( ageNameDictionary.get(50, "Unknown Value")) # 'Unknown Value'

# If Key Already Exists 
#       Using get(Key) Function Will Return Key's Value
print( ageNameDictionary.get(25, "Unknown Value"))  # 'Alice Thomson'


print( len(ageNameDictionary) _) # 6


ageNameD = { 100 : "Ram Singh", 300: "Veeru" }
ageNameDictionary + ageNameD
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: unsupported operand type(s) for +: 'dict' and 'dict'



#__________________________________________________________-
#           PYTHON OBJECT CREATION USING CONSTRUCTORS
#__________________________________________________________-



# Literal Syntax To Create a Object With Initial Value Of 90
a = 90

# Literal Syntax To Create a Object With Initial Value Of 0
aa = 0

type(a)  # <class 'int'>
type(aa) # <class 'int'>


# Creating a Object Using int() Constructor
# It will Inialise a With 0 Default Value For int Type
a = int()
type(a)     # <class 'int'>
print( a )  # 0

# Creating a Object Using float() Constructor
# It will Inialise a With 0.0 Default Value For float Type
f = float()
type(f)     # <class 'float'>
print( f ) # 0.0

# Creating a Object Using str() Constructor
# It will Inialise a With Empty String "" Default Value For str Type
s = str()
type(s) # <class 'str'>
print( s )  # ''

t = tuple()
type(t) # <class 'tuple'>
print( t ) # ()

l = list()
type(l) # <class 'list'>
print( l )  # []

ss = set()
type(ss) # <class 'set'>
print(set) # set{} 

dd = dict()
type(dd) <class 'dict'>
print(dd) # {}


# Creating a Object Using Constructors
#   It Will Create Duplicate Copy Of That Type
# int(Sequence), float(Sequence), str(Sequence), dict(Sequence), 
# set(Sequence), list(Sequence), tuple(Sequence) etc...
# It will Return Data Of Type With Elements Collected After Iteratining Sequence 
# These Constructors Can Be Used To Convert Type Of The Data

aa = int(10)
type(aa) # <class 'int'>
print(aa) # 10

ff = float(90.99)
type(float) # <class 'type'>
float(ff) # 90.99

ss = str("Ding Dong")
print(ss) # 'Ding Dong'


tt = tuple( (10, 20, 30) )
print(tt) # (10, 20, 30)

ll = list( (10, 20, 20 ) )
print(ll) # [10, 20, 20]

lll = list( [ 10, 20, 20 ] )
print(lll) # [10, 20, 20]

ttt = tuple( "Hello" )
print(ttt) # ('H', 'e', 'l', 'l', 'o')

listHellow = list( "Hello World"  )
print(listHellow) # ['H', 'e', 'l', 'l', 'o', ' ', 'W', 'o', 'r', 'l', 'd']

# Iterating/Looping On String
for character in "Hello":
    print(character)

# Output Of The Loop
# H
# e
# l
# l
# o

#__________________________________________________________-
#__________________________________________________________-
#__________________________________________________________-
#__________________________________________________________-

