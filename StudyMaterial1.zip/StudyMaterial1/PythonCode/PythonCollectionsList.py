
# EXPERIMENT FOLLOWING CODE BY TYPING LINE BY LINE ON PYTHON SHELL

#   >>>>>>>  MOMENT COMPLETED, RAISE YOUR HAND!!!  <<<<<<<<<

#__________________________________________________________-
#                      PYTHON LIST
#__________________________________________________________-


# Python Lists Are MUTABLE IN NATURE
numbersAgain = [10, 20, 30, 40, 50, 60, 70, 80, 99]
numbers = (1, 2, 3, 4, 5, 6, 7, 8, 90)

type(numbersAgain)  # <class 'list'>
type(numbers)       # <class 'tuple'>

# Looping On List
for number in numbersAgain:
    print(number)

# Loop Output Will Be
# 10
# 20
# 30
# 40
# 50
# 60
# 70
# 80
# 99
numbersAgain[0]     # 10
numbersAgain[1]     # 20

# Using Slicing And Striding Operator
#[Start : End : Steps/Stride ]
# In Following Code 
# Start Index   = 2   [ Included ]
# End Index     = 8   [ Excluded ]
# Steps/Stride  = 1 , i.e. Default Value, Indexes Are Increased By Steps = 1
numbersAgain[2: 8]      # [30, 40, 50, 60, 70, 80]

# Using Slicing And Striding Operator
#[Start : End : Steps/Stride ]
# In Following Code 
# Start Index   = 2   [ Included ]
# End Index     = 8   [ Excluded ]
# Steps/Stride  = 2 , i.e. Indexes Are Increased By Steps = 2
numbersAgain[2: 8: 2]   # [30, 50, 70]

# Creating List Of Heterogenous Data
nestedList = [ numbers, numbersAgain, something, greeting ]
print(nestedList) # [(1, 2, 3, 4, 5, 6, 7, 8, 90), [10, 20, 30, 40, 50, 60, 70, 80, 99], ('Ding', 'Dong', 100, 199, (1000, 2000), 90.89), 'Hello World!']

print(nestedList[0])  # (1, 2, 3, 4, 5, 6, 7, 8, 90)
print(nestedList[1])  # [10, 20, 30, 40, 50, 60, 70, 80, 99]
print(nestedList[2])  # ('Ding', 'Dong', 100, 199, (1000, 2000), 90.89)
print(nestedList[3])  # 'Hello World!'

# Last Element In List
print(nestedList[-1])       # 'Hello World!'

# Last Element In List
print(numbersAgain[-1])     # 99

# Second Last Element In Tuple
print(numbersAgain[-2])     # 80

# Lists Are MUTABLE
print(numbersAgain)         # [10, 20, 30, 40, 50, 60, 70, 80, 99]
# Updating List Member At Index 0
numbersAgain[0] = 1000
print(numbersAgain)         # [1000, 20, 30, 40, 50, 60, 70, 80, 99]

# Tuples Are IMMUTABLE
print(numbers)              # (1, 2, 3, 4, 5, 6, 7, 8, 90)

# Updating Tuple Member At Index 0 : YOU CAN'T CHANGE TUPLE MEMBERS
numbers[0] = 1000
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: 'tuple' object does not support item assignment

# Accessing List Members Using Index Operator []
nestedList = [(1, 2, 3, 4, 5, 6, 7, 8, 90), [1000, 20, 30, 40, 50, 60, 70, 80, 99], ('Ding', 'Dong', 100, 199, (1000, 2000), 90.89), 'Hello World!']
print(nestedList[2])            # ('Ding', 'Dong', 100, 199, (1000, 2000), 90.89)
print(nestedList[2][1])         # 'Dong'
print(nestedList[2][1][1])      # 'o'

nestedList[4]
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
IndexError: list index out of range

print(nestedList[3])        # 'Hello World!'
print(nestedList[3][1])     # 'e'
print(nestedList[2][1])     # 'Dong'

# List Unpacking
numbersAgain = [1000, 20, 30, 40, 50, 60, 70, 80, 99]

# List  Unpacking
# numbersAgain List Have 9 Elements. 
# These 9 Elements Are Unpacked On first, last Respectively
# Where first Will Get First Element and Rest All Will Be Assigned To last
first, *rest = numbersAgain
print(first)   # 1000
print(rest)    # [20, 30, 40, 50, 60, 70, 80, 99]

# List Unpacking
# numbersAgain Tuple Have 9 Elements. 
# These 9 Elements Are Unpacked On first, rest, secondLast, last Respectively
# Where first Will Get First Element, last Will Get Last Element, secondLast Will Get Second Element
# Rest All Will Be Assigned To rest
first, *rest, secondLast, last  = numbersAgain
print(first)        # 1000
print(last)         # 99
print(secondLast)   # 80
print(rest)         # [20, 30, 40, 50, 60, 70]



numbers = (1, 2, 3, 4, 5, 6, 7, 8, 90)

# Operations/Functions Supported By Tuple
dir(numbers)
['__add__', '__class__', '__contains__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__getnewargs__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__rmul__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__', 'count', 'index']

# Counting Element Value 8 Exists How Many Times In Tuple
numbers.count(8) # 1
# Location of Element Value 8 In Tuple. It Will Return Index Of Value In Tuple
numbers.index(8) # 7

# Operations/Functions Supported By List
dir(list)
['__add__', '__class__', '__contains__', '__delattr__', '__delitem__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__gt__', '__hash__', '__iadd__', '__imul__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__reversed__', '__rmul__', '__setattr__', '__setitem__', '__sizeof__', '__str__', '__subclasshook__', 'append', 'clear', 'copy', 'count', 'extend', 'index', 'insert', 'pop', 'remove', 'reverse', 'sort']

numbersAgain = [1000, 20, 30, 40, 50, 60, 70, 80, 99]

# WIll Append Element Value 999 In List At The End
numbersAgain.append(999)
print(numbersAgain)     # [1000, 20, 30, 40, 50, 60, 70, 80, 99, 999]

# WIll Pop/Remove Last Element From The List End And Returns It
numbersAgain.pop()      # 999
print(numbersAgain)     # [1000, 20, 30, 40, 60, 70, 80, 99]

# WIll Remove Element With Value 50 From The List
numbersAgain.remove(50)
print(numbersAgain)     # [1000, 20, 30, 40, 60, 70, 80, 99]

# WIll Remove Element With Value 888 In The List At Index 3
numbersAgain.insert(3, 888)
print(numbersAgain)     #  [1000, 20, 30, 888, 40, 60, 70, 80, 99]

numbersAgain.reverse()
print(numbersAgain)     # [99, 80, 70, 60, 40, 888, 30, 20, 1000]

# Sorting In Acending Order
numbersAgain.sort()
print(numbersAgain)     # [20, 30, 40, 60, 70, 80, 99, 888, 1000]

# List Concatenation
# It Will Create New List After Adding Elements From Both Lists
numbersAgain = numbersAgain + [9000, 8000]
print(numbersAgain)     # [20, 30, 40, 60, 70, 80, 99, 888, 1000, 9000, 8000]

