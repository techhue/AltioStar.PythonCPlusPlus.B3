
print("Hello World!")
print("My Environment Is Ready!!!...")

