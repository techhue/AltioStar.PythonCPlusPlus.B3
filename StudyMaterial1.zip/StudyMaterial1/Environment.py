
______________________________________________________________________

				  INSTALLING PYTHON IN WINDOWS
______________________________________________________________________

______________________________________________________________________
				>>>>> PLEASE RAISE YOUR HAND <<<<<<
	WHOEVER VISUAL STUDIO CODE AND PYTHON INSTALLED IN THERE MACHINCES
______________________________________________________________________

1. Download Link 	: 
	https://www.python.org/downloads/release/python-3100/

	Go To Bottom Of Page and Download Windows Installer (64 Bit)
    
2. Download Python : Windows installer (64-bit)
	python-3.10.0-amd64.exe

3. Install By Clicking .exe File
	python-3.10.0-amd64.exe

	While Installing Make Sure To Select Following Options
		 
		 [SELECT] Install Launcher For All Users 
		 [SELECT] Add Python 3.10.x To PATH

    In Customize Installation Select All The Following Options
    	[SELECT] Documentation
    	[SELECT] Pip
    	[SELECT] IDLE
    	[SELECT] Python Test Suite
    	[SELECT] Py Launcher [SELECT] For All Users 



4. Checking Python Installation

	1. Run IDLE (Python 3.10.0 Shell)
	
	OR 
	
	2. Run Following Commands On Command Prompt or Terminal
		python 	--version
		python3 --version

5. Visual Studio Code Installation And Setup
	5.1 Download Visual Studio Code
		Download Link : https://code.visualstudio.com/

			Download File : VSCodeUserSetup-x64-1.62.3.exe
	5.2 Install VSCodeUserSetup-x64-1.62.3.exe
	5.3 Launch Visual Studio Code
	5.4 Install Python Extension From Microsoft In Visual Studio Code
			Click On Extensions Button On Left Hand Side In Visual Studio Code
			Type Python In Extensions Search Bar
			Click First Option "Python" Comes In Search Result
				Python  v2021.11.1422169775
				Microsoft

			Click Insall Button To Install Extension

	5.4 Create Hello.py File With Following Code
		
		File > New File : Hello.py

		Wrie Following Code In Hello.py File
		_______________________________________
		print("Hello World")
		print("My Environment Is Ready!!!...")

	5.5 Run Hello.py File 
		Click On Run Button On Top Right Corner
		
			OR
		
		Run > Run Without Debugging
		
			OR 
		
		Press Ctrl+F5


______________________________________________________________________
				>>>>> PLEASE RAISE YOUR HAND <<<<<<
	WHOEVER UbUNTU 20.04 LTS 64 Bit AND Sublime Text/Visual Studio Code Installed
__________________________________________________________________

Preparing an environment for Python and C/C++ Programming in their machines
Using Ubuntu 20.04 LTS 64 Bit In VirtualBox/Hyper-V

	1. Installing Ubuntu 20.04 LTS 64 Bit In VirtualBox/Hyper-V On Windows 10/11
		1.1 Quick article for installation process.
			https://automaticaddison.com/how-to-install-ubuntu-20-04-and-virtualbox-on-your-computer/

		1.2 Detailed Video for installation process:
			https://www.youtube.com/watch?v=x5MhydijWmc

		1.3 How to check Virtualisation is enabled in windows
			https://stackoverflow.com/questions/49005791/how-to-check-if-intel-virtualization-is-enabled-without-going-to-bios-in-windows

	2. Installing Sublime Text Editor in Ubuntu
		https://snapcraft.io/install/sublime-text/ubuntu

	3. Checking Python version installed on Ubuntu
		3.1 Open Terminal Application in Ubuntu
		3.2 Type following commands on it
			python --version
			python3 --version

	4. Writing HelloWorld.py
		4.1 Open Sublime Text Editor

		4.2 Write the following code and save the file Hello.py in Documents directory/folder

		print("Hello World!")

	4.3 Running Hello.py File. 
		Open Terminal Application and Type Following Commands
	
		First change to Documents directory where Hello.py file saved
			cd ~/Documents

		Run Python Code File
			python Hello.py

______________________________________________________________________

