## Chapter 09 Errors: MAC 10.8.2 (Mountain Lion)

###Error 1:

	g++  -c Stash4Test.cpp
	In file included from Stash4Test.cpp:7:
	Stash4.h:25: error: extra qualification ‘Stash::’ on member ‘Stash’
	make: *** [Stash4Test.o] Error 1

###Solution:

In-class definitions of member function(s)/constructor(s)/destructor don't require qualification such as student::.

So this code,

 ```c++
 Stash::~Stash()
```

should be this:

 ```c++
 ~Stash()
```

The qualification Stash:: is required only if you define the member functions outside the class, usually in .cpp file.


##Chapter 16 Errors: MAC 10.8.2 (Mountain Lion)

###Error 1:

	g++  -c TStack2Test.cpp
	In file included from TStack2Test.cpp:6:
	TStack2.h:31: error: type ‘Stack<T>’ is not derived from type ‘Stack<T>::iterator’
	TStack2.h:31: error: expected ‘;’ before ‘*’ token
	TStack2.h: In constructor ‘Stack<T>::iterator::iterator(const Stack<T>&)’:
	TStack2.h:33: error: class ‘Stack<T>::iterator’ does not have any field named ‘p’
	TStack2.h: In copy constructor ‘Stack<T>::iterator::iterator(const Stack<T>::iterator&)’:
	TStack2.h:35: error: class ‘Stack<T>::iterator’ does not have any field named ‘p’
	TStack2.h: In constructor ‘Stack<T>::iterator::iterator()’:
	TStack2.h:37: error: class ‘Stack<T>::iterator’ does not have any field named ‘p’
	TStack2.h: In member function ‘bool Stack<T>::iterator::operator++()’:
	TStack2.h:40: error: ‘p’ was not declared in this scope
	TStack2.h:43: error: ‘p’ was not declared in this scope
	TStack2.h: In member function ‘T* Stack<T>::iterator::current() const’:
	TStack2.h:47: error: ‘p’ was not declared in this scope
	TStack2.h:48: error: ‘p’ was not declared in this scope
	TStack2.h: In member function ‘T* Stack<T>::iterator::operator->() const’:
	TStack2.h:52: error: ‘p’ was not declared in this scope
	TStack2.h:53: error: there are no arguments to ‘require’ that depend on a template parameter, so a declaration of ‘require’ must be available
	TStack2.h:53: error: (if you use ‘-fpermissive’, G++ will accept your code, but allowing the use of an undeclared name is deprecated)
	TStack2.h: In member function ‘Stack<T>::iterator::operator bool() const’:
	TStack2.h:58: error: ‘p’ was not declared in this scope
	TStack2.h: In member function ‘bool Stack<T>::iterator::operator==(const Stack<T>::iterator&) const’:
	TStack2.h:61: error: ‘p’ was not declared in this scope
	TStack2.h: In member function ‘bool Stack<T>::iterator::operator!=(const Stack<T>::iterator&) const’:
	TStack2.h:64: error: ‘p’ was not declared in this scope
	make: *** [TStack2Test.o] Error 1

###Solution:

In this line, you are missing the typename keyword:
 ```c++
Stack::Link* p;
```

You need:
 ```c++
typename Stack::Link\* p;
```

This because Stack::Link* p is dependent on the template parameter (T) of the class template (A). To enable correct parsing of the template without having to make any assumptions about possible specializations of any other templates, the language rules require you to indicate which dependent names denote types by using the typename keyword.



##Chapter 13 Warnings: MAC 10.8.2 (Mountain Lion)

###Warning 1: 

	g++  -c BadVoidPointerDeletion.cpp
	BadVoidPointerDeletion.cpp: In destructor ‘Object::~Object()’:
	BadVoidPointerDeletion.cpp:22: warning: deleting ‘void*’ is undefined
	BadVoidPointerDeletion.cpp: In function ‘int main()’:
	BadVoidPointerDeletion.cpp:31: warning: deleting ‘void*’ is undefined

###Solution:

It depends on "safe." It will usually work because information is stored along with the pointer about the allocation itself, so the deallocator can return it to the right place. In this sense it is "safe" as long as your allocator uses internal boundary tags. (Many do.)

However, as mentioned above, deleting a void pointer will not call destructors, which can be a problem. In that sense, it is not "safe."

There is no good reason to do what you are doing the way you are doing it. If you want to write your own deallocation functions, you can use function templates to generate functions with the correct type. A good reason to do that is to generate pool allocators, which can be extremely efficient for specific types.

###Warning 2:

	g++  -c GlobalOperatorNew.cpp
	GlobalOperatorNew.cpp: In function ‘void* operator new(size_t)’:
	GlobalOperatorNew.cpp:12: warning: format ‘%d’ expects type ‘int’, but argument 2 has type ‘size_t’
	GlobalOperatorNew.cpp:12: warning: format ‘%d’ expects type ‘int’, but argument 2 has type ‘size_t’

###Solution:

Use %zu to print it.

###Warning 3:

	g++  -c PStashTest.cpp
	PStashTest.cpp: In function ‘int main()’:
	PStashTest.cpp:26: warning: deleting ‘void*’ is undefined

###Solution:

Warning 1 solution.

###Warning 4:

	g++  -c ArrayOperatorNew.cpp
	ArrayOperatorNew.cpp: In static member function ‘static void Widget::operator delete(void*)’:
	ArrayOperatorNew.cpp:25: warning: deleting ‘void*’ is undefined
	ArrayOperatorNew.cpp: In static member function ‘static void Widget::operator delete [](void*)’:
	ArrayOperatorNew.cpp:34: warning: deleting ‘void*’ is undefined

###Solution:

Warning 1 solution.

##Chapter 14 Warnings: MAC 10.8.2 (Mountain Lion)

###Warning 1:

	g++  -c PseudoConstructor.cpp
	PseudoConstructor.cpp: In constructor ‘X::X()’:
	PseudoConstructor.cpp:12: warning: deprecated conversion from string constant to ‘char*’

###Solution:

If you really want to modify Type:
 ```c++
char *s;
strcpy( s, "howdy" );
```

If you don't want to modify access:
 ```c++
const char *s;
```

Please note, that, however, arrays of char in C and in C++ come with a lot of problems. For example, you don't really know if the call to new has been successful, or whether it is going to throw an exception. Also, strcpy() could surpass the limit of 10 chars.

#####Some other solutions Links
 1. http://stackoverflow.com/questions/59670/how-to-get-rid-of-deprecated-conversion-from-string-constant-to-char-warnin
 2. http://stackoverflow.com/questions/8126512/deprecated-conversion-from-string-constant-to-char

##Chapter 15 Warnings: MAC 10.8.2 (Mountain Lion)

###Warning 1:

	g++  -c Instrument4.cpp
	Instrument4.cpp: In member function ‘virtual char* Instrument::what() const’:
	Instrument4.cpp:17: warning: deprecated conversion from string constant to ‘char*’
	Instrument4.cpp: In member function ‘virtual char* Wind::what() const’:
	Instrument4.cpp:28: warning: deprecated conversion from string constant to ‘char*’
	Instrument4.cpp: In member function ‘virtual char* Percussion::what() const’:
	Instrument4.cpp:37: warning: deprecated conversion from string constant to ‘char*’
	Instrument4.cpp: In member function ‘virtual char* Stringed::what() const’:
	Instrument4.cpp:46: warning: deprecated conversion from string constant to ‘char*’
	Instrument4.cpp: In member function ‘virtual char* Brass::what() const’:
	Instrument4.cpp:55: warning: deprecated conversion from string constant to ‘char*’
	Instrument4.cpp: In member function ‘virtual char* Woodwind::what() const’:
	Instrument4.cpp:63: warning: deprecated conversion from string constant to ‘char*’

###Solution:

Warning 1 of chapter 14 solution.

###Warning 2:

	g++  -c Instrument5.cpp
	Instrument5.cpp: In member function ‘virtual char* Wind::what() const’:
	Instrument5.cpp:26: warning: deprecated conversion from string constant to ‘char*’
	Instrument5.cpp: In member function ‘virtual char* Percussion::what() const’:
	Instrument5.cpp:35: warning: deprecated conversion from string constant to ‘char*’
	Instrument5.cpp: In member function ‘virtual char* Stringed::what() const’:
	Instrument5.cpp:44: warning: deprecated conversion from string constant to ‘char*’
	Instrument5.cpp: In member function ‘virtual char* Brass::what() const’:
	Instrument5.cpp:53: warning: deprecated conversion from string constant to ‘char*’
	Instrument5.cpp: In member function ‘virtual char* Woodwind::what() const’:
	Instrument5.cpp:61: warning: deprecated conversion from string constant to ‘char*’

###Solution:

Warning 1 of chapter 14 solution.

##Chapter 03 Warnings: MAC 10.9.4 (Mavericks)

###Warning 1:

	g++  -c Pitfall.cpp
	Pitfall.cpp:10:11: warning: using the result of an assignment as a condition without parentheses [-Wparentheses]
  	while(a = b) {
    	  ~~^~~
	Pitfall.cpp:10:11: note: place parentheses around the assignment to silence this warning
  	while(a = b) {
    	    ^
          (    )
	Pitfall.cpp:10:11: note: use '==' to turn this assignment into an equality comparison
  	while(a = b) {
            ^
            ==

###Solution:

 ```cpp
 	while(a == b) {
    
    }
```

##Chapter 07 Warnings: MAC 10.9.4 (Mavericks)

###Warning 1:

	g++  -c MemTest.cpp
	MemTest.cpp:44:14: warning: conversion from string literal to 'char *' is deprecated [-Wc++11-compat-deprecated-writable-strings]
    MyString s("My test string");
               ^
	MemTest.cpp:46:12: warning: conversion from string literal to 'char *' is deprecated [-Wc++11-compat-deprecated-writable-strings]
    s.concat(" some additional stuff");
             ^
	MemTest.cpp:49:13: warning: conversion from string literal to 'char *' is deprecated [-Wc++11-compat-deprecated-writable-strings]
    s2.concat("Using default constructor");
              ^

###Solution
Need to fix

##Chapter 16 Error: MAC 10.9.4 (Mavericks)

###Error 1:
	g++  -c TStack2Test.cpp
	In file included from TStack2Test.cpp:7:
	./TStack2.h:53:7: error: call to function 'require' that is neither visible in
      the template definition nor found by argument-dependent lookup
      require(p != 0, "PStack::iterator::operator->returns 0");
      ^
	TStack2Test.cpp:27:15: note: in instantiation of member function
      'Stack<std::__1::basic_string<char> >::iterator::operator->' requested
      here
    cout << it->c_str() << endl;
               ^
	./../require.h:15:13: note: 'require' should be declared prior to the call site
	inline void require(bool requirement, 
    	        ^
	1 error generated.

###Solution

 1. Remove #include "../require.h" from TStack2Test.cpp
 2. Add #include "../require.h" to TStack2.h


##Chapter 10 Warning: MAC 10.9.4 (Mavericks)
	g++  -c StaticVariablesInfunctions.cpp
	StaticVariablesInfunctions.cpp:23:11: warning: conversion from string literal to
      'char *' is deprecated [-Wc++11-compat-deprecated-writable-strings]
	char* a = "abcdefghijklmnopqrstuvwxyz";

###Solution
Need to fix

##Chapter 11 Warning: MAC 10.9.4 (Mavericks)
	g++  -c SimpleStructure.cpp
	SimpleStructure.cpp:9:7: warning: expression result unused [-Wunused-value]
  	sp->a;
  	~~  ^
	SimpleStructure.cpp:10:6: warning: expression result unused [-Wunused-value]
  	so.a;
  	~~ ^

###Solution
Need to fix

##Chapter 13 Warning: MAC 10.9.4 (Mavericks)

###Warning 1:
	g++  -c BadVoidPointerDeletion.cpp
	BadVoidPointerDeletion.cpp:22:5: warning: cannot delete expression with pointer-to-'void' type 'void *'
    delete []data; // OK, just releases storage,
    ^        ~~~~
	BadVoidPointerDeletion.cpp:31:3: warning: cannot delete expression with pointer-to-'void' type 'void *'
 	 delete b;
	  ^      ~

###Solution
Need to fix

###Warning 2:
	g++  -c PStashTest.cpp
	PStashTest.cpp:26:5: warning: cannot delete expression with pointer-to-'void' type 'void *'
    delete intStash.remove(k);
    ^      ~~~~~~~~~~~~~~~~~~

###Solution
Need to fix

###Warning 3:
	g++  -c ArrayOperatorNew.cpp
	ArrayOperatorNew.cpp:25:5: warning: cannot delete expression with pointer-to-'void' type 'void *'
    ::delete []p;
    ^          ~
	ArrayOperatorNew.cpp:34:5: warning: cannot delete expression with pointer-to-'void' type 'void *'
    ::delete []p;
    ^          ~

###Solution
Need to fix

##Chapter 15 Warning: MAC 10.9.4 (Mavericks)

###Warning 1:

	Instrument4.cpp:17:12: warning: conversion from string literal to 'char *' is deprecated [-Wc++11-compat-deprecated-writable-strings]
    return "Instrument";
           ^
	Instrument4.cpp:28:31: warning: conversion from string literal to 'char *' is deprecated [-Wc++11-compat-deprecated-writable-strings]
  	char* what() const { return "Wind"; }
                              ^
	Instrument4.cpp:37:31: warning: conversion from string literal to 'char *' is deprecated [-Wc++11-compat-deprecated-writable-strings]
  	char* what() const { return "Percussion"; }
                              ^
	Instrument4.cpp:46:31: warning: conversion from string literal to 'char *' is deprecated [-Wc++11-compat-deprecated-writable-strings]
  	char* what() const { return "Stringed"; }
                              ^
	Instrument4.cpp:55:31: warning: conversion from string literal to 'char *' is deprecated [-Wc++11-compat-deprecated-writable-strings]
  	char* what() const { return "Brass"; }
                              ^
	Instrument4.cpp:63:31: warning: conversion from string literal to 'char *' is deprecated [-Wc++11-compat-deprecated-writable-strings]
  	char* what() const { return "Woodwind"; }
                              ^
###Solution
Need to fix

###Warning 2:

	g++  -c Instrument5.cpp
	Instrument5.cpp:26:31: warning: conversion from string literal to 'char *' is deprecated [-Wc++11-compat-deprecated-writable-strings]
  	char* what() const { return "Wind"; }
                              ^
	Instrument5.cpp:35:31: warning: conversion from string literal to 'char *' is deprecated [-Wc++11-compat-deprecated-writable-strings]
  	char* what() const { return "Percussion"; }
                              ^
	Instrument5.cpp:44:31: warning: conversion from string literal to 'char *' is deprecated [-Wc++11-compat-deprecated-writable-strings]
  	char* what() const { return "Stringed"; }
                              ^
	Instrument5.cpp:53:31: warning: conversion from string literal to 'char *' is deprecated [-Wc++11-compat-deprecated-writable-strings]
  	char* what() const { return "Brass"; }
                              ^
	Instrument5.cpp:61:31: warning: conversion from string literal to 'char *' is deprecated [-Wc++11-compat-deprecated-writable-strings]
  	char* what() const { return "Woodwind"; }
                              ^

###Solution
Need to fix

##G++ Flag settings

###MAC 10.9.4 (Mavericks)
	Configured with: --prefix=/Library/Developer/CommandLineTools/usr --with-gxx-include-dir=/usr/include/c++/4.2.1

	Apple LLVM version 6.0 (clang-600.0.56) (based on LLVM 3.5svn)
	Target: x86_64-apple-darwin13.3.0
	Thread model: posix

###MAC 10.8.2 (Mountain Lion)

	Using built-in specs.
	Target: i686-apple-darwin11
	Configured with: /private/var/tmp/llvmgcc42/llvmgcc42-2336.11~182/src/configure --disable-checking --enable-werror --prefix=/Applications/Xcode.app/Contents/Developer/usr/llvm-gcc-4.2 --mandir=/share/man --enable-languages=c,objc,c++,obj-c++ --program-prefix=llvm- --program-transform-name=/^[cg][^.-]*$/s/$/-4.2/ --with-slibdir=/usr/lib --build=i686-apple-darwin11 --enable-llvm=/private/var/tmp/llvmgcc42/llvmgcc42-2336.11~182/dst-llvmCore/Developer/usr/local --program-prefix=i686-apple-darwin11- --host=x86_64-apple-darwin11 --target=i686-apple-darwin11 --with-gxx-include-dir=/usr/include/c++/4.2.1
	Thread model: posix
	gcc version 4.2.1 (Based on Apple Inc. build 5658) (LLVM build 2336.11.00)