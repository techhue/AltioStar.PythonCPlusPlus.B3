
# EXPERIMENT FOLLOWING CODE BY TYPING LINE BY LINE ON PYTHON SHELL

#   >>>>>>> MOMENT COMPLETED, RAISE YOUR HAND!!!  <<<<<<<<<

#______________________________________________________________

>>> 
>>> list1 = [10, 20, 30, 40, 50]
>>> 
>>> list2 = list1
>>> 
>>> list1
[10, 20, 30, 40, 50]
>>> list2
[10, 20, 30, 40, 50]
>>> 
>>> list1[0] = 1000
>>> 
>>> list1
[1000, 20, 30, 40, 50]
>>> list2
[1000, 20, 30, 40, 50]
>>> 
>>> list1 = ["Ding", "Dong", "Ting", "Tong"]
>>> list1
['Ding', 'Dong', 'Ting', 'Tong']
>>> list2
[1000, 20, 30, 40, 50]
>>> 
>>> 
>>> tuple1 = (10, 20, 30, 40, 50)
>>> 
>>> tuple2 = tuple1
>>> 
>>> tuple1[0] = 1000
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: 'tuple' object does not support item assignment
>>> 
>>> tuple1
(10, 20, 30, 40, 50)
>>> tuple2
(10, 20, 30, 40, 50)
>>> 
>>> tuple1 = ("Ding", "Dong", "Ting", "Tong")
>>> tuple1
('Ding', 'Dong', 'Ting', 'Tong')
>>> tuple2
(10, 20, 30, 40, 50)
>>> 
>>> 
>>> l = [10, 20, 30, 40, 50]
>>> m = [100, 200, 300]
>>> 
>>> ll = [l, m]
>>> 
>>> mm = ll
>>> 
>>> ll
[[10, 20, 30, 40, 50], [100, 200, 300]]
>>> mm
[[10, 20, 30, 40, 50], [100, 200, 300]]
>>> 
>>> l[0] = 1000
>>> 
>>> l
[1000, 20, 30, 40, 50]
>>> m
[100, 200, 300]
>>> ll
[[1000, 20, 30, 40, 50], [100, 200, 300]]
>>> 
>>> mm
[[1000, 20, 30, 40, 50], [100, 200, 300]]
>>> 
>>> l = [11, 22, 33, 44]
>>> 
>>> l
[11, 22, 33, 44]
>>> ll
[[1000, 20, 30, 40, 50], [100, 200, 300]]
>>> 
>>> 
>>> 
>>> 

#_______________________________________________________________
#_______________________________________________________________

>>> flag = true
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'true' is not defined
>>> 
>>> flag = True
>>> 
>>> if (flag):
...     print("If Block Running")
... else:
...     print("Else Block")
... 
If Block Running
>>> 
>>> 
>>> if (flag):
...     print("If Block Running")
... elif ( 90 > 100 ):
...     print("Whats Going Be Math")
... elif (100 > 90):
...     print("Lets Do Math Right")
... else:
...     print("Else Block")
... 
If Block Running
>>> 
>>> offset = 20
>>> if not sys.platform.startswith("win"):
...     offset = 10
... 
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'sys' is not defined
>>> 
>>> 
>>> import sys
>>> 
>>> offset = 20
>>> if not sys.platform.startswith("win"):
...     offset = 10
... 
>>> offset
10
>>> sys.platform
'linux2'
>>> 
>>> 
>>> offset = 20 if sys.platform.startswith("win") else 10
>>> 
>>> offset
10
>>> 


#_______________________________________________________________

Python 3.8.10 (default, Sep 28 2021, 16:10:42) 
[GCC 9.3.0] on linux
Type "help", "copyright", "credits" or "license" for more information.
>>> 
>>> 
>>> math = [90, 80, 60, 77, 66, 78, 10, 30]
>>> science = [ 90, 50, 60, 40, 80, 99]
>>> 
>>> marks = zip(math, science)
>>> 
>>> type(marks)
<class 'zip'>
>>> 
>>> marks
<zip object at 0x7f2aae593800>
>>> 
>>> for mark in marks:
...     print(mark)
... 
(90, 90)
(80, 50)
(60, 60)
(77, 40)
(66, 80)
(78, 99)
>>> 
>>> 
>>> r = range(0, 10)
>>> 
>>> r
range(0, 10)
>>> 
>>> 
>>> type(r)
<class 'range'>
>>> 
>>> for item in r:
...     print(item)
... 
0
1
2
3
4
5
6
7
8
9
>>> rr = range(4, 10)
>>> rr
range(4, 10)
>>> for item in rr:
...     print(item)
... 
4
5
6
7
8
9
>>> rrr = range(4, 10, 2)
>>> rr
range(4, 10)
>>> rrrr
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'rrrr' is not defined
>>> rrr
range(4, 10, 2)
>>> 
>>> for item in rrr:
...     print(item)
... 
4
6
8
>>> 
>>> 

#_______________________________________________________________




Python 3.8.10 (default, Sep 28 2021, 16:10:42) 
[GCC 9.3.0] on linux
Type "help", "copyright", "credits" or "license" for more information.
>>> 
>>> 
>>> math = [90, 80, 60, 77, 66, 78, 10, 30]
>>> science = [ 90, 50, 60, 40, 80, 99]
>>> 
>>> marks = zip(math, science)
>>> 
>>> type(marks)
<class 'zip'>
>>> 
>>> marks
<zip object at 0x7f2aae593800>
>>> 
>>> for mark in marks:
...     print(mark)
... 
(90, 90)
(80, 50)
(60, 60)
(77, 40)
(66, 80)
(78, 99)
>>> 
>>> 
>>> r = range(0, 10)
>>> 
>>> r
range(0, 10)
>>> 
>>> 
>>> type(r)
<class 'range'>
>>> 
>>> for item in r:
...     print(item)
... 
0
1
2
3
4
5
6
7
8
9
>>> rr = range(4, 10)
>>> rr
range(4, 10)
>>> for item in rr:
...     print(item)
... 
4
5
6
7
8
9
>>> rrr = range(4, 10, 2)
>>> rr
range(4, 10)
>>> rrrr
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'rrrr' is not defined
>>> rrr
range(4, 10, 2)
>>> 
>>> for item in rrr:
...     print(item)
... 
4
6
8
>>> 
>>> 
>>> 
>>> numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
>>> 
>>> squares = []
>>> 
>>> for n in numbers:
...     squares.append(n * n)
... 
>>> squares
[1, 4, 9, 16, 25, 36, 49, 64, 81, 100]
>>> 
>>> 
>>> 
>>> squaresAgain = [ n * n for n in numbers ]
>>> 
>>> squaresAgain
[1, 4, 9, 16, 25, 36, 49, 64, 81, 100]
>>> 
>>> evenSquares = [ n * n for n in numbers if n % 2 == 0 ]
>>> 
>>> evenSquares
[4, 16, 36, 64, 100]
>>> 
>>> squaresDict = dict()
>>> 
>>> for n in numbers:
...     squaresDict[n] = n * n
... 
>>> squaresDict
{1: 1, 2: 4, 3: 9, 4: 16, 5: 25, 6: 36, 7: 49, 8: 64, 9: 81, 10: 100}
>>> 
>>> squaresDictAgain = { n : n * n for n in numbers }
>>> 
>>> squaresDictAgain
{1: 1, 2: 4, 3: 9, 4: 16, 5: 25, 6: 36, 7: 49, 8: 64, 9: 81, 10: 100}
>>> 
>>> values = range(1, 11)
>>> values
range(1, 11)
>>> 
>>> for in in values:
  File "<stdin>", line 1
    for in in values:
        ^
SyntaxError: invalid syntax
>>> for in in values:
  File "<stdin>", line 1
    for in in values:
        ^
SyntaxError: invalid syntax
>>> for n in values:
...     print(n)
... 
1
2
3
4
5
6
7
8
9
10
>>> 
>>> for n in values:
...     print(n * n)
... 
1
4
9
16
25
36
49
64
81
100
>>> for n in values:
...     print(" For n = {0} Square = {1}".format(n, n * n) )
... 
 For n = 1 Square = 1
 For n = 2 Square = 4
 For n = 3 Square = 9
 For n = 4 Square = 16
 For n = 5 Square = 25
 For n = 6 Square = 36
 For n = 7 Square = 49
 For n = 8 Square = 64
 For n = 9 Square = 81
 For n = 10 Square = 100
>>> 
>>> 
>>> 
>>> squaresGenerator = ( n * n for n in numbers )
>>> 
>>> squaresGenerator
<generator object <genexpr> at 0x7f2aad154190>
>>> 
>>> for square in squaresGenerator:
...     print(squaure)
... 
Traceback (most recent call last):
  File "<stdin>", line 2, in <module>
NameError: name 'squaure' is not defined
>>> 
>>> for n in squaresGenerator:
...     print(n)
... 
4
9
16
25
36
49
64
81
100
>>> 

#_______________________________________________________________
#_______________________________________________________________

Python 3.8.10 (default, Sep 28 2021, 16:10:42) 
[GCC 9.3.0] on linux
Type "help", "copyright", "credits" or "license" for more information.
>>> 
>>> 
>>> 
>>> import sys
>>> 
>>> dir(sys)
['__breakpointhook__', '__displayhook__', '__doc__', '__excepthook__', '__interactivehook__', '__loader__', '__name__', '__package__', '__spec__', '__stderr__', '__stdin__', '__stdout__', '__unraisablehook__', '_base_executable', '_clear_type_cache', '_current_frames', '_debugmallocstats', '_framework', '_getframe', '_git', '_home', '_xoptions', 'abiflags', 'addaudithook', 'api_version', 'argv', 'audit', 'base_exec_prefix', 'base_prefix', 'breakpointhook', 'builtin_module_names', 'byteorder', 'call_tracing', 'callstats', 'copyright', 'displayhook', 'dont_write_bytecode', 'exc_info', 'excepthook', 'exec_prefix', 'executable', 'exit', 'flags', 'float_info', 'float_repr_style', 'get_asyncgen_hooks', 'get_coroutine_origin_tracking_depth', 'getallocatedblocks', 'getcheckinterval', 'getdefaultencoding', 'getdlopenflags', 'getfilesystemencodeerrors', 'getfilesystemencoding', 'getprofile', 'getrecursionlimit', 'getrefcount', 'getsizeof', 'getswitchinterval', 'gettrace', 'hash_info', 'hexversion', 'implementation', 'int_info', 'intern', 'is_finalizing', 'maxsize', 'maxunicode', 'meta_path', 'modules', 'path', 'path_hooks', 'path_importer_cache', 'platform', 'prefix', 'ps1', 'ps2', 'pycache_prefix', 'set_asyncgen_hooks', 'set_coroutine_origin_tracking_depth', 'setcheckinterval', 'setdlopenflags', 'setprofile', 'setrecursionlimit', 'setswitchinterval', 'settrace', 'stderr', 'stdin', 'stdout', 'thread_info', 'unraisablehook', 'version', 'version_info', 'warnoptions']
>>> 
>>> sys.platform
'linux'
>>> 
>>> sys.version
'3.8.10 (default, Sep 28 2021, 16:10:42) \n[GCC 9.3.0]'
>>> 
>>> greeting = "Hello World!!!!"
>>> offset = 20 if ( len(greeting) > 10 )  else 10
>>> print(offset) # 10
20
>>> 
>>> 
>>> offset = 20
>>> if not ( len(greeting) > 10 )
  File "<stdin>", line 1
    if not ( len(greeting) > 10 )
                                ^
SyntaxError: invalid syntax
>>>     offset = 10
  File "<stdin>", line 1
    offset = 10
    ^
IndentationError: unexpected indent
>>> print(offset) # 10
20
>>> 
>>> offset = 20
>>> if not ( len(greeting) > 10 )
  File "<stdin>", line 1
    if not ( len(greeting) > 10 )
                                ^
SyntaxError: invalid syntax
>>>     offset = 10
  File "<stdin>", line 1
    offset = 10
    ^
IndentationError: unexpected indent
>>> print(offset) # 10
20
>>> 
>>> 
>>> offset = 20
>>> if not ( len(greeting) > 10 ):
...     offset = 10
... print(offset) # 10
  File "<stdin>", line 3
    print(offset) # 10
    ^
SyntaxError: invalid syntax
>>> 
>>> 
>>> offset = 20
>>> if not ( len(greeting) > 10 ):
...     offset = 10
... 
>>> print(offset) # 10
20
>>> 
>>> 
>>> greeting = "Hello World!!!!"
>>> offset = 20 if ( len(greeting) > 10 )  else 10
>>> print(offset) # 10
20
>>> 
>>> mathMarks     = [90, 80, 60, 77, 66, 78, 10, 30]
>>> scienceMarks  = [90, 50, 60, 40, 80, 99]
>>> 
>>> 
>>> marks = zip(mathMarks, scienceMarks)
>>> 
>>> type(marks_
... 
KeyboardInterrupt
>>> 
>>> type(marks)
<class 'zip'>
>>> 
>>> marks
<zip object at 0x7f5016d56b80>
>>> 
>>> for mark in marks:
...     print(mark)
... 
(90, 90)
(80, 50)
(60, 60)
(77, 40)
(66, 80)
(78, 99)
>>> 
>>> help(zip)

>>> help(zip)

>>> 
>>> 
>>> list(zip('abcdefg', range(3), range(4)))
[('a', 0, 0), ('b', 1, 1), ('c', 2, 2)]
>>> 
>>> 
>>> 
>>> zip('abcdefg', range(3), range(4))
<zip object at 0x7f5016d6b240>
>>> 
>>> list(zip('abcdefg', range(3), range(4)))
[('a', 0, 0), ('b', 1, 1), ('c', 2, 2)]
>>> 
>>> 
>>> 
>>> r = range(0, 10)
>>> 
>>> r
range(0, 10)
>>> 
>>> type(r)
<class 'range'>
>>> 
>>> for n in r:
...     print(n)
... 
0
1
2
3
4
5
6
7
8
9
>>> 
>>> r = range(4, 12)
>>> 
>>> r
range(4, 12)
>>> 
>>> type(r)
<class 'range'>
>>> 
>>> for number in r:
...     print(number)
... 
4
5
6
7
8
9
10
11
>>> 
>>> 
>>> numbers = list( range(4, 12) )
>>> 
>>> numbers
[4, 5, 6, 7, 8, 9, 10, 11]
>>> 
>>> numbersAgain = tuple( range(4, 12) )
>>> 
>>> numbersAgain
(4, 5, 6, 7, 8, 9, 10, 11)
>>> 
>>> type(numbersAgain)
<class 'tuple'>
>>> 
>>> type(numbers)
<class 'list'>
>>> 
>>> 
>>> evenRange = range(0, 10, 2)
>>> 
>>> evenRange
range(0, 10, 2)
>>> 
>>> for even in evenRange:
...     print(even)
... 
0
2
4
6
8
>>> 
>>> 
>>> evenNumbers = list( evenRange )
>>> 
>>> evenNumbers
[0, 2, 4, 6, 8]
>>> 
>>> 

#_______________________________________________________________
#_______________________________________________________________


#_______________________________________________________________
#_______________________________________________________________


#_______________________________________________________________
#_______________________________________________________________



