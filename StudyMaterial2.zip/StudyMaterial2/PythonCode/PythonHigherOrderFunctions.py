
# EXPERIMENT FOLLOWING CODE BY TYPING LINE BY LINE ON PYTHON SHELL

#   >>>>>>> MOMENT COMPLETED, RAISE YOUR HAND!!!  <<<<<<<<<

#______________________________________________________________


#__________________________________________________________________
#				FUNCTION IS AN OBJECT IN PYTHON
#__________________________________________________________________


# Following Functions Take Two Arguments
def sum(a, b):
	return a + b

def sub(a, b):
	return a - b

def mul(a, b):
	return a * b 


# Function Is Also An Object In Python
# 		Hence It Can Be Assigned To Variable 
#			Like Any Other Python Object
something = sum

sum(10, 20) # 30
something(10, 20) # 30

print( type(sum) ) 		 # <class 'function'>
print( type(something) ) # <class 'function'>

def multiply(a, b, c, d):
    return a * b * c * d

multiply(10, 20, 2, 3) # 1200
somethingAgain = multiply
somethingAgain(10, 20, 2, 3) # 1200

print( type(multiply) ) 			# <class 'function'>
print( type(somethingAgain) ) 		# <class 'function'>

#__________________________________________________________________
# Higher Order Functions
# 		Functions Which Takes Function As Argument
#		Functions Which Returns Function
#		Functions Takes Function As Argument And Retuns Function
#__________________________________________________________________


#_________________________________________________
# Higher Order Functions
# 		Function Which Takes Function As Argument
# Hence calculator Function is Higher Order Function
#_________________________________________________

def calculator(a, b, operation):
	return operation(a, b)

# Passing Function sum As Argument To calculator Function
result = calculator(30, 20, sum)
print(result) # 50

# Passing Function sub As Argument To calculator Function
result = calculator(30, 20, sub)
print(result) # 10

# Passing Function mul As Argument To calculator Function
result = calculator(30, 20, mul)
print(result) # 600



#_________________________________________________
# Higher Order Functions
# 		Functions Which Can Return Function
# Hence chooseStep is Higher Order Function
#_________________________________________________


def chooseStep(forward):
	# Local Function
	#		Function Defined Inside A Function	
	def moveBackward(steps):
		steps = steps - 1
		return steps

	# Local Function
	def moveForward(steps):
		steps = steps + 1
		return steps
	if(forward == True):
		return moveForward   # Returning Function
	else:
		return moveBackward  # Returning Function

doMagic = chooseStep(True)
print ( doMagic(10) ) # 11
print ( doMagic(11) ) # 12

doMagic = chooseStep(False)
print ( doMagic(10) ) # 9
print ( doMagic(11) ) # 10



#_________________________________________________
# Higher Order Functions
#		Functions Takes Function As Argument And Retuns Function
#_________________________________________________



def chooseStep(forward, changeSteps):
	# Local Function
	#		Function Defined Inside A Function	
	def moveBackward(steps):
		steps = steps - changeSteps()
		return steps
		
	# Local Function
	def moveForward(steps):
		steps = steps + changeSteps()
		return steps

	if(forward == True):
		return moveForward   # Returning Function
	else:
		return moveBackward  # Returning Function

def moveTwoSteps():
	return 2

def moveThreeSteps():
	return 3

def moveFiveSteps():
	return 5

doMagic = chooseStep(True, moveTwoSteps)
print ( doMagic(10) ) 
print ( doMagic(11) ) 

doMagic = chooseStep(True, moveThreeSteps)
print ( doMagic(10) ) 
print ( doMagic(11) ) 

doMagic = chooseStep(True, moveFiveSteps)
print ( doMagic(10) )
print ( doMagic(11) ) 

doMagic = chooseStep(False, moveTwoSteps)
print ( doMagic(10) ) 
print ( doMagic(11) ) 

doMagic = chooseStep(False, moveThreeSteps)
print ( doMagic(10) ) 
print ( doMagic(11) )

doMagic = chooseStep(False, moveFiveSteps)
print ( doMagic(10) )
print ( doMagic(11) )

#_________________________________________________

