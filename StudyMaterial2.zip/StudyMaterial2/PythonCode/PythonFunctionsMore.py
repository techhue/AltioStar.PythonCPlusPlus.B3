
# EXPERIMENT FOLLOWING CODE BY TYPING LINE BY LINE ON PYTHON SHELL

#   >>>>>>> MOMENT COMPLETED, RAISE YOUR HAND!!!  <<<<<<<<<

#______________________________________________________________


# 09.1 Basic function definitions


def fact(n): 
    """Return the factorial of the given number."""            #1
    r = 1
    while n > 0:
        r = r * n
        n = n - 1
    return r                                      #2

fact(4)            #24
x = fact(4)         
x  # 24


# 09.2. Positional parameters

def power(x, y):
    r = 1
    while y > 0:
        r = r * x
        y = y - 1
    return r

power(3, 3) # 27
power(3)
# Gives Following TypeError
# Traceback (most recent call last):
#   File "<stdin>", line 1, in <module>
# TypeError: power() missing 1 required positional argument: 'y'

# Function With Default Arguments
def power(x, y=2):
    r = 1
    while y > 0:
        r = r * x
        y = y - 1
    return r

power(3, 3) # 27
power(3) # 9

power(2, 3) # 8
power(3, 2) # 9

# Named Arguments Can Change Order
power(y=2, x=3) #9

# 09.2.2 Passing arguments by parameter name

# def list_file_info(size=False, create_date=False, mod_date=False, ...):
# #    ...get file names...
#     if size:
#         # code to get file sizes goes here
#     if create_date:
#         # code to get create dates goes here
#     # do any other stuff desired
    
#     return fileinfostructure

# fileinfo = list_file_info(size=True, mod_date=True)


# 09.2.3 Variable numbers of arguments

def maximum( *numbers ):
    if len(numbers) == 0:
        return None
    else:
        maxnum = numbers[0]
        for n in numbers[1:]:
            if n > maxnum:
                maxnum = n
        return maxnum

maximum(3, 2, 8)        # 8
maximum(1, 5, 9, -2, 2) # 9


# Function Taking Variable Number Of Key Value Arguments
def example_fun(x, y, **other):
    print("x: {0}, y: {1}, keys in 'other': {2}".format(x, 
          y, list(other.keys())))
    other_total = 0
    for k in other.keys():
        other_total = other_total + other[k]

    print("The total of values in 'other' is {0}".format(other_total))


example_fun(2, y="1")
example_fun(2, y="1", foo=3)
example_fun(2, y="1", foo=3, bar=4)

# x: 2, y: 1, keys in 'other': ['foo', 'bar']
# The total of values in 'other' is 7

# 09.3 9.3	Mutable objects as arguments

def f(n, list1, list2):
   n = 10            # n Is Local To Function
   list1.append(3)   # list1 Changes Will Be Reflected Outside
   list2 = [4, 5, 6] # list2 Changes Are Local
   n = n + 1

x = 5
y = [1, 2]
z = [4, 5]
f(x, y, z)
x, y, z # (5, [1, 2, 3], [4, 5])


# 09.4 9.4  Local, nonlocal, and global variables

def fact(n):
    """Return the factorial of the given number."""
    r = 1  # n and r Are Local
    while n > 0:
        r = r * n
        n = n - 1
    return r # Returning r Value To Outside World

def funWthGlobal():
    global a  # Accessing Global Variable a
    a = 1     # Chaning Global Variable a
    b = 2

a = "one"
b = "two"
funWthGlobal()
a # 1    Global Variable Value Changed Inside Function
b # 'two'


