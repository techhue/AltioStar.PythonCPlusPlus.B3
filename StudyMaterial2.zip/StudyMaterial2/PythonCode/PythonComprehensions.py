

# EXPERIMENT FOLLOWING CODE BY TYPING LINE BY LINE ON PYTHON SHELL

#   >>>>MOMENT COMPLETED, RAISE YOUR HAND!!!  <<<<<<<<<

#_______________________________________________________________
#					LIST COMPREHENSION
#_______________________________________________________________


# Code To Generate Squares Of Numbers

# Following CODE-LC11 and CODE-LC12 Are Logically Same
#CODE-LC11
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
squares = []
for nnumber in numbers:
    squares.append( number * number )

print(numbers) # [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
print(squares) # [1, 4, 9, 16, 25, 36, 49, 64, 81, 100]

#CODE-LC12
# List Compreshension
squaresAgain = [ number * number for number in numbers ]
print(squaresAgain) # [1, 4, 9, 16, 25, 36, 49, 64, 81, 100]


# Following CODE-LC21 and CODE-LC22 Are Logically Same
#CODE-LC21
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
evenSquares = []
for number in numbers:
	if ( number % 2 == 0 ):
		evenSquares.append( number * number )

#CODE-LC22
# List Comprehension
evenSquares = [ number * number for number in numbers if number % 2 == 0 ]
print(evenSquares) # [4, 16, 36, 64, 100]


#_______________________________________________________________
#				DICTIONARY COMPREHENSION
#_______________________________________________________________

# Following CODE-DC11 and CODE-DC12 Are Logically Same

#CODE-DC11
squaresDict = dict()
for number in numbers:
    squaresDict[number] = number * number

print(squaresDict) # {1: 1, 2: 4, 3: 9, 4: 16, 5: 25, 6: 36, 7: 49, 8: 64, 9: 81, 10: 100}

#CODE-DC12
# Dictionary Comprehension
squaresDictAgain = { number : number * number for number in numbers }
print(squaresDictAgain) # {1: 1, 2: 4, 3: 9, 4: 16, 5: 25, 6: 36, 7: 49, 8: 64, 9: 81, 10: 100}



#_______________________________________________________________
#				GENERATOR EXPRESSION
#_______________________________________________________________


rangeValues = range(1, 6)
rangeValues # range(1, 6)

# Querying Range Object
# It Will Yield/Give Values On Demand
for number in rangeValues:
    print(number)

# Output Will Be
# 1
# 2
# 3
# 4
# 5

# Querying Range Object
# It Will Yield/Give Values On Demand
for number in rangeValues:
    print(number * number)

# Output Will Be
# 1
# 4
# 9
# 16
# 25

# Querying Range Object
# It Will Yield/Give Values On Demand
for number in rangeValues:
    print(" For n = {0} Square = {1}".format(n, n * n) )

 # Output Will Be
 # For n = 1 Square = 1
 # For n = 2 Square = 4
 # For n = 3 Square = 9
 # For n = 4 Square = 16
 # For n = 5 Square = 25


numbers = [1, 2, 3, 4, 5]

# Generator Expression
squaresGenerator = ( number * number for number in numbers )
print(squaresGenerator) # <generator object <genexpr> at 0x7f2aad154190>

# Querying Generator Expression
# It Will Yield/Give Values On Demand
for square in squaresGenerator:
    print(square)

# Output Will Be
# 1
# 4
# 9
# 16
# 25


#_______________________________________________________________
#_______________________________________________________________


#_______________________________________________________________
#_______________________________________________________________


#_______________________________________________________________
#_______________________________________________________________


#_______________________________________________________________
#_______________________________________________________________



