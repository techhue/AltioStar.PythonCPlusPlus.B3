
# EXPERIMENT FOLLOWING CODE BY TYPING LINE BY LINE ON PYTHON SHELL

#   >>>>MOMENT COMPLETED, RAISE YOUR HAND!!!  <<<<<<<<<

#______________________________________________________________


list1 = [10, 20, 30, 40, 50]

list2 = list1  # Reference or Address Assignment

print(list1)  # [10, 20, 30, 40, 50]
print(list2)  # [10, 20, 30, 40, 50]

list1[0] = 1000

# list1 and list2 Both Are Pointing To Same List Object
print(list1)  # [1000, 20, 30, 40, 50]
print(list2)  # [1000, 20, 30, 40, 50]

# list1 Pointing To New List Obejct
list1 = ["Ding", "Dong", "Ting", "Tong"]

print(list1) # ['Ding', 'Dong', 'Ting', 'Tong']

# list2 Still Pointing To Old List Obejct
print(list2)  # [1000, 20, 30, 40, 50]


tuple1 = (10, 20, 30, 40, 50)

tuple2 = tuple1 # Reference or Address Assignment

tuple1[0] = 1000
# Traceback (most recent call last):
#   File "<stdin>", line 1, in <module>
# TypeError: 'tuple' object does not support item assignment


print(tuple1) # (10, 20, 30, 40, 50)
print(tuple2) # (10, 20, 30, 40, 50)

# tuple1 Pointing To New Tuple Obejct
tuple1 = ("Ding", "Dong", "Ting", "Tong")
print(tuple1) # ('Ding', 'Dong', 'Ting', 'Tong')

# tuple2 Pointing To New Tuple Obejct
print(tuple2) # (10, 20, 30, 40, 50)


# l Stores Reference Of List Object Defined On RHS
l = [10, 20, 30, 40, 50]

# m Stores Reference Of List Object Defined On RHS
m = [100, 200, 300]

# ll Stores Reference Of List Objects Pointed By l and m
ll = [l, m]

# Reference or Address Assignment
# i.e. mm And ll Both Points To Same List Objects
mm = ll

print(ll) # [[10, 20, 30, 40, 50], [100, 200, 300]]
print(mm) # [[10, 20, 30, 40, 50], [100, 200, 300]]

l[0] = 1000

print(l)  # [1000, 20, 30, 40, 50]
print(m)  # [100, 200, 300]
print(ll) # [[1000, 20, 30, 40, 50], [100, 200, 300]]

print(mm) # [[1000, 20, 30, 40, 50], [100, 200, 300]]

# l Pointing To New List Object Created On RHS
l = [11, 22, 33, 44]

print(l) #  [11, 22, 33, 44]
print(ll) # [[1000, 20, 30, 40, 50], [100, 200, 300]]


