# PLEASE RAISE YOUR HAND MOMENT YOU ARE DONE!!!


#__________________________________________________________-
#                    PYTHON BASIC TYPES
# integer, float, string and boolean
#	Python Types : int, float, str and bool
#__________________________________________________________-


a = 10
b = 20
c = a + b 		# Integer Aritematic
print(c)
print(type(a))
print(type(b))
print(type(c))

f1 = 10.90
f2 = 20.01
f3 = f1 + f2  	# Floating Point Artitmatic
print(f3)
print(type(f1))
print(type(f2))
print(type(f3))

s1 = "Ding Dong"
s2 = 'Ting Tong'
s3 = s1 + s2 	# String Concatenation
print(s3)
print(type(s1))
print(type(s2))
print(type(s3))

flag = True
flagAgain = False
flagResult = flag and flagAgain # Boolean Logical Operation
print(flagResult)
print(type(flag))
print(type(flagAgain))
print(type(flagResult))


#__________________________________________________________-
#                    PYTHON STRING TYPES
#	Python Type : str
#__________________________________________________________-


greeting = "Good Morning!"
greetingAgain = 'Vankaaam!'

print(greeting)
print(greetingAgain)

length = len(greeting)

print(greeting[0])
print(greeting[1])
print(greeting[2])
print(greeting[3])
print(greeting[4])
print(greeting[ length - 1])
print(greeting[ length - 2])
print(greeting[ length - 3])


print(greeting[-1])
print(greeting[-2])
print(greeting[-3])
print(greeting[-4])
print(greeting[-5])
print(greeting[ -length])
print(greeting[ -length + 1] )
print(greeting[ -length + 2] )


#__________________________________________________________-
#                    PYTHON STRING TYPES
#	Python Type : str
# 	Experiment Done On Python Shell
#__________________________________________________________-


greeting = "Good Morning!"
greetingAgain = 'Vankaaam!'


print(greeting)
Good Morning!
print(greetingAgain)
Vankaaam!

length = len(greeting)
print(length)

greeting[0]
greeting[1]
greeting[2]
greeting[3]
greeting[4]
greeting[4]

greeting[5]
greeting[length - 1]
greeting[length]
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
IndexError: string index out of range

greeting[length - 2]
greeting[length - 3]
greeting[-1]
greeting[length - 1]
greeting[-2]
greeting[length - 2]
greeting[-3]
greeting[length - 3]
greeting[-4]
greeting[length - 4]
greeting[-length]
greeting[-length + 1]
greeting[-length + 3]


>>> greetingNew = greeting + greetingAgain
>>> 
>>> type(greetingNew)
<class 'str'>
>>> 
>>> print(greetingNew)
Good Morning!Vankaaam!
>>> 
>>> greetingNew = greeting + ' ' + greetingAgain
>>> 
>>> print(greetingNew)
Good Morning! Vankaaam!
>>> 
>>> greetingNew = greeting + ' ' + greetingAgain + '!!!'
>>> 
>>> print(greetingNew)
Good Morning! Vankaaam!!!!


>>> greetingMultiple = greeting * 4
>>> 
>>> greetingMultiple
'Good Morning!Good Morning!Good Morning!Good Morning!'
>>> 
>>> 
>>> dir(greeting)
['__add__', '__class__', '__contains__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__getnewargs__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__mod__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__rmod__', '__rmul__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__', 'capitalize', 'casefold', 'center', 'count', 'encode', 'endswith', 'expandtabs', 'find', 'format', 'format_map', 'index', 'isalnum', 'isalpha', 'isascii', 'isdecimal', 'isdigit', 'isidentifier', 'islower', 'isnumeric', 'isprintable', 'isspace', 'istitle', 'isupper', 'join', 'ljust', 'lower', 'lstrip', 'maketrans', 'partition', 'replace', 'rfind', 'rindex', 'rjust', 'rpartition', 'rsplit', 'rstrip', 'split', 'splitlines', 'startswith', 'strip', 'swapcase', 'title', 'translate', 'upper', 'zfill']
>>> 
>>> 
>>> type(greeting)
<class 'str'>
>>> 
>>> dir(str(
... 
KeyboardInterrupt
>>> dir(str)
['__add__', '__class__', '__contains__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__getnewargs__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__mod__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__rmod__', '__rmul__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__', 'capitalize', 'casefold', 'center', 'count', 'encode', 'endswith', 'expandtabs', 'find', 'format', 'format_map', 'index', 'isalnum', 'isalpha', 'isascii', 'isdecimal', 'isdigit', 'isidentifier', 'islower', 'isnumeric', 'isprintable', 'isspace', 'istitle', 'isupper', 'join', 'ljust', 'lower', 'lstrip', 'maketrans', 'partition', 'replace', 'rfind', 'rindex', 'rjust', 'rpartition', 'rsplit', 'rstrip', 'split', 'splitlines', 'startswith', 'strip', 'swapcase', 'title', 'translate', 'upper', 'zfill']
>>> 
>>> 
>>> greeting.lower()
'good morning!'
>>> 
>>> greeting.upper()
'GOOD MORNING!'
>>> 
>>> greeting.title()
'Good Morning!'
>>> 
>>> greeting.split()
['Good', 'Morning!']
>>> 
>>> 
>>> greeting.endswith('!')
True
>>> 
>>> greeting.endswith('#')
False
>>> 
>>> someString = "Ding Dong 
  File "<stdin>", line 1
    someString = "Ding Dong 
                           ^
SyntaxError: EOL while scanning string literal
>>> 
>>> 
>>> someString = "Ding Dong\nTing\tTong    Ping     Pong     Zing Zong  \n TingTing"
>>> 
>>> words = someString.split()
>>> 
>>> words
['Ding', 'Dong', 'Ting', 'Tong', 'Ping', 'Pong', 'Zing', 'Zong', 'TingTing']
>>> 
>>> 
>>> words = someString.split('\n')
>>> 
>>> words
['Ding Dong', 'Ting\tTong    Ping     Pong     Zing Zong  ', ' TingTing']
>>> 
>>> 
>>> words = someString.split('\t')
>>> 
>>> words
['Ding Dong\nTing', 'Tong    Ping     Pong     Zing Zong  \n TingTing']
>>> 
>>> 
>>> words = someString.split('g')
>>> 
>>> words
['Din', ' Don', '\nTin', '\tTon', '    Pin', '     Pon', '     Zin', ' Zon', '  \n Tin', 'Tin', '']
>>> 
>>> 
>>> someStringAgain = "     Ding Dong\nTing\tTong    Ping     Pong     Zing Zong  \n TingTing       "
>>> 
>>> someStringAgain
'     Ding Dong\nTing\tTong    Ping     Pong     Zing Zong  \n TingTing       '
>>> 
>>> someStringAgain.strip()
'Ding Dong\nTing\tTong    Ping     Pong     Zing Zong  \n TingTing'
>>> 
>>> someStringAgain.lstrip()
'Ding Dong\nTing\tTong    Ping     Pong     Zing Zong  \n TingTing       '
>>> 
>>> someStringAgain.rstrip()
'     Ding Dong\nTing\tTong    Ping     Pong     Zing Zong  \n TingTing'


>>> greeting
'Good Morning!'
>>> 
>>> for character in greeting:
...     print(character)
... 
G
o
o
d
 
M
o
r
n
i
n
g
!
>>> 
>>> 
>>> greeting
'Good Morning!'
>>> 
>>> greeting[0: 7]
'Good Mo'
>>> 
>>> greeting[0: 9]
'Good Morn'
>>> 
>>> greeting[2: 9]
'od Morn'
>>> 
>>> 
>>> greeting[2: 9: 2]
'o on'
>>> 
>>> 
>>> greeting[ : :]
'Good Morning!'
>>> 
>>> greeting[ 0: len(greeting) : 1]
'Good Morning!'
>>> 
>>> 
>>> greeting[ : : -1 ]
'!gninroM dooG'
>>> 
>>> greeting[ -1: -len(greeting) : -1]
'!gninroM doo'
>>> 
>>> 
>>> greeting[ : :]
'Good Morning!'
>>> 
>>> greeting[ : : 2]
'Go onn!'
>>> greeting[ : : 3]
'Gdoi!'
>>> greeting[ : : 4]
'G n!'
>>> 
>>> 


>>> dir(str)
['__add__', '__class__', '__contains__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__getnewargs__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__mod__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__rmod__', '__rmul__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__', 'capitalize', 'casefold', 'center', 'count', 'encode', 'endswith', 'expandtabs', 'find', 'format', 'format_map', 'index', 'isalnum', 'isalpha', 'isascii', 'isdecimal', 'isdigit', 'isidentifier', 'islower', 'isnumeric', 'isprintable', 'isspace', 'istitle', 'isupper', 'join', 'ljust', 'lower', 'lstrip', 'maketrans', 'partition', 'replace', 'rfind', 'rindex', 'rjust', 'rpartition', 'rsplit', 'rstrip', 'split', 'splitlines', 'startswith', 'strip', 'swapcase', 'title', 'translate', 'upper', 'zfill']
>>> 
>>> 
>>> dir(greeting)
['__add__', '__class__', '__contains__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__getnewargs__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__mod__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__rmod__', '__rmul__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__', 'capitalize', 'casefold', 'center', 'count', 'encode', 'endswith', 'expandtabs', 'find', 'format', 'format_map', 'index', 'isalnum', 'isalpha', 'isascii', 'isdecimal', 'isdigit', 'isidentifier', 'islower', 'isnumeric', 'isprintable', 'isspace', 'istitle', 'isupper', 'join', 'ljust', 'lower', 'lstrip', 'maketrans', 'partition', 'replace', 'rfind', 'rindex', 'rjust', 'rpartition', 'rsplit', 'rstrip', 'split', 'splitlines', 'startswith', 'strip', 'swapcase', 'title', 'translate', 'upper', 'zfill']
>>> 
>>> help(greeting.upper)

>>> help(greeting.upper)

>>> 
>>> 
>>> help(greeting.split)

