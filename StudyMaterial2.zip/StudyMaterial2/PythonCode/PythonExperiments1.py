# PythonExperiments1.py

>>> something
('Ding', 'Dong', 100, 199, (1000, 2000), 90.89)
>>> 
>>> something[1]
'Dong'
>>> something[2]
100
>>> 
>>> something[3]
199
>>> 
>>> something[4]
(1000, 2000)
>>> 
>>> something[4][0]
1000
>>> 
>>> something[4][1]
2000
>>> 
>>> 
>>> something[4][-3]
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
IndexError: tuple index out of range
>>> 
>>> something[4]
(1000, 2000)
>>> 
>>> something[4][-2]
1000
>>> something[4][-1]
2000
>>> 
>>> something[4][-3]
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
IndexError: tuple index out of range
>>> 
>>> 
>>> 
>>> something
('Ding', 'Dong', 100, 199, (1000, 2000), 90.89)
>>> 
>>> 
>>> something[5]
90.89
>>> 
>>> something[6]
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
IndexError: tuple index out of range
>>> 
>>> 
>>> something[-6]
'Ding'
>>> 
>>> 
>>> 
>>> point
(10, 20)
>>> 
>>> point[0] = 100
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: 'tuple' object does not support item assignment
>>> 
>>> 
>>> 
>>> hello
'Hello World!'
>>> 
>>> hello[0]
'H'
>>> 
>>> hello[0] = "G"
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: 'str' object does not support item assignment
>>> 
>>> 
>>> 
>>> 
>>> 
>>> uple1 = (10, 20, 30)
>>> tuple2 = (100, 200)
>>> tuple1 = (10, 20, 30)
>>> 
>>> 
>>> tuple1
(10, 20, 30)
>>> tuple2
(100, 200)
>>> 
>>> tuple3 = tuple1 + tuple2
>>> 
>>> tuple3
(10, 20, 30, 100, 200)
>>> 
>>> tuple4 = ( tuple1, tuple2, greeting, something)
>>> 
>>> 
>>> tuple4
((10, 20, 30), (100, 200), 'Good Morning!', ('Ding', 'Dong', 100, 199, (1000, 2000), 90.89))
>>> 
>>> 
>>> tuple4[0]
(10, 20, 30)
>>> tuple4[1]
(100, 200)
>>> 
>>> 
>>> tuple4[2]
'Good Morning!'
>>> tuple4[3]
('Ding', 'Dong', 100, 199, (1000, 2000), 90.89)
>>> 
>>> 
>>> tuple4[0][1]
20
>>> 
>>> tuple4[1][1]
200
>>> 
>>> tuple4[2][3]
'd'
>>> 
>>> 
>>> tuple4[4][1][1]
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
IndexError: tuple index out of range
>>> 
>>> 
>>> 
>>> tuple4[3][1][1]
'o'
>>> 
>>> tuple4[3][1][0]
'D'
>>> 
>>> tuple4[3][1][1]
'o'
>>> tuple4[3][1][2]
'n'
>>> 
>>> 
>>> 
>>> binaryTree = ( (10, 20), (100, 200))
>>> 
>>> binaryTree[0]
(10, 20)
>>> binaryTree[1]
(100, 200)
>>> 
>>> 
>>> binaryTree[0][0]
10
>>> 
>>> binaryTree[1][0]
100
>>> 
>>> 
>>> 
>>> tuple4
((10, 20, 30), (100, 200), 'Good Morning!', ('Ding', 'Dong', 100, 199, (1000, 2000), 90.89))
>>> 
>>> for item in tuple4:
...     print(item)
... 
(10, 20, 30)
(100, 200)
Good Morning!
('Ding', 'Dong', 100, 199, (1000, 2000), 90.89)
>>> 
>>> 
>>> 
>>> 
>>> type(tuple4[0])
<class 'tuple'>
>>> 
>>> tuple4[0]
(10, 20, 30)
>>> 
>>> type(tuple4[0])
<class 'tuple'>
>>> 
>>> 
>>> 
>>> 
>>> hello
'Hello World!'
>>> 
>>> hello[::]
'Hello World!'
>>> 
>>> 
>>> 
>>> hello[::-1]
'!dlroW olleH'
>>> 
>>> 
>>> 
>>> hello[0: 6]
'Hello '
>>> 
>>> 
>>> hello[2: 9]
'llo Wor'
>>> 
>>> hello[ 0 : 10 : 2 ]
'HloWr'
>>> 
>>> 
>>> 
>>> hello[ : : -2 ]
'!lo le'
>>> 
>>> 
>>> numbers = (1, 2, 3, 4, 5, 6, 7, 8, 90)
>>> 
>>> numbers[0]
1
>>> numbers[1]
2
>>> numbers[2]
3
>>> numbers[-1]
90
>>> 
>>> numbers[ : : -1]
(90, 8, 7, 6, 5, 4, 3, 2, 1)
>>> 
>>> 
>>> numbers[0: 6]
(1, 2, 3, 4, 5, 6)
>>> 
>>> numbers[3 : 6]
(4, 5, 6)
>>> 
>>> numbers[ : : 2]
(1, 3, 5, 7, 90)
>>> 
>>> 
>>> point
(10, 20)
>>> 
>>> type(point)
<class 'tuple'>
>>> 
>>> numbers
(1, 2, 3, 4, 5, 6, 7, 8, 90)
>>> 
>>> type(numbers)
<class 'tuple'>
>>> 
>>> len(point)
2
>>> 
>>> len(numbers)
9
>>> 
>>> 
>>> point
(10, 20)
>>> 
>>> a, b = point
>>> 
>>> a
10
>>> b
20
>>> 
>>> a, b, c = point
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
ValueError: not enough values to unpack (expected 3, got 2)
>>> 
>>> point5 = (10, 20, 30, 40, 99)
>>> 
>>> a, b, c, d, e = point5
>>> 
>>> 
>>> a
10
>>> b
20
>>> c
30
>>> d
40
>>> e
99
>>> 
>>> a, *b = point5
>>> 
>>> a
10
>>> b
[20, 30, 40, 99]
>>> 
>>> a, *b, c  = point5
>>> 
>>> a
10
>>> b
[20, 30, 40]
>>> c
99
>>> 
>>> a, *b, c, d  = point5
>>> 
>>> a
10
>>> b
[20, 30]
>>> c
40
>>> d
99
>>> 
>>> 
>>> aa = 1000
>>> bb = 2000
>>> 
>>> bb, aa  = (aa, bb)
>>> 
>>> bb
1000
>>> aa
2000
>>> 
>>> 
>>> point
(10, 20)
>>> 
>>> a = point[0]
>>> b = point[1]
>>> 
>>> a
10
>>> b
20
>>> 
>>> a, b = point
>>> 
>>> a
10
>>> b
20
>>> 
>>> point5
(10, 20, 30, 40, 99)
>>> 
>>> a, b, c, d, e = point5
>>> 
>>> a
10
>>> b
20
>>> c
30
>>> d
40
>>> e
99
>>> 
>>> a, b, c, d = point5
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
ValueError: too many values to unpack (expected 4)
>>> 
>>> a, b, c, d, e, f = point5
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
ValueError: not enough values to unpack (expected 6, got 5)
>>> 
>>> 
>>> 
>>> a, *b = point5
>>> 
>>> a
10
>>> b
[20, 30, 40, 99]
>>> 
>>> point5
(10, 20, 30, 40, 99)
>>> 
>>> 
>>> a, *b, c = point5
>>> 
>>> a
10
>>> c
99
>>> b
[20, 30, 40]
>>> 
>>> 
>>> 
>>> 
>>> numbers
(1, 2, 3, 4, 5, 6, 7, 8, 90)
>>> 
>>> for number in numbers:
... 
  File "<stdin>", line 2
    
    ^
IndentationError: expected an indented block
>>> 
>>> for number in numbers:
...     print(number)
... 
1
2
3
4
5
6
7
8
90
>>> 
>>> 
>>> points = ( (10, 20),  (100, 200), (99, 88), (0, 0), (10, 10) )
>>> 
>>> 
>>> points
((10, 20), (100, 200), (99, 88), (0, 0), (10, 10))
>>> 
>>> type(points)
<class 'tuple'>
>>> 
>>> type(points[0])
<class 'tuple'>
>>> 
>>> type(points[2])
<class 'tuple'>
>>> 
>>> 
>>> for point in points:
...     print(point)
... 
(10, 20)
(100, 200)
(99, 88)
(0, 0)
(10, 10)
>>> 
>>> 
>>> for xCoord, yCoord in points:
...     print(xCoord)
...     print(yCoord)
... 
10
20
100
200
99
88
0
0
10
10
>>> 
>>> points
((10, 20), (100, 200), (99, 88), (0, 0), (10, 10))
>>> 
>>> 
>>> single = {10)
  File "<stdin>", line 1
    single = {10)
                ^
SyntaxError: closing parenthesis ')' does not match opening parenthesis '{'
>>> 
>>> single = (10)
>>> 
>>> single
10
>>> type(single)
<class 'int'>
>>> 
>>> single = (10,)
>>> type(single)
<class 'tuple'>
>>> 
>>> a, b  = single
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
ValueError: not enough values to unpack (expected 2, got 1)
>>> 
>>> 
>>> 
>>> for xCoordinate, yCoordinate in points:
...     print( " X Coordinate = {0} and Y Cooridnate = {1}".format(xCoordinate, yCoordinate) )
... 
 X Coordinate = 10 and Y Cooridnate = 20
 X Coordinate = 100 and Y Cooridnate = 200
 X Coordinate = 99 and Y Cooridnate = 88
 X Coordinate = 0 and Y Cooridnate = 0
 X Coordinate = 10 and Y Cooridnate = 10
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 


#_________________________________________________________________



>>> a, b, c, d, e = point5
>>> 
>>> a
10
>>> b
20
>>> c
30
>>> d
40
>>> e
99
>>> 
>>> a, b, c, d = point5
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
ValueError: too many values to unpack (expected 4)
>>> 
>>> a, b, c, d, e, f = point5
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
ValueError: not enough values to unpack (expected 6, got 5)
>>> 
>>> 
>>> 
>>> a, *b = point5
>>> 
>>> a
10
>>> b
[20, 30, 40, 99]
>>> 
>>> point5
(10, 20, 30, 40, 99)
>>> 
>>> 
>>> a, *b, c = point5
>>> 
>>> a
10
>>> c
99
>>> b
[20, 30, 40]
>>> 
>>> 
>>> 
>>> 
>>> numbers
(1, 2, 3, 4, 5, 6, 7, 8, 90)
>>> 
>>> for number in numbers:
... 
  File "<stdin>", line 2
    
    ^
IndentationError: expected an indented block
>>> 
>>> for number in numbers:
...     print(number)
... 
1
2
3
4
5
6
7
8
90
>>> 
>>> 
>>> points = ( (10, 20),  (100, 200), (99, 88), (0, 0), (10, 10) )
>>> 
>>> 
>>> points
((10, 20), (100, 200), (99, 88), (0, 0), (10, 10))
>>> 
>>> type(points)
<class 'tuple'>
>>> 
>>> type(points[0])
<class 'tuple'>
>>> 
>>> type(points[2])
<class 'tuple'>
>>> 
>>> 
>>> for point in points:
...     print(point)
... 
(10, 20)
(100, 200)
(99, 88)
(0, 0)
(10, 10)
>>> 
>>> 
>>> for xCoord, yCoord in points:
...     print(xCoord)
...     print(yCoord)
... 
10
20
100
200
99
88
0
0
10
10
>>> 
>>> points
((10, 20), (100, 200), (99, 88), (0, 0), (10, 10))
>>> 
>>> 
>>> single = {10)
  File "<stdin>", line 1
    single = {10)
                ^
SyntaxError: closing parenthesis ')' does not match opening parenthesis '{'
>>> 
>>> single = (10)
>>> 
>>> single
10
>>> type(single)
<class 'int'>
>>> 
>>> single = (10,)
>>> type(single)
<class 'tuple'>
>>> 
>>> a, b  = single
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
ValueError: not enough values to unpack (expected 2, got 1)
>>> 
>>> 
>>> 
>>> for xCoordinate, yCoordinate in points:
...     print( " X Coordinate = {0} and Y Cooridnate = {1}".format(xCoordinate, yCoordinate) )
... 
 X Coordinate = 10 and Y Cooridnate = 20
 X Coordinate = 100 and Y Cooridnate = 200
 X Coordinate = 99 and Y Cooridnate = 88
 X Coordinate = 0 and Y Cooridnate = 0
 X Coordinate = 10 and Y Cooridnate = 10
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> quit()
khoj@Universe:~/Documents/AltioStar$ 
khoj@Universe:~/Documents/AltioStar$ 
khoj@Universe:~/Documents/AltioStar$ python3
Python 3.8.10 (default, Sep 28 2021, 16:10:42) 
[GCC 9.3.0] on linux
Type "help", "copyright", "credits" or "license" for more information.
>>> 
>>> 
>>> numbersAgain = [10, 20, 30, 40, 50, 60, 70, 80, 99]
>>> numbers = (1, 2, 3, 4, 5, 6, 7, 8, 90)
>>> 
>>> type(numbersAgain)  # <class 'list'>
<class 'list'>
>>> type(numbers)       # <class 'tuple'>
<class 'tuple'>
>>> 
>>> 
>>> 
>>> for number in numbers:
...     print(number)
... 
1
2
3
4
5
6
7
8
90
>>> 
>>> for number in numbersAgain:
...     print(number)
... 
10
20
30
40
50
60
70
80
99
>>> 
>>> 
>>> 
>>> numbersAgain[0]
10
>>> 
>>> numbersAgain
[10, 20, 30, 40, 50, 60, 70, 80, 99]
>>> 
>>> numbersAgain[0]
10
>>> 
>>> numbersAgain[1]
20
>>> numbersAgain[2]
30
>>> 
>>> numbersAgain[-1]
99
>>> 
>>> numbersAgain[-2]
80
>>> 
>>> numbersAgain[ -len(numbersAgain) ]
10
>>> 
>>> numbersAgain[ len(numbersAgain) ]
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
IndexError: list index out of range
>>> numbersAgain[ len(numbersAgain) ]
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
IndexError: list index out of range
>>> 
>>> 
>>> numbersAgain[ len(numbersAgain) - 1  ]
99
>>> 
>>> 
>>> 
>>> numbersAgain[ : : -1 ]
[99, 80, 70, 60, 50, 40, 30, 20, 10]
>>> 
>>> 
>>> numbersAgain[ : : -1 ]
[99, 80, 70, 60, 50, 40, 30, 20, 10]
>>> 
>>> numbersAgain[ -1 ]
99
>>> 
>>> 
>>> numbersAgain[ 0 : 6  ]
[10, 20, 30, 40, 50, 60]
>>> 
>>> numbersAgain
[10, 20, 30, 40, 50, 60, 70, 80, 99]
>>> 
>>> numbersAgain[ 0 : 6 : 2  ]
[10, 30, 50]
>>> 
>>> 
>>> numbersAgain[ 0 : 6 : 3  ]
[10, 40]
>>> 
>>> numbersAgain[ -2 :  : -2  ]
[80, 60, 40, 20]
>>> 
>>> 
>>> 
>>> 
>>> 
>>> numbersAgain
[10, 20, 30, 40, 50, 60, 70, 80, 99]
>>> 
>>> numbers
(1, 2, 3, 4, 5, 6, 7, 8, 90)
>>> 
>>> type(numbers)
<class 'tuple'>
>>> 
>>> type(numbersAgain)
<class 'list'>
>>> 
>>> numebers[0] = 1000
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'numebers' is not defined
>>> 
>>> numebersAgain[0] = 1000
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'numebersAgain' is not defined
>>> 
>>> numbersAgain[0] = 1000
>>> 
>>> numbersAgain
[1000, 20, 30, 40, 50, 60, 70, 80, 99]
>>> 
>>> number[0] = 1000
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: 'int' object does not support item assignment
>>> 
>>> numbers
(1, 2, 3, 4, 5, 6, 7, 8, 90)
>>> 
>>> numbers[0] = 1000
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: 'tuple' object does not support item assignment
>>> 
>>> 
>>> numbersAgain
[1000, 20, 30, 40, 50, 60, 70, 80, 99]
>>> 
>>> numbersAgain[2 : 4]
[30, 40]
>>> 
>>> numbersAgain[2 : 4] = [100, 200, 300, 400, 500 ]
>>> 
>>> numbersAgain
[1000, 20, 100, 200, 300, 400, 500, 50, 60, 70, 80, 99]
>>> 
>>> 
>>> 
>>> something = ('Ding', 'Dong', 100, 199, (1000, 2000), 90.89)
>>> 
>>> greeting = 'Hello World!'
>>> 
>>> nestedList = [ numbers, numbersAgain, something, greeting ]
>>> 
>>> 
>>> nestedList
[(1, 2, 3, 4, 5, 6, 7, 8, 90), [1000, 20, 100, 200, 300, 400, 500, 50, 60, 70, 80, 99], ('Ding', 'Dong', 100, 199, (1000, 2000), 90.89), 'Hello World!']
>>> 
>>> nestedList[0]
(1, 2, 3, 4, 5, 6, 7, 8, 90)
>>> 
>>> nestedList[1]
[1000, 20, 100, 200, 300, 400, 500, 50, 60, 70, 80, 99]
>>> 
>>> nestedList[2]
('Ding', 'Dong', 100, 199, (1000, 2000), 90.89)
>>> 
>>> nestedList[3]
'Hello World!'
>>> 
>>> len(nestedList)
4
>>> 
>>> len(nestedList)
4
>>> 
>>> 
>>> nestedList[-1]
'Hello World!'
>>> 
>>> 
>>> nestedList[ : : -1 ]
['Hello World!', ('Ding', 'Dong', 100, 199, (1000, 2000), 90.89), [1000, 20, 100, 200, 300, 400, 500, 50, 60, 70, 80, 99], (1, 2, 3, 4, 5, 6, 7, 8, 90)]
>>> 
>>> 
>>> 
>>> nestedList[1][ 2 : 6 ]
[100, 200, 300, 400]
>>> 
>>> nestedList[1][ -2 : 2 ]
[]
>>> 
>>> 
>>> 
>>> nestedList[1][ 2 : -2 ]
[100, 200, 300, 400, 500, 50, 60, 70]
>>> 
>>> 
>>> 
>>> nestedList[2][1]
'Dong'
>>> 
>>> nestedList[2][1][1]
'o'
>>> 
>>> 
>>> 
>>> first, *rest = numbersAgain
>>> 
>>> 
>>> numbersAgain
[1000, 20, 100, 200, 300, 400, 500, 50, 60, 70, 80, 99]
>>> 
>>> first
1000
>>> 
>>> rest
[20, 100, 200, 300, 400, 500, 50, 60, 70, 80, 99]
>>> 
>>> first, *rest, secondLast, last  = numbersAgain
>>> 
>>> first
1000
>>> 
>>> last
99
>>> secondLast
80
>>> 
>>> rest
[20, 100, 200, 300, 400, 500, 50, 60, 70]
>>> 
>>> 
>>> 
>>> numbersAgain
[1000, 20, 100, 200, 300, 400, 500, 50, 60, 70, 80, 99]
>>> 
>>> numbersAgain += [10, 20, 20, 30]
>>> 
>>> numbersAgain
[1000, 20, 100, 200, 300, 400, 500, 50, 60, 70, 80, 99, 10, 20, 20, 30]
>>> 
>>> numbersAgan.count(20)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'numbersAgan' is not defined
>>> 
>>> numbersAgain.count(20)
3
>>> 
>>> numbersAgain.count(30)
1
>>> 
>>> numbersAgain.count(10)
1
>>> 
>>> numbersAgain.count(10)
1
>>> 
>>> numbersAgain.index(10)
12
>>> 
>>> numbersAgain.index(20)
1
>>> 
>>> numbersAgain.index(100)
2
>>> 
>>> numbersAgain.append(999)
>>> 
>>> numbersAgain
[1000, 20, 100, 200, 300, 400, 500, 50, 60, 70, 80, 99, 10, 20, 20, 30, 999]
>>> 
>>> 
>>> 
>>> numbersAgain.insert(3, 999)
>>> numbersAgain
[1000, 20, 100, 999, 200, 300, 400, 500, 50, 60, 70, 80, 99, 10, 20, 20, 30, 999]
>>> 
>>> 
>>> numbersAgain.pop()
999
>>> 
>>> numbersAgain
[1000, 20, 100, 999, 200, 300, 400, 500, 50, 60, 70, 80, 99, 10, 20, 20, 30]
>>> 
>>> numbersAgain.reverse()
>>> 
>>> 
>>> numbersAgain
[30, 20, 20, 10, 99, 80, 70, 60, 50, 500, 400, 300, 200, 999, 100, 20, 1000]
>>> 
>>> numbersAgain.sort()
>>> 
>>> numbersAgain
[10, 20, 20, 20, 30, 50, 60, 70, 80, 99, 100, 200, 300, 400, 500, 999, 1000]
>>> 
>>> help(numbersAgain.sort)

>>> 
>>> 
>>> numbersAgain(reverse=False)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: 'list' object is not callable
>>> 
>>> 
>>> numbersAgain.sort(reverse=False)
>>> 
>>> numbersAgain
[10, 20, 20, 20, 30, 50, 60, 70, 80, 99, 100, 200, 300, 400, 500, 999, 1000]
>>> 
>>> numbersAgain.sort(reverse=True)
>>> 
>>> numbersAgain
[1000, 999, 500, 400, 300, 200, 100, 99, 80, 70, 60, 50, 30, 20, 20, 20, 10]
>>> 
>>> 
>>> 
>>> oneMoreList = ["Ding", "Dong", "Ting", "Tong"]
>>> 
>>> finalList = numbersAgain + oneMoreList
>>> 
>>> finalList
[1000, 999, 500, 400, 300, 200, 100, 99, 80, 70, 60, 50, 30, 20, 20, 20, 10, 'Ding', 'Dong', 'Ting', 'Tong']
>>> 
>>> 


#___________________________________________________________________
#___________________________________________________________________
#___________________________________________________________________


Python 3.8.10 (default, Sep 28 2021, 16:10:42) 
[GCC 9.3.0] on linux
Type "help", "copyright", "credits" or "license" for more information.

>>> 
>>> 
>>> s = { 10, 20, "Ding", "Dong", 30, 20,  10}
>>> 
>>> type(s)
<class 'set'>
>>> 
>>> s
{10, 'Dong', 'Ding', 20, 30}
>>> 
>>> 
>>> {10, 'Dong', 'Ding', 20, 30}
{10, 'Dong', 'Ding', 20, 30}
>>> 
>>> setA = { 10, 20, "Ding", "Dong", 30, 20,  10}
>>> 
>>> setB = { 100, 200, "Ping", 10, 20, "Ding" }
>>> 
>>> setA.union(setB)
{100, 'Ping', 200, 'Dong', 10, 'Ding', 20, 30}
>>> 
>>> setA.intersection(setB)
{'Ding', 10, 20}
>>> 
>>> 
>>> for item in setA:
...     print(item)
... 
10
Dong
Ding
20
30
>>> 
>>> 
>>> 
>>> for item in setB:
...     print(item)
... 
100
Ping
200
10
Ding
20
>>> 
>>> setD.add("Dong")
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'setD' is not defined
>>> print(setD)  
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'setD' is not defined
>>> 
>>> setD = { 10, 20, 30, 30, "Ding"}
>>> 
>>> 
>>> len(setD)
4
>>> 
>>> dir(setD)
['__and__', '__class__', '__contains__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__gt__', '__hash__', '__iand__', '__init__', '__init_subclass__', '__ior__', '__isub__', '__iter__', '__ixor__', '__le__', '__len__', '__lt__', '__ne__', '__new__', '__or__', '__rand__', '__reduce__', '__reduce_ex__', '__repr__', '__ror__', '__rsub__', '__rxor__', '__setattr__', '__sizeof__', '__str__', '__sub__', '__subclasshook__', '__xor__', 'add', 'clear', 'copy', 'difference', 'difference_update', 'discard', 'intersection', 'intersection_update', 'isdisjoint', 'issubset', 'issuperset', 'pop', 'remove', 'symmetric_difference', 'symmetric_difference_update', 'union', 'update']
>>> 
>>> 
>>> setD.add("Dong")
>>> 
>>> setD
{10, 'Dong', 'Ding', 20, 30}
>>> 
>>> setD.remove(10)
>>> 
>>> setD
{'Dong', 'Ding', 20, 30}
>>> 
>>> 
>>> 
>>> len(setD)
4
>>> 
>>> setD
{'Dong', 'Ding', 20, 30}
>>> 
>>> 
>>> setD.pop()
'Dong'
>>> 
>>> setD.pop()
'Ding'
>>> 
>>> setD
{20, 30}
>>> 
>>> 
>>> setD.add("Dong")
>>> setD.add("Ding")
>>> print(setD)  
{'Dong', 'Ding', 20, 30}
>>> 
>>> 
>>> setD[0]
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: 'set' object is not subscriptable
>>> 
>>> setD
{'Dong', 'Ding', 20, 30}
>>> 
>>> 
>>> setD.add(99.90)
>>> 
>>> setD
{99.9, 'Dong', 'Ding', 20, 30}
>>> 
>>> 
>>> 
>>> 
>>> setD.add(90)
>>> setD.add(8989890)
>>> 
>>> setD.add("Hello World!!")
>>> 
>>> setD
{8989890, 99.9, 'Dong', 'Ding', 20, 'Hello World!!', 90, 30}
>>> 
>>> 
>>> 
>>> dir(setD)
['__and__', '__class__', '__contains__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__gt__', '__hash__', '__iand__', '__init__', '__init_subclass__', '__ior__', '__isub__', '__iter__', '__ixor__', '__le__', '__len__', '__lt__', '__ne__', '__new__', '__or__', '__rand__', '__reduce__', '__reduce_ex__', '__repr__', '__ror__', '__rsub__', '__rxor__', '__setattr__', '__sizeof__', '__str__', '__sub__', '__subclasshook__', '__xor__', 'add', 'clear', 'copy', 'difference', 'difference_update', 'discard', 'intersection', 'intersection_update', 'isdisjoint', 'issubset', 'issuperset', 'pop', 'remove', 'symmetric_difference', 'symmetric_difference_update', 'union', 'update']
>>> 
>>> 
>>> 90 in setD
True
>>> 
>>> 800 in setD
False
>>> 
>>> setA = {'Dong', 1000, 'Ding', 10, 20, 30}
>>> setB = {100, 200, 'Ding', 10, 20, 'Ping'}
>>> 
>>> setA == setB  # False
False
>>> 
>>> setC = {'Dong', 1000, 'Ding', 10, 20, 30}
>>> setA == setC   # True
True
>>> 
>>> 
>>> 
>>> frozenSetA = frozenset()
>>> 
>>> 
>>> type(frozenSetA)
<class 'frozenset'>
>>> 
>>> setA
{1000, 'Dong', 10, 'Ding', 20, 30}
>>> 
>>> frozenSetA = frozenset( setA )
>>> 
>>> 
>>> setA.__eq__(setB)
False
>>> 
>>> setA == setB # setA.__eq__(setB)
False
>>> 
>>> 
>>> frozenSet
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'frozenSet' is not defined
>>> 
>>> frozenSetA
frozenset({'Ding', 10, 20, 1000, 'Dong', 30})
>>> 
>>> dir(frozenSetA)
['__and__', '__class__', '__contains__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__ne__', '__new__', '__or__', '__rand__', '__reduce__', '__reduce_ex__', '__repr__', '__ror__', '__rsub__', '__rxor__', '__setattr__', '__sizeof__', '__str__', '__sub__', '__subclasshook__', '__xor__', 'copy', 'difference', 'intersection', 'isdisjoint', 'issubset', 'issuperset', 'symmetric_difference', 'union']
>>> 
>>> 
>>> dir(setA)
['__and__', '__class__', '__contains__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__gt__', '__hash__', '__iand__', '__init__', '__init_subclass__', '__ior__', '__isub__', '__iter__', '__ixor__', '__le__', '__len__', '__lt__', '__ne__', '__new__', '__or__', '__rand__', '__reduce__', '__reduce_ex__', '__repr__', '__ror__', '__rsub__', '__rxor__', '__setattr__', '__sizeof__', '__str__', '__sub__', '__subclasshook__', '__xor__', 'add', 'clear', 'copy', 'difference', 'difference_update', 'discard', 'intersection', 'intersection_update', 'isdisjoint', 'issubset', 'issuperset', 'pop', 'remove', 'symmetric_difference', 'symmetric_difference_update', 'union', 'update']
>>> 
>>> 
>>> 
>>> 
>>> ageNameDictionary = { 20: "Lewis Carol", 25: "Alice", 15: "Ram Singh", 40: "Gabbar Singh", 60: "Thakkur" }
>>> 
>>> ageNameDictionary
{20: 'Lewis Carol', 25: 'Alice', 15: 'Ram Singh', 40: 'Gabbar Singh', 60: 'Thakkur'}
>>> 
>>> type(ageNameDictionary)
<class 'dict'>
>>> 
>>> 
>>> ageNameDictionary[20]
'Lewis Carol'
>>> 
>>> ageNameDictionary[25]
'Alice'
>>> 
>>> ageNameDictionary[100]
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
KeyError: 100
>>> 
>>> 
>>> 
>>> ageNameDictionary.keys()
dict_keys([20, 25, 15, 40, 60])
>>> 
>>> ageNameDictionary.values()
dict_values(['Lewis Carol', 'Alice', 'Ram Singh', 'Gabbar Singh', 'Thakkur'])
>>> 
>>> ageNameDictionary.items()
dict_items([(20, 'Lewis Carol'), (25, 'Alice'), (15, 'Ram Singh'), (40, 'Gabbar Singh'), (60, 'Thakkur')])
>>> 
>>> 
>>> 
>>> for key in ageNameDictionary.keys():
...     print(key)
... 
20
25
15
40
60
>>> 
>>> for value in ageNameDictionary.values():
...     print(value)
... 
Lewis Carol
Alice
Ram Singh
Gabbar Singh
Thakkur
>>> 
>>> for item in ageNameDictionary.items():
...     print(item)
... 
(20, 'Lewis Carol')
(25, 'Alice')
(15, 'Ram Singh')
(40, 'Gabbar Singh')
(60, 'Thakkur')
>>> 
>>> 
>>> 
>>> 
>>> for key, value in ageNameDictionary.items():
...     print(key)
...     print(value)
... 
20
Lewis Carol
25
Alice
15
Ram Singh
40
Gabbar Singh
60
Thakkur
>>> 
>>> 
>>> ageNameDictionary
{20: 'Lewis Carol', 25: 'Alice', 15: 'Ram Singh', 40: 'Gabbar Singh', 60: 'Thakkur'}
>>> 
>>> ageNameDictionary[20]
'Lewis Carol'
>>> 
>>> ageNameDictionary[25]
'Alice'
>>> 
>>> 
>>> ageNameDictionary[25] = "Alice Carol"
>>> 
>>> ageNameDictionary[25]
'Alice Carol'
>>> 
>>> ageNameDictionary
{20: 'Lewis Carol', 25: 'Alice Carol', 15: 'Ram Singh', 40: 'Gabbar Singh', 60: 'Thakkur'}
>>> 
>>> 
>>> ageNameDictionary[100]
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
KeyError: 100
>>> 
>>> ageNameDictionary[100] = "Shahrukh Khan"
>>> 
>>> ageNameDictionary[100]
'Shahrukh Khan'
>>> 
>>> ageNameDictionary
{20: 'Lewis Carol', 25: 'Alice Carol', 15: 'Ram Singh', 40: 'Gabbar Singh', 60: 'Thakkur', 100: 'Shahrukh Khan'}
>>> 
>>> 
>>> 
>>> dir(ageNameDictionary)
['__class__', '__contains__', '__delattr__', '__delitem__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__reversed__', '__setattr__', '__setitem__', '__sizeof__', '__str__', '__subclasshook__', 'clear', 'copy', 'fromkeys', 'get', 'items', 'keys', 'pop', 'popitem', 'setdefault', 'update', 'values']
>>> 
>>> 
>>> 
>>> ageNameDictionary[25]
'Alice Carol'
>>> 
>>> ageNameDictionary.get(25)
'Alice Carol'
>>> 
>>> ageNameDictionary[101]
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
KeyError: 101
>>> 
>>> ageNameDictionary.get(101)
>>> 
>>> ageNameDictionary.get(101, "Unknown Name")
'Unknown Name'
>>> 
>>> ageNameDictionary.get(100, "Unknown Name")
'Shahrukh Khan'
>>> 
>>> ageNameDictionary.get(101)
>>> 
>>> ageNameDictionary.get(100)
'Shahrukh Khan'


#___________________________________________________________________

>>> 
>>> 
>>> 
>>> a = 90
>>> 
>>> type(a)
<class 'int'>
>>> 
>>> a
90
>>> 
>>> aa = 0
>>> 
>>> type(aa)
<class 'int'>
>>> 
>>> aa
0
>>> 
>>> 
>>> a = int()
>>> 
>>> type(a)
<class 'int'>
>>> 
>>> a
0
>>> 
>>> f = float()
>>> type(float)
<class 'type'>
>>> 
>>> f
0.0
>>> 
>>> s = str()
>>> type(s)
<class 'str'>
>>> 
>>> s
''
>>> 
>>> len(s)
0
>>> 
>>> t = tuple()
>>> 
>>> type(t)
<class 'tuple'>
>>> 
>>> t
()
>>> 
>>> l = list()
>>> 
>>> type(l)
<class 'list'>
>>> 
>>> l
[]
>>> 
>>> ss = set()
>>> 
>>> type(ss)
<class 'set'>
>>> 
>>> ss
set()
>>> 
>>> dd = dict()
>>> 
>>> dd
{}
>>> type(dd)
<class 'dict'>
>>> 
>>> 
>>> 
>>> a = int(100)
>>> 
>>> a 
100
>>> type(a)
<class 'int'>
>>> 
>>> a = float(100.90)
>>> 
>>> a
100.9
>>> 
>>> type(a)
<class 'float'>
>>> 
>>> f = float( a )
>>> 
>>> a = 90
>>> 
>>> type(a)
<class 'int'>
>>> 
>>> f = float( a )
>>> f
90.0
>>> type(f)
<class 'float'>
>>> 
>>> 
>>> s = str("Ding Dong")
>>> 
>>> s
'Ding Dong'
>>> 
>>> type(s)
<class 'str'>
>>> 
>>> s1 = str("12345")
>>> 
>>> a = int(s1)
>>> 
>>> a
12345
>>> 
>>> type(a)
<class 'int'>
>>> 
>>> a = int( "123AB" )
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
ValueError: invalid literal for int() with base 10: '123AB'
>>> 
>>> 
>>> b = bool()
>>> 
>>> b
False
>>> 
>>> type(b)
<class 'bool'>
>>> 
>>> 
>>> 
>>> t = (10, 20, 30, 40)
>>> 
>>> tt = tuple( t )
>>> 
>>> tt
(10, 20, 30, 40)
>>> 
>>> ss
set()
>>> s1
'12345'
>>> 
>>> greeting = "Hello!"
>>> 
>>> ttt = tuple( greeting )
>>> 
>>> ttt
('H', 'e', 'l', 'l', 'o', '!')
>>> 
>>> 
>>> for character in greeting:
...     print(character)
... 
H
e
l
l
o
!
>>> for character in greeting:
...     
... 
  File "<stdin>", line 3
    
    ^
IndentationError: expected an indented block
>>> 
>>> someTuple = tuple()
>>> 
>>> for character in greeting:
...     someTuple = someTuple + (character,)
... 
>>> someTuple
('H', 'e', 'l', 'l', 'o', '!')
>>> 
>>> 
>>> 
>>> numbers = [10, 20, 30, 40, 50]
>>> 
>>> type(numbers)
<class 'list'>
>>> 
>>> tt = tuple( numbers )
>>> 
>>> tt
(10, 20, 30, 40, 50)
>>> 
>>> type(tt)
<class 'tuple'>
>>> 
>>> 
>>> t
(10, 20, 30, 40)
>>> 
>>> l = list( t )
>>> 
>>> l
[10, 20, 30, 40]
>>> 
>>> type(l)
<class 'list'>
>>> 
>>> 
>>> ll = list( "DING DONG" )
>>> 
>>> ll
['D', 'I', 'N', 'G', ' ', 'D', 'O', 'N', 'G']
>>> 
>>> 

#___________________________________________________________________

Python 3.8.10 (default, Sep 28 2021, 16:10:42) 
[GCC 9.3.0] on linux
Type "help", "copyright", "credits" or "license" for more information.
>>> 
>>> 
>>> l = [10, 20, 30, 40, 50]
>>> 
>>> ll = l 
>>> 
>>> l
[10, 20, 30, 40, 50]
>>> 
>>> 
>>> ll
[10, 20, 30, 40, 50]
>>> 
>>> l[0] = 1000
>>> 
>>> l
[1000, 20, 30, 40, 50]
>>> 
>>> ll
[1000, 20, 30, 40, 50]
>>> 
>>> 
>>> l
[1000, 20, 30, 40, 50]
>>> 
>>> m = [100, 200. 300]

  File "<stdin>", line 1
    m = [100, 200. 300]
                   ^
SyntaxError: invalid syntax
>>> 
>>> m = [100, 200, 300]
>>> 
>>> l
[1000, 20, 30, 40, 50]
>>> 
>>> m
[100, 200, 300]
>>> 
>>> n = [l, m]
>>> 
>>> n
[[1000, 20, 30, 40, 50], [100, 200, 300]]
>>> 
>>> l[1] = 2000
>>> 
>>> l
[1000, 2000, 30, 40, 50]
>>> 
>>> m
[100, 200, 300]
>>> 
>>> n
[[1000, 2000, 30, 40, 50], [100, 200, 300]]
>>> 
>>> 
>>> 
>>> ss = { l, m }
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: unhashable type: 'list'
>>> 
>>> 
>>> 
>>> 
>>> ss = { {10, 20, 30), (100, 200), "Ding"  }
  File "<stdin>", line 1
    ss = { {10, 20, 30), (100, 200), "Ding"  }
                      ^
SyntaxError: closing parenthesis ')' does not match opening parenthesis '{'
>>> 
>>> 
>>> ss = { (10, 20, 30), (100, 200), "Ding"  }
>>> 
>>> ss
{(100, 200), 'Ding', (10, 20, 30)}
>>> 
>>> 
>>> 
>>> l
[1000, 2000, 30, 40, 50]
>>> 
>>> m
[100, 200, 300]
>>> 
>>> n
[[1000, 2000, 30, 40, 50], [100, 200, 300]]
>>> 
>>> l = [11, 22. 33]
  File "<stdin>", line 1
    l = [11, 22. 33]
                 ^
SyntaxError: invalid syntax
>>> 
>>> l = [11, 22. 33]
  File "<stdin>", line 1
    l = [11, 22. 33]
                 ^
SyntaxError: invalid syntax
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> l
[1000, 2000, 30, 40, 50]
>>> 
>>> m
[100, 200, 300]
>>> 
>>> n
[[1000, 2000, 30, 40, 50], [100, 200, 300]]
>>> 
>>> 
>>> 
>>> l = [11, 22, 33]
>>> 
>>> 
>>> 
>>> 
>>> l
[11, 22, 33]
>>> 
>>> 
>>> 
>>> nn
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'nn' is not defined
>>> 
>>> n
[[1000, 2000, 30, 40, 50], [100, 200, 300]]
>>> 
>>> 
>>> n = [l, m]
>>> 
>>> n
[[11, 22, 33], [100, 200, 300]]
>>> 
>>> n[0] = l
>>> 
>>> n
[[11, 22, 33], [100, 200, 300]]
>>> 
>>> 


#___________________________________________________________________
#___________________________________________________________________
#___________________________________________________________________
#___________________________________________________________________
#___________________________________________________________________



