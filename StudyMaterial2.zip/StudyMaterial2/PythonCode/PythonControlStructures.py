

# EXPERIMENT FOLLOWING CODE BY TYPING LINE BY LINE ON PYTHON SHELL

#   >>>>MOMENT COMPLETED, RAISE YOUR HAND!!!  <<<<<<<<<

#______________________________________________________________


#______________________________________________________________
#					if-else Construct
#______________________________________________________________


flag = True

# Body Of If-Else Block Is Identified Based On Indentation
# Use Same Number Of Tabs Or Spaces To Indent The Block

if (flag):
    print("If Block Running")
else:
    print("Else Block")

#______________________________________________________________
#					if-else Ladder Construct
#______________________________________________________________


if ( flag ):
    print("If Block Running")
elif ( 90 > 100 ):
    print("Whats Going Be Math")
elif (100 > 90):
    print("Lets Do Math Right")
else:
    print("Else Block")


#______________________________________________________________
#			Terniary Operator Equivalent In Python
#					Written As Follows
#______________________________________________________________


import sys
print(sys.platform) # 'linux2'


# Following Code-01 and Code-02 Both Are Logically Same
# Read As Follows
# offset Is 20 Value Provided Platform Starts With "win" 
# Otherwise It Is 10 Value

#Code-01
offset = 20 if sys.platform.startswith("win") else 10
print(offset) # 10

#Code-02
offset = 20
if not sys.platform.startswith("win"):
    offset = 10
print(offset) # 10


# Following Code-01 and Code-02 Both Are Logically Same
#Code-011
greeting = "Hello World!!!!"
offset = 20 if ( len(greeting) > 10 )  else 10
print(offset) # 10

#Code-021
offset = 20
if not ( len(greeting) > 10 ):
	offset = 10

print(offset) # 10

#_______________________________________________________________
# 					SOME USEFUL FUNCTIONS
#_______________________________________________________________


mathMarks 	  = [90, 80, 60, 77, 66, 78, 10, 30]
scienceMarks  = [90, 50, 60, 40, 80, 99]

marks = zip(mathMarks, scienceMarks)

type(marks) # <class 'zip'>
marks # <zip object at 0x7f2aae593800>

# Query The Data From zip Type Object
for mark in marks:
    print(mark)

# Output Will Be
# (90, 90)
# (80, 50)
# (60, 60)
# (77, 40)
# (66, 80)
# (78, 99)


r = range(0, 10) # Default Step/Stride Is 1
print(r) 		# range(0, 10)
print(type(r)) 	# <class 'range'>

# Query Range Object For Values
for item in r:
    print(item)

# Output Will Be
# 0
# 1
# 2
# 3
# 4
# 5
# 6
# 7
# 8
# 9

rr = range(4, 10) # Default Step/Stride Is 1
print(rr) # range(4, 10)

# Query Range Object For Values
for item in rr:
    print(item)

# Output Will Be
# 4
# 5
# 6
# 7
# 8
# 9


rrr = range(4, 10, 2) # Step/Stride Is 2
print(rr) 	# range(4, 10)
print(rrr)  # range(4, 10, 2)

# Query Range Object For Values
for item in rrr:
    print(item)

# Output Will Be
# 4
# 6
# 8


# list() Iterate On Range Object And Will Return List Of All Values
numbers = list( range(4, 12) )
print(numbers) # [4, 5, 6, 7, 8, 9, 10, 11]
print(type(numbers)) 		# <class 'list'>

# tuple() Iterate On Range Object And Will Return Tuple Of All Values
numbersAgain = tuple( range(4, 12) )
print(numbersAgain) # (4, 5, 6, 7, 8, 9, 10, 11)
print(type(numbersAgain)) 	# <class 'tuple'>

evenRange = range(0, 10, 2)
print(evenRange) # range(0, 10, 2)

# Querying Range Object For Values
for even in evenRange:
    print(even)

# Output Will Be
# 0
# 2
# 4
# 6
# 8


# list() Iterate On Range Object And Will Return List Of All Values
evenNumbers = list( evenRange )
print(evenNumbers) # [0, 2, 4, 6, 8]

#_______________________________________________________________
#					LIST COMPREHENSION
#_______________________________________________________________


# Code To Generate Squares Of Numbers

# Following CODE-LC11 and CODE-LC12 Are Logically Same
#CODE-LC11
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
squares = []
for nnumber in numbers:
    squares.append( number * number )

print(numbers) # [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
print(squares) # [1, 4, 9, 16, 25, 36, 49, 64, 81, 100]

#CODE-LC12
# List Compreshension
squaresAgain = [ number * number for number in numbers ]
print(squaresAgain) # [1, 4, 9, 16, 25, 36, 49, 64, 81, 100]


# Following CODE-LC21 and CODE-LC22 Are Logically Same
#CODE-LC21
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
evenSquares = []
for number in numbers:
	if ( number % 2 == 0 ):
		evenSquares.append( number * number )

#CODE-LC22
# List Comprehension
evenSquares = [ number * number for number in numbers if number % 2 == 0 ]
print(evenSquares) # [4, 16, 36, 64, 100]


#_______________________________________________________________
#				DICTIONARY COMPREHENSION
#_______________________________________________________________

# Following CODE-DC11 and CODE-DC12 Are Logically Same

#CODE-DC11
squaresDict = dict()
for number in numbers:
    squaresDict[number] = number * number

print(squaresDict) # {1: 1, 2: 4, 3: 9, 4: 16, 5: 25, 6: 36, 7: 49, 8: 64, 9: 81, 10: 100}

#CODE-DC12
# Dictionary Comprehension
squaresDictAgain = { number : number * number for number in numbers }
print(squaresDictAgain) # {1: 1, 2: 4, 3: 9, 4: 16, 5: 25, 6: 36, 7: 49, 8: 64, 9: 81, 10: 100}



#_______________________________________________________________
#				GENERATOR EXPRESSION
#_______________________________________________________________


rangeValues = range(1, 6)
rangeValues # range(1, 6)

# Querying Range Object
# It Will Yield/Give Values On Demand
for number in rangeValues:
    print(number)

# Output Will Be
# 1
# 2
# 3
# 4
# 5

# Querying Range Object
# It Will Yield/Give Values On Demand
for number in rangeValues:
    print(number * number)

# Output Will Be
# 1
# 4
# 9
# 16
# 25

# Querying Range Object
# It Will Yield/Give Values On Demand
for number in rangeValues:
    print(" For n = {0} Square = {1}".format(n, n * n) )

 # Output Will Be
 # For n = 1 Square = 1
 # For n = 2 Square = 4
 # For n = 3 Square = 9
 # For n = 4 Square = 16
 # For n = 5 Square = 25


numbers = [1, 2, 3, 4, 5]

# Generator Expression
squaresGenerator = ( number * number for number in numbers )
print(squaresGenerator) # <generator object <genexpr> at 0x7f2aad154190>

# Querying Generator Expression
# It Will Yield/Give Values On Demand
for square in squaresGenerator:
    print(square)

# Output Will Be
# 1
# 4
# 9
# 16
# 25


#_______________________________________________________________
#_______________________________________________________________


#_______________________________________________________________
#_______________________________________________________________


#_______________________________________________________________
#_______________________________________________________________


#_______________________________________________________________
#_______________________________________________________________



