
# EXPERIMENT FOLLOWING CODE BY TYPING LINE BY LINE ON PYTHON SHELL
#   >>>>>>>  MOMENT COMPLETED, RAISE YOUR HAND!!!  <<<<<<<<<

#__________________________________________________________-
#                   PYTHON TUPLES
#__________________________________________________________-

# Python Tuple Is Collection Of Ordered Data
# point is a Tuple Having Two Members 10 and 20. In Tuple Order Matters
point = (10, 20)
type(point)

point[0] # Accessing First Element
point[1] # Accessing Second Element

# Creating Tuple Of Tuples
# Tuples Can Store Heterogeneous Ordered Data
something = ( "Ding", "Dong", 100, 199, (1000, 2000), 90.89)
print(something) # ('Ding', 'Dong', 100, 199, (1000, 2000), 90.89)
len(something) #6

point # (10, 20)
len(point) # 2

something[0] # 'Ding'
something[1] # 'Dong'
something[2] # 100
something[3] # 199
something[4] # (1000, 2000)
something[5] # 90.89

something[0] # 'Ding'
something[0][0] #'D'
something[0][1] #'i'
something[0][2] # 'n'
something[4] # (1000, 2000)
something[4][0]
1000
something[4][2]
# Traceback (most recent call last):
#   File "<stdin>", line 1, in <module>
# IndexError: tuple index out of range

something[4][1] # 2000


point
(10, 20)

point[0]  #10

# Tuple Are Immutable In Nature
# You Can't Change Tuple Members
point[0] = 100
# Traceback (most recent call last):
#   File "<stdin>", line 1, in <module>
# TypeError: 'tuple' object does not support item assignment


# Strings Are Immutable In Nature
# You Can't Change String Members

greeting        # 'Hello World!'
greeting[0]     # 'H'
greeting[0] = 'K'
# Traceback (most recent call last):
#   File "<stdin>", line 1, in <module>
# TypeError: 'str' object does not support item assignment


something
('Ding', 'Dong', 100, 199, (1000, 2000), 90.89)
greeting
'Hello World!'

# String Concatenation Using + Operator
# It Will Create New String After Concatenating
greetingNew = greeting + " Asywarya!"
greetingNew  # 'Hello World! Asywarya!'

tuple1 = (10, 20, 30)
tuple2 = (100, 200)

# Tuple Concatenation Using + Operator
# It Will Create New Tuple After Concatenating
tuple3  = tuple1 + tuple2
tuple3  # (10, 20, 30, 100, 200)

tuple4 = ( tuple1, tuple2, greeting, something)
tuple4
((10, 20, 30), (100, 200), 'Hello World!', ('Ding', 'Dong', 100, 199, (1000, 2000), 90.89))

tuple4[0]
(10, 20, 30)
tuple4[1]
(100, 200)
tuple4[2]
'Hello World!'
tuple4[2][2]
'l'

tuple4[3]
('Ding', 'Dong', 100, 199, (1000, 2000), 90.89)

tuple4[3][0]
'Ding'

tuple4[3][0][1]
'i'

# Looping On Tuple
#   In Each Iteration Next Element In Tuple Is Picked
#   And Assigned To item.
for item in tuple4:
    print(item)

(10, 20, 30)
(100, 200)
# Hello World!
('Ding', 'Dong', 100, 199, (1000, 2000), 90.89)

numbers = (1, 2, 3, 4, 5, 6, 7, 8, 90)

# Using Slicing And Striding Operator
# Picking Slice From Tuple From Index 0 to 5 Both Including
numbers[0:6] # (1, 2, 3, 4, 5, 6)

# Picking Slice From Tuple From Index 3 to 5 Both Inclusive
numbers[3:6]
(4, 5, 6)

# Reading Tuple From Right To Left
# Last Element In Tuple
numbers[-1]  # 90

# Second Last Element In Tuple
numbers[-2]  # 8

# Third Last Element In Tuple
numbers[-3]  # 7

# Using Slicing And Striding Operator
#[Start : End : Steps/Stride ]
# In Following Code 
# Start Index = 0   [ Inclusive ]
# End Index = 6     [ Exclusive ]
# Steps/Stride  = 2 , i.e. Indexes Are Increased By Steps = 2
numbers[0:6:2] # (1, 3, 5)


point = (10, 20)

# Tuple Unpacking
# point Tuple Have 2 Elements. 
# These Two elements Are Unpacked On a and b Respectively
a, b = point
print(a)   # 10
print(b)    # 20

point5 = (10, 20, 30, 40, 99)

# Tuple Unpacking
# point Tuple Have 5 Elements. 
# These 5 Elements Are Unpacked On a, b, c, d and e Respectively
a, b, c, d, e = point5
print(a)    # 10
print(b)    # 20
print(c)    # 30
print(d)    # 40
print(e)    # 99


# Tuple Unpacking
# point Tuple Have 5 Elements. 
# These 5 Elements Are Unpacked On a, b Respectively
# Where a Will Get First Element and Rest All Will Be Assigned To b
a, *b = point5
print(a)  # 10
print(b)  # [20, 30, 40, 99]

# Tuple Unpacking
# point Tuple Have 5 Elements. 
# These 5 Elements Are Unpacked On a, b Respectively
# Where a Will Get First Element, c Will Get Last Element
# Rest All Will Be Assigned To b
a, *b, c = point5
print(a) # 10
print(b) # [20, 30, 40]
print(c) # 99

# Swapping Values Using Tuple Unpacking
aa = 1000
bb = 2000
bb, aa = (aa, bb)
print(bb) # 1000
print(aa) # 2000


# Looping On Tuple Of Tuples
points = ( (10, 20),  (100, 200), (99, 88), (0, 0), (10, 10) )
# In Each Iteration point Will Be Assigned Tuple Values From points Tuple
for point in points:
    print(point)

# Loop Output Will Be
# (10, 20)
# (100, 200)
# (99, 88)
# (0, 0)
# (10, 10)

# Looping On Tuple Of Tuples
# Along With Upacking Elements Of Two Elements Tuple
for xCoordinate, yCoordinate in points:
    print(xCoordinate)
    print(yCoordinate)

# Loop Output Will Be
# 10
# 20
# 100
# 200
# 99
# 88
# 0
# 0
# 10
# 10

for xCoordinate, yCoordinate in points:
    print( " X Coordinate = {0} and Y Cooridnate = {1}".format(xCoordinate, yCoordinate) )

# Loop Output Will Be
#  X Coordinate = 10 and Y Cooridnate = 20
#  X Coordinate = 100 and Y Cooridnate = 200
#  X Coordinate = 99 and Y Cooridnate = 88
#  X Coordinate = 0 and Y Cooridnate = 0
#  X Coordinate = 10 and Y Cooridnate = 10

