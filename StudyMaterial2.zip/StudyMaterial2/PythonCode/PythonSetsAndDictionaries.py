

# EXPERIMENT FOLLOWING CODE BY TYPING LINE BY LINE ON PYTHON SHELL

#   >>>>>>>  MOMENT COMPLETED, RAISE YOUR HAND!!!  <<<<<<<<<

#__________________________________________________________-
#                   PYTHON SETS
#__________________________________________________________-

# Sets In Python
# Sets In Pythhon Are Mathematical Sets
#       Order Doesn't Matters
#       Elements Should Be Unique i.e. Duplicates Are Not Allowed

s = { 10, 20, "Ding", "Dong", 30, 20,  10}
print(s)            # {'Dong', 'Ding', 10, 20, 30}
print( type(s))     # <class 'set'>

setA = { 10, 20, "Ding", "Dong", 30, 20,  10}
print(setA)         # {'Dong', 'Ding', 10, 20, 30}

setB = { 100, 200, "Ping", 10, 20, "Ding" }
print(setB)         # {100, 200, 'Ding', 10, 20, 'Ping'}

# Unions Of Two Sets SetA and SetB
setA.union(setB)    # {'Dong', 100, 200, 'Ding', 10, 20, 'Ping', 30}

# Intersections Of Two Sets SetA and SetB
setA.intersection(setB)
{'Ding', 10, 20}

# Difference Of Two Sets SetA and SetB
setA.difference(setB)     # {'Dong', 30}

# Iterating/Looping On Sets
#       Elements Order Doesn't Matter
#       i.e. You Can't Predict What Will Be Elements Order In Set
for item in setA:
    print(item)

# Looping Output Is
# Dong
# Ding
# 10
# 20
# 30

# Iterating/Looping On Sets
#       Elements Order Doesn't Matter
#       i.e. You Can't Predict What Will Be Elements Order In Set
for item in setB:
    print(item)
# Looping Output Is

# 100
# 200
# Ding
# 10
# 20
# Ping


setD = { 10, 20, 30, 30, "Ding"}

print(setD)     # {'Ding', 10, 20, 30}
len(setD)       # 4
dir(setD)       # ['__and__', '__class__', '__contains__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__gt__', '__hash__', '__iand__', '__init__', '__init_subclass__', '__ior__', '__isub__', '__iter__', '__ixor__', '__le__', '__len__', '__lt__', '__ne__', '__new__', '__or__', '__rand__', '__reduce__', '__reduce_ex__', '__repr__', '__ror__', '__rsub__', '__rxor__', '__setattr__', '__sizeof__', '__str__', '__sub__', '__subclasshook__', '__xor__', 'add', 'clear', 'copy', 'difference', 'difference_update', 'discard', 'intersection', 'intersection_update', 'isdisjoint', 'issubset', 'issuperset', 'pop', 'remove', 'symmetric_difference', 'symmetric_difference_update', 'union', 'update']

# Sets Are Mutable In Python
setD.add("Dong")
print(setD)    # {'Ding', 10, 'Dong', 20, 30}

setD.add(99.89)
print(setD)     # {99.89, 'Ding', 10, 'Dong', 20, 30}

setD.remove(10)
print(setD)         # {99.89, 'Ding', 'Dong', 20, 30}
print(setD.pop())   # 99.89


setD.pop()          # 'Ding'
setD.pop()          # 'Dong'
print(setD)         # {20, 30}

# Python Set Does't Maintain Order
#       Python Set Is A Mathematical Set
setD.add("Dong")
setD.add("Ding")
print(setD)         # {'Ding', 'Dong', 20, 30}

setD.add(99.99)
print(setD)         # {99.99, 'Ding', 'Dong', 20, 30}

# Python Set Does't Allow Duplicates
#       Python Set Is A Mathematical Set
setD.add("Dong")
print(setD)         # {99.99, 'Ding', 'Dong', 20, 30}

# Python Set Does't Support Subscript/Indexing Operator []
setD[0]
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: 'set' object is not subscriptable



setA = {'Dong', 1000, 'Ding', 10, 20, 30}
print(setA)         # {'Dong', 1000, 'Ding', 10, 20, 30}
setB = { 100, 200, "Ping", 10, 20, "Ding" }
print(setB)         # {100, 200, 'Ding', 10, 20, 'Ping'}

setC = {'Dong', 1000, 'Ding', 10, 20, 30, "Ting", "Tong", 1000 }
print(setC)  # {'Dong', 'Ting', 1000, 'Ding', 10, 'Tong', 20, 30}

setA.issubset(setC)
True

setA.issubset(setB)
False

# Two Sets Equality Test
setA = {'Dong', 1000, 'Ding', 10, 20, 30}
setB = {100, 200, 'Ding', 10, 20, 'Ping'}

setA == setB  # False

setC = {'Dong', 1000, 'Ding', 10, 20, 30}
setA == setC   # True


#__________________________________________________________-
#                 PYTHON FROZEN SETS
#__________________________________________________________-


# Python Frozen Sets Are Immutable In Nature
frozenSetA = frozenset()

# Creating A Frozen Set From A Mutable Set A
frozenSetA = frozenset( setA )
print(frozenSetA)  # frozenset({'Dong', 20, 1000, 'Ding', 10, 30})

dir(frozenSetA)   # ['__and__', '__class__', '__contains__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__ne__', '__new__', '__or__', '__rand__', '__reduce__', '__reduce_ex__', '__repr__', '__ror__', '__rsub__', '__rxor__', '__setattr__', '__sizeof__', '__str__', '__sub__', '__subclasshook__', '__xor__', 'copy', 'difference', 'intersection', 'isdisjoint', 'issubset', 'issuperset', 'symmetric_difference', 'union']


#__________________________________________________________-
#                 PYTHON DICTIONARIES
#__________________________________________________________-


#Python Dictionary: 
#      It's A Set Of Elements 
#      Where Each Element Is A Tuple With Two Elements i.e. (Key, Value)
#      Dictionary Doesn't Maintain Order 
#      Keys Are Unique In Dictionary

ageNameDictionary = { 20: "Lewis Carol", 25: "Alice", 15: "Ram Singh", 40: "Gabbar Singh", 60: "Thakkur" }

print(ageNameDictionary) # {20: 'Lewis Carol', 25: 'Alice', 15: 'Ram Singh', 40: 'Gabbar Singh', 60: 'Thakkur'}

# Quering Dictionary With Keys. 
# It Returns Value For Key If Key Exists
print(ageNameDictionary[20]) # 'Lewis Carol'
print(ageNameDictionary[40]) # 'Gabbar Singh'

# If Key Doesn't Exists In Dictionary, Than It Gives KeyError
print(ageNameDictionary[44])
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
KeyError: 44

# Getting List Of All Keys In The Dictionary
print(ageNameDictionary.keys())  # dict_keys([20, 25, 15, 40, 60])

# Getting List Of All Values In The Dictionary
print(ageNameDictionary.values())
# dict_values(['Lewis Carol', 'Alice', 'Ram Singh', 'Gabbar Singh', 'Thakkur'])

# Getting List Of All (Key, Value) Tuples In The Dictionary
print(ageNameDictionary.items())
dict_items([(20, 'Lewis Carol'), (25, 'Alice'), (15, 'Ram Singh'), (40, 'Gabbar Singh'), (60, 'Thakkur')])

# Looping On List Of Keys In Dictionary
for key in ageNameDictionary.keys():
    print(key)

# Loop Output Will Be
# 20
# 25
# 15
# 40
# 60

# Looping On List Of Values In Dictionary
for values in ageNameDictionary.values():
    print(values)

# Loop Output Will Be
# Lewis Carol
# Alice
# Ram Singh
# Gabbar Singh
# Thakkur

# Looping On List Of Tuples i.e. (Key, Value) In Dictionary
for item in ageNameDictionary.items():
    print(item)

# Loop Output Will Be
# (20, 'Lewis Carol')
# (25, 'Alice')
# (15, 'Ram Singh')
# (40, 'Gabbar Singh')
# (60, 'Thakkur')


# Looping On List Of Tuples i.e. (Key, Value) In Dictionary
# As Well As Unpacking Tuple (Key, Value) On key And value Variables
for key, value in ageNameDictionary.items():
    print(" For Key = {0} and Value = {1}".format(key, value))

# Loop Output Will Be
 # For Key = 20 and Value = Lewis Carol
 # For Key = 25 and Value = Alice
 # For Key = 15 and Value = Ram Singh
 # For Key = 40 and Value = Gabbar Singh
 # For Key = 60 and Value = Thakkur

print( type(ageNameDictionary) ) # <class 'dict'>


# If Key Already Exists
#       Than With Assignment Statement We Can Modify Key Value
# Modify Already Existing Key Value
# i.e. For Key 25 Value Is Changed From "Alice" To "Alice Thomson"
ageNameDictionary[25] = 'Alice Thomson'

print(ageNameDictionary)
# {20: 'Lewis Carol', 25: 'Alice Thomson', 15: 'Ram Singh', 40: 'Gabbar Singh', 60: 'Thakkur'}

# If Key Already DOESNOT Exists 
#       Than With Assignment Statement We Add New Key And Value
ageNameDictionary[44] = 'Sholay'

print(ageNameDictionary)
# {20: 'Lewis Carol', 25: 'Alice Thomson', 15: 'Ram Singh', 40: 'Gabbar Singh', 60: 'Thakkur', 44: 'Sholay'}

print( dir(dict) )
# ['__class__', '__contains__', '__delattr__', '__delitem__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__reversed__', '__setattr__', '__setitem__', '__sizeof__', '__str__', '__subclasshook__', 'clear', 'copy', 'fromkeys', 'get', 'items', 'keys', 'pop', 'popitem', 'setdefault', 'update', 'values']


# Can Access Key's Value 
#       Using Subscript Operator [Key] or get(Key) Function
# If Key Already Exists It Will Return Value
print( ageNameDictionary[25] )       # 'Alice Thomson'
print( ageNameDictionary.get(25))    # 'Alice Thomson'


# Can Access Key's Value 
#       Using Subscript Operator [Key] or get(Key) Function
# If Key DOESNOT Exists 
#       Using Subscript Operator [Key] Will Give KeyError
#       Using get(Key) Function Will Return None

# If Key DOESNOT Exists 
#       Using Subscript Operator [Key] Will Give KeyError
print( ageNameDictionary[50] )
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
KeyError: 50

# If Key DOESNOT Exists 
#       Using get(Key) Function Will Return None
print( ageNameDictionary.get(50) )

# If Key DOESNOT Exists 
#       Using get(Key, DefaultValue) Function Will Return DefaultValue
print( ageNameDictionary.get(50, "Unknown Value")) # 'Unknown Value'

# If Key Already Exists 
#       Using get(Key) Function Will Return Key's Value
print( ageNameDictionary.get(25, "Unknown Value"))  # 'Alice Thomson'


print( len(ageNameDictionary) _) # 6


ageNameD = { 100 : "Ram Singh", 300: "Veeru" }
ageNameDictionary + ageNameD
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: unsupported operand type(s) for +: 'dict' and 'dict'



#__________________________________________________________-
#           PYTHON OBJECT CREATION USING CONSTRUCTORS
#__________________________________________________________-



# Literal Syntax To Create a Object With Initial Value Of 90
a = 90

# Literal Syntax To Create a Object With Initial Value Of 0
aa = 0

type(a)  # <class 'int'>
type(aa) # <class 'int'>


# Creating a Object Using int() Constructor
# It will Inialise a With 0 Default Value For int Type
a = int()
type(a)     # <class 'int'>
print( a )  # 0

# Creating a Object Using float() Constructor
# It will Inialise a With 0.0 Default Value For float Type
f = float()
type(f)     # <class 'float'>
print( f ) # 0.0

# Creating a Object Using str() Constructor
# It will Inialise a With Empty String "" Default Value For str Type
s = str()
type(s) # <class 'str'>
print( s )  # ''

t = tuple()
type(t) # <class 'tuple'>
print( t ) # ()

l = list()
type(l) # <class 'list'>
print( l )  # []

ss = set()
type(ss) # <class 'set'>
print(set) # set{} 

dd = dict()
type(dd) <class 'dict'>
print(dd) # {}


# Creating a Object Using Constructors
#   It Will Create Duplicate Copy Of That Type
# int(Sequence), float(Sequence), str(Sequence), dict(Sequence), 
# set(Sequence), list(Sequence), tuple(Sequence) etc...
# It will Return Data Of Type With Elements Collected After Iteratining Sequence 
# These Constructors Can Be Used To Convert Type Of The Data

aa = int(10)
type(aa) # <class 'int'>
print(aa) # 10

ff = float(90.99)
type(float) # <class 'type'>
float(ff) # 90.99

ss = str("Ding Dong")
print(ss) # 'Ding Dong'


tt = tuple( (10, 20, 30) )
print(tt) # (10, 20, 30)

ll = list( (10, 20, 20 ) )
print(ll) # [10, 20, 20]

lll = list( [ 10, 20, 20 ] )
print(lll) # [10, 20, 20]

ttt = tuple( "Hello" )
print(ttt) # ('H', 'e', 'l', 'l', 'o')

listHellow = list( "Hello World"  )
print(listHellow) # ['H', 'e', 'l', 'l', 'o', ' ', 'W', 'o', 'r', 'l', 'd']

# Iterating/Looping On String
for character in "Hello":
    print(character)

# Output Of The Loop
# H
# e
# l
# l
# o

#__________________________________________________________-
#__________________________________________________________-
#__________________________________________________________-
#__________________________________________________________-

