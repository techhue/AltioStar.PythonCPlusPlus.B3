
>>> 
>>> 
>>> # Function With Variable Numbers Of Positional Arguments
>>> def summation( *values ):
...     result = 0
...     print( "Arguments {0} With Type {1}"
...             .format(values, type(values))) 
... 
>>>     # Iterating On Arguments Tuple
>>>     for value in values: 
  File "<stdin>", line 1
    for value in values: 
    ^
IndentationError: unexpected indent
>>>             result = result + value
  File "<stdin>", line 1
    result = result + value
    ^
IndentationError: unexpected indent
>>> 
>>>     return result
  File "<stdin>", line 1
    return result
    ^
IndentationError: unexpected indent
>>> 
>>> 
>>> 
>>> # Function With Variable Numbers Of Positional Arguments
>>> def summation( *values ):
...     result = 0
...     print( "Arguments {0} With Type {1}"
...             .format(values, type(values))) 
...             
...     # Iterating On Arguments Tuple
...     for value in values: 
...             result = result + value
... 
>>>     return result
  File "<stdin>", line 1
    return result
    ^
IndentationError: unexpected indent
>>> 
>>> 
>>> # Function With Variable Numbers Of Positional Arguments
>>> def summation( *values ):
...     result = 0
...     print( "Arguments {0} With Type {1}"
...             .format(values, type(values))) 
...     # Iterating On Arguments Tuple
...     for value in values: 
...             result = result + value
...     return result
... 
>>> 
>>> 
>>> 
>>> summation()
Arguments () With Type <class 'tuple'>
0
>>> 
>>> summation( 10, 20 )
Arguments (10, 20) With Type <class 'tuple'>
30
>>> 
>>> 
>>> 
>>> t = 10, 20, 30
>>> 
>>> t
(10, 20, 30)
>>> 
>>> type(t)
<class 'tuple'>
>>> 
>>> 
>>> 
>>> summation( 10, 20, 30, 40, 50 )
Arguments (10, 20, 30, 40, 50) With Type <class 'tuple'>
150
>>> 
>>> summation( 10, 20, 30, 40, 50, 100, 200, 400, 500)
Arguments (10, 20, 30, 40, 50, 100, 200, 400, 500) With Type <class 'tuple'>
1350
>>> 
>>> summation( (10, 20, 30, 40, 50), (100, 200, 400, 500) )
Arguments ((10, 20, 30, 40, 50), (100, 200, 400, 500)) With Type <class 'tuple'>
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
  File "<stdin>", line 7, in summation
TypeError: unsupported operand type(s) for +: 'int' and 'tuple'
>>> 
>>> 
>>> 
>>> summation( (10, 20, 30, 40, 50)  )
Arguments ((10, 20, 30, 40, 50),) With Type <class 'tuple'>
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
  File "<stdin>", line 7, in summation
TypeError: unsupported operand type(s) for +: 'int' and 'tuple'
>>> 
>>> 
>>> # Function With Variable Numbers Of Positional Arguments
>>> def variablePoistionalArguments( *values ):
...     print( "Arguments {0} With Type {1}"
...             .format(values, type(values))) 
... 
>>> variablePoistionalArguments( 10, 20, 30 )
Arguments (10, 20, 30) With Type <class 'tuple'>
>>> 
>>> 
>>> 
>>> 
>>> variablePoistionalArguments( (10, 20), 30 )
Arguments ((10, 20), 30) With Type <class 'tuple'>
>>> 
>>> 
>>> variablePoistionalArguments( (10, 20), (30, 40, 50) )
Arguments ((10, 20), (30, 40, 50)) With Type <class 'tuple'>
>>> 
>>> 
>>> variablePoistionalArguments( [30, 40, 50] )
Arguments ([30, 40, 50],) With Type <class 'tuple'>
>>> 
>>> 
>>> 
>>> variablePoistionalArguments( [30, 40, 50], (10, 20, 30) )
Arguments ([30, 40, 50], (10, 20, 30)) With Type <class 'tuple'>
>>> 
>>> 
>>> variablePoistionalArguments( [30, 40, 50], (10, 20, 30), "Ding", "Dong" )
Arguments ([30, 40, 50], (10, 20, 30), 'Ding', 'Dong') With Type <class 'tuple'>
>>> 
>>> 
>>> def mutliply( values ):
...     result = 1
...     for value in values:
...             result = result * value
...     return result
... 
>>> 
>>> numbers = [1, 2, 3]
>>> print( mutliply(numbers) )
6
>>> 
>>>  = [1, 2, 3]
  File "<stdin>", line 1
    = [1, 2, 3]
    ^
IndentationError: unexpected indent
>>> 
>>> 
>>> numbers = (1, 2, 3)
>>> print( mutliply(numbers) )
6
>>> 
>>> numbers = [10, 20, 30, 40, 50, 60]
>>> print( mutliply(numbers) )
720000000
>>> 
>>> numbers = (10, 20, 30, 40, 50, 60)
>>> print( mutliply(numbers) )
720000000
>>> 
>>> 
>>> print( mutliply(numbers, 10) )
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: mutliply() takes 1 positional argument but 2 were given
>>> 
>>> 
>>> 
>>> def functionWithKeyValueArguments(**keyValueArguments):
...     print("Arguments = {0} and Type = {1}".format(keyValueArguments, type(keyValueArguments) ))
... 
>>> 
>>> functionWithKeyValueArguments(ding = "Ding", dong = "Dong", 10: "Ram")
  File "<stdin>", line 1
    functionWithKeyValueArguments(ding = "Ding", dong = "Dong", 10: "Ram")
                                                                  ^
SyntaxError: invalid syntax
>>> 
>>> functionWithKeyValueArguments(ding = "Ding", dong = "Dong", 10 = "Ram")
  File "<stdin>", line 1
SyntaxError: expression cannot contain assignment, perhaps you meant "=="?
>>> 
>>> functionWithKeyValueArguments(first = 999)
Arguments = {'first': 999} and Type = <class 'dict'>
>>> 
>>> 
>>> functionWithKeyValueArguments(ding = "Ding")
Arguments = {'ding': 'Ding'} and Type = <class 'dict'>
>>> 
>>> functionWithKeyValueArguments(ding = "Ding", dong = "Dong")
Arguments = {'ding': 'Ding', 'dong': 'Dong'} and Type = <class 'dict'>
>>> 
>>> 
>>> functionWithKeyValueArguments(first = 10, second = 909.89, third = True)
Arguments = {'first': 10, 'second': 909.89, 'third': True} and Type = <class 'dict'>
>>> 
>>> 
>>> functionWithKeyValueArguments(ding = "Ding", dong = "Dong", ting = 6666)
Arguments = {'ding': 'Ding', 'dong': 'Dong', 'ting': 6666} and Type = <class 'dict'>
>>> 
>>> 
>>> functionWithKeyValueArguments(ding = "Ding", dong = "Dong", ting = 6666, third = true)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'true' is not defined
>>> 
>>> functionWithKeyValueArguments(ding = "Ding", dong = "Dong", ting = 6666, third = True)
Arguments = {'ding': 'Ding', 'dong': 'Dong', 'ting': 6666, 'third': True} and Type = <class 'dict'>
>>> 
>>> 
>>> def doSomething( first, second, *values , **keyValues):
...     print(" Arguments = {0} and Type = {1}".format(first, type(first) ))
...     print(" Arguments = {0} and Type = {1}".format(second, type(second) ))
...     print(" Arguments = {0} and Type = {1}".format(values, type(values) ))
...     print(" Arguments = {0} and Type = {1}".format(keyValues, type(keyValues) ))
... 
>>> 
>>> 
>>> 
>>> doSomething(10, 20)
 Arguments = 10 and Type = <class 'int'>
 Arguments = 20 and Type = <class 'int'>
 Arguments = () and Type = <class 'tuple'>
 Arguments = {} and Type = <class 'dict'>
>>> 
>>> 
>>> #doSomething(10, 20, third = 99, 90, 800, 999, 777, ding = "Ding", dong = "Dong", ting = 6666)
>>> doSomething(10, 20, third = 99)
 Arguments = 10 and Type = <class 'int'>
 Arguments = 20 and Type = <class 'int'>
 Arguments = () and Type = <class 'tuple'>
 Arguments = {'third': 99} and Type = <class 'dict'>
>>> 
>>> 
>>> 
>>> doSomething(10, 20, 90, 800, 999, 777, ding = "Ding", dong = "Dong", ting = 6666)
 Arguments = 10 and Type = <class 'int'>
 Arguments = 20 and Type = <class 'int'>
 Arguments = (90, 800, 999, 777) and Type = <class 'tuple'>
 Arguments = {'ding': 'Ding', 'dong': 'Dong', 'ting': 6666} and Type = <class 'dict'>
>>> 
>>> 
>>> def example_fun(x, y, **other):
...     print("x: {0}, y: {1}, keys in 'other': {2}".format(x, 
...           y, list(other.keys())))
...     other_total = 0
...     for k in other.keys():
...         other_total = other_total + other[k]
...         
...     print("The total of values in 'other' is {0}".format(other_total))
... 
>>> 
>>> 
>>> 
>>> example_fun(2, y="1")
x: 2, y: 1, keys in 'other': []
The total of values in 'other' is 0
>>> 
>>> example_fun(2, y="1", foo=3)
x: 2, y: 1, keys in 'other': ['foo']
The total of values in 'other' is 3
>>> 
>>> example_fun(2, y="1", foo=3, bar=4)
x: 2, y: 1, keys in 'other': ['foo', 'bar']
The total of values in 'other' is 7
>>> 
>>> 
>>> 
>>> def f(n, list1, list2):
...    n = 10            # n Is Local To Function
...    list1.append(3)   # list1 Changes Will Be Reflected Outside
...    list2 = [4, 5, 6] # list2 Changes Are Local
...    n = n + 1
... 
>>> 
>>> 
>>> x = 5
>>> y = [10, 20, 30]
>>> 
>>> z = [40, 50]
>>> 
>>> f(x, y, z)
>>> 
>>> x
5
>>> 
>>> y
[10, 20, 30, 3]
>>> 
>>> z
[40, 50]
>>> 
>>> 
>>> 
>>> 
>>> def sum(a, b):
...     return a + b
... 
>>> 
>>> sum(10, 20)
30
>>> 
>>> type(sum)
<class 'function'>
>>> 
>>> greeting = "Hello!"
>>> 
>>> geetingAgain = greeting
>>> 
>>> something = sum
>>> 
>>> type(sum)
<class 'function'>
>>> 
>>> type(something)
<class 'function'>
>>> 
>>> sum(10, 20)
30
>>> 
>>> something(10, 20)
30
>>> 
>>> def sub(a, b):
...     return a - b
... 
>>> something = sub
>>> 
>>> type(something)
<class 'function'>
>>> 
>>> type(sub)
<class 'function'>
>>> 
>>> something(40, 10)
30
>>> 
>>> def sum(a, b):
...     return a + b
... 
>>> def sub(a, b):
...     return a - b
... 
>>> def mul(a, b):
...     return a * b 
... 
>>> 
>>> 
>>> 
>>> def calculator(a, b, operation):
...     return operation(a, b)
... 
>>> 
>>> type(sum)
<class 'function'>
>>> type(sub)
<class 'function'>
>>> type(mul)
<class 'function'>
>>> 
>>> type(calculator)
<class 'function'>
>>> 
>>> result = calculator(30, 20, sum)
>>> print(result)
50
>>> 
>>> result = calculator(30, 20, sub)
>>> print(result)
10
>>> 
>>> result = calculator(30, 20, mul)
>>> print(result)
600
>>> 
>>> 
>>> 
>>> 
>>> 
>>> def chooseStep(forward):
...     # Local Function
...     #               Function Defined Inside A Function
...     def moveBackward(steps):
...             steps = steps - 1
...             return steps
...     # Local Function
...     def moveForward(steps):
...             steps = steps + 1
...             return steps
...     if(forward == True):
...             return moveForward   # Returning Function
...     else:
...             return moveB
... 
>>> 
>>> 
>>> type(sum)
<class 'function'>
>>> 
>>> print(sum)
<function sum at 0x7faaa33ed820>
>>> 
>>> sum
<function sum at 0x7faaa33ed820>
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> 
>>> def chooseStep(forward):
...     # Local Function
...     #               Function Defined Inside A Function
...     def moveBackward(steps):
...             steps = steps - 1
...             return steps
...     # Local Function
...     def moveForward(steps):
...             steps = steps + 1
...             return steps
...     if(forward == True):
...             return moveForward   # Returning Function
...     else:
...             return moveB
... 
>>> 
>>> doMagic = chooseStep(True)
>>> 
>>> type(doMagic)
<class 'function'>
>>> 
>>> 
>>> doMagic
<function chooseStep.<locals>.moveForward at 0x7faaa33eda60>
>>> 
>>> doMagic(10)
11
>>> doMagic(11)
12
>>> doMagic(12)
13
>>> 
>>> doMagic = chooseStep(False)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
  File "<stdin>", line 14, in chooseStep
NameError: name 'moveB' is not defined
>>> 
>>> doMagic = chooseStep(False)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
  File "<stdin>", line 14, in chooseStep
NameError: name 'moveB' is not defined
>>> 
>>> 
>>> 
>>> def chooseStep(forward):
...     # Local Function
...     #               Function Defined Inside A Function
...     def moveBackward(steps):
...             steps = steps - 1
...             return steps
...     # Local Function
...     def moveForward(steps):
...             steps = steps + 1
...             return steps
...     if(forward == True):
...             return moveForward   # Returning Function
...     else:
...             return moveBackward  # Returning Function
... 
>>> 
>>> doMagic = chooseStep(False)
>>> 
>>> type(doMagic)
<class 'function'>
>>> 
>>> print(doMagic)
<function chooseStep.<locals>.moveBackward at 0x7faaa33ed9d0>
>>> 
>>> 
>>> doMagic(10)
9
>>> doMagic(9)
8
>>> doMagic(8)
7
>>> 
>>> 
>>> doMagicAgain = chooseStep
>>> 
>>> doMagic = doMagicAgain(True)
>>> 
>>> doMagic
<function chooseStep.<locals>.moveForward at 0x7faaa33ed940>
>>> 
>>> doMagic = doMagicAgain(False)
>>> 
>>> doMagic
<function chooseStep.<locals>.moveBackward at 0x7faaa33ed9d0>
>>> 
>>> 

#_____________________________________________________


Python 3.8.10 (default, Sep 28 2021, 16:10:42) 
[GCC 9.3.0] on linux
Type "help", "copyright", "credits" or "license" for more information.
>>> 
>>> 
>>> 
>>> 
>>> def chooseStep(forward, changeSteps):
...     # Local Function
...     #               Function Defined Inside A Function
...     def moveBackward(steps):
...             steps = steps - changeSteps()
...             return steps
...             
...     # Local Function
...     def moveForward(steps):
...             steps = steps + changeSteps()
...             return steps
... 
>>>     if(forward == True):
  File "<stdin>", line 1
    if(forward == True):
    ^
IndentationError: unexpected indent
>>>             return moveForward   # Returning Function
  File "<stdin>", line 1
    return moveForward   # Returning Function
    ^
IndentationError: unexpected indent
>>>     else:
  File "<stdin>", line 1
    else:
    ^
IndentationError: unexpected indent
>>>             return moveBackward  # Returning Function
  File "<stdin>", line 1
    return moveBackward  # Returning Function
    ^
IndentationError: unexpected indent
>>> 
>>> 
>>> def chooseStep(forward, changeSteps):
...     # Local Function
...     #               Function Defined Inside A Function
...     def moveBackward(steps):
...             steps = steps - changeSteps()
...             return steps
...     # Local Function
...     def moveForward(steps):
...             steps = steps + changeSteps()
...             return steps
...             
...     if(forward == True):
...             return moveForward   # Returning Function
...     else:
...             return moveBackward  # Returning Function
... 
>>> 
>>> 
>>> def moveTwoSteps():
...     return 2
... 
>>> def moveThreeSteps():
...     return 3
... 
>>> def moveFiveSteps():
...     return 5
... 
>>> doMagic = chooseStep(True, moveTwoSteps)
>>> 
>>> type(doMagic)
<class 'function'>
>>> 
>>> print(doMagic)
<function chooseStep.<locals>.moveForward at 0x7f0cf135a4c0>
>>> 
>>> doMagic(10)
12
>>> doMagic(10)
12
>>> doMagic(12)
14
>>> 
>>> doMagic = chooseStep(True, movFiveSteps)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'movFiveSteps' is not defined
>>> 
>>> doMagic = chooseStep(True, moveFiveSteps)
>>> 
>>> doMagic(10)
15
>>> 
>>> doMagic(11)
16
>>> 
>>> 
>>> doMagic = chooseStep(False, moveFiveSteps)
>>> 
>>> doMagic(10)
5
>>> doMagic(5)
0
>>> 
>>> doMagic(0)
-5
>>> 
>>> 

