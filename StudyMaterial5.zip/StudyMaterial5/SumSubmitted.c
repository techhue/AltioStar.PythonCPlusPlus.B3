sum (int a, int b)
{
  uint sum = a + b;
  return sum;
}


from saloni to Everyone12:09 int

sum (int a, int b)
{
  int sum = a + b;
  return sum;
}

from Jai Prakash N to Everyone12:09 int
sum (int a, int b)
{
  int res = a + b;

  if (a > 0 && b > 0)
    {
      if ((res < a || res < b) || (res < 0))
	{
	  printf
	    ("one of the numbers is out of range or overflow flag set to 1");
	}
      else
	{
	  return res;
	}
    }


  from Kundala Prasanna to Everyone12:09 

  int sum (int a, int b)
  {
    int c;
    c = a + b;
    return c;
  }
  
  int main ()
  {
    long int a = 888888;
    long int b = 11;
    sum ();
    printf ("%d", c);
  }
  

  from Lochan Lingaraja Setty to Everyone12:11 int sum (int a, int b)
  {
    int r = a + b;
    if (a > 0 && b > 0 && r < 0)
      {
	       return -1;
      }
    else if (a < 0 && b < 0 && r > 0)
      {
	       return -1;
      }
    else
      {
	       return r;
      }
  }

  from Kaalla Madhulatha to Everyone12:12

#include<conio.h> 
#include<stdio.h> 
  int sum(long long int a, long long int b)
  { 

    return (a ^ b); 

  } 

  int main() { 
    long long int a=2453237878; long long int b=1; printf("%lld",sum(a,b)); }

    from Hemant Shettigar to Everyone12:14

#include<stdio.h> 
#include<stdlib.h> 
    long sum(long a,long b) { return a+b; } 

    int main() { long a=8888888888888; long b=2; printf("%ld",sum(a,b)); }

    from Anish Gond to Everyone12:14

#include <stdio.h> 
#include<math.h> 
#include<limits.h> 
    int sum(int a , int b) { 
      int c = a+b; 
      if( c <= INT_MAX ) { 
        return c ; 
      } else { 
        return -1; 
      } } int main () { int a , b; scanf("%d" , &a); scanf("%d" , &b); int result=sum(a,b); if(result) printf("%d" , result); else printf("Print Cann't calculated Valid Sum For Given a And b Values"); return 0; }

    from KiranKumar A to Everyone12:15

#include<stdio.h> int sum(long long int a, long long int b){ 
    return (a + b); 
  } int main() { long long int a=2453237878; long long int b=1; printf("%lld",sum(a,b)); }


    from Priyanshu Kumar Chaudhary to Everyone12:15 int sum (int a, int b)
  {
    int diff = INT_MAX - a;
    if (diff >= b)
      {
	       return (a + b);
      }
        else
      {
	       printf ("Can\'t calculate");
	exit (0);
      }
  }
  
  from Usha Uthirasamy to Everyone12:15 


  int sum (unsigned long long a, int b)
  {
    printf ("%llu \n %d", a, b);
    unsigned long long res = a + b;
    return res;
  }
  int main ()
  {
    unsigned long long a = 299792458000000000ULL;
    int b = 2;
    unsigned long long c = sum (a, b);
    printf ("%llu", c);
  }
  
  from saloni to Everyone12:15 int sum (int a, int b)
  {
    if (b > INT_MAX - a)
      {
	printf ("cant calculate valid sum");
      }
    else
      {
	return a + b;
      }
  }
}

int
main ()
{
  int x = sum (1, 2);
  printf ("%d,x); }
from shaik abdul cader soofi seyed mohamed to Everyone12:15
#include <stdio.h> 

#define INT_MINUS_MAX -2147483648 
#define INT_PLUS_MAX 2147483647 

int sum(int a,int b) { if( a<=INT_PLUS_MAX && b<=INT_PLUS_MAX) { 

    if(a>=INT_MINUS_MAX && b>=INT_MINUS_MAX) { 

      if((a+b)<=INT_PLUS_MAX && (a+b)>=INT_MINUS_MAX) {

       return a+b; 
     } else { 
      printf(" Value is out of range "); return; 
    } } } else { 
      printf(" Value is out of range "); return; } }


from Ashutosh Chavan to Everyone12:15
#include <stdio.h> int main() { 

  long int x, y, z; z = x + y; 

printf(" % ld \ n ", z); return 0; }

from Priyanshu Kumar Chaudhary to Everyone12:15
But it will work only for positive values

from Priyanshu Kumar Chaudhary to Everyone12:15

int sum(int a,int b){ int diff=INT_MAX-a; if(diff>=b){ return (a+b); }else{ printf(" Can \ 't calculate"); exit(0); } }

from Bhavani Beenaveni to Everyone12:16

int sum(int a , int b) { return a+b; } int main() { long int a= 888888; long int b= 1; printf("%d",sum(a,b)); }

from Kirti Rai to Everyone12:16
int sum(int a, int b) { if(b>INT_MAX-a) { printf("cant calculate valid sum"); } else{ return a+b;} } } int main(){ int x=sum(1,2); printf("%d,x); }

from Kamal Agarawal to Everyone12:16

int sum(int a,int b){ int c; c=a+b; 
  if((a > 0 && b > 0 && c < 0)||(a < 0 && b < 0 && c> 0)) { 
    printf("Can' t calculate valid sum for a and b "); } return c; }

from Munna kushwaha to Everyone12:16
int sum(int a ,int b){ int *result ; *result=a+b; return *result;}
from saloni to Everyone12:16
}int sum(int a, int b) { if(b>INT_MAX-a) { printf(" cant calculate valid sum "); exit(0); } else{ return a+b;} } } int main(){ int x=sum(1,2); printf(" % d, x);
}

else
{
  return a + b;
}
}
}

int
main ()
{
  int x = sum (1, 2);
  printf ("%d,x); }
from Vishal Kamble to Everyone12:16
#include<stdio.h> int sum(long int a, int b) { return a+b; } int main() { unsigned long long int a=89999999999; int b=1; unsigned long long int result = sum(a,b); printf(" % lld ",result); }
from PENUKONDA SAI JYOTHI to Everyone12:17
#include<stdio.h> #include<stdlib.h> long sum(long a,long b) { return a+b; } int main() { long a=8888888888888; long b=2; printf(" % ld ",sum(a,b)); }
from Shubha Banasihalli Jagadeesh to Everyone12:18
#include<conio.h> #include<stdio.h> int sum(long long int p, long long int q){ return (a ^ b); } int main() { long long int p=2453237878; long long int q=1; printf(" % lld ",sum(p,q)); }
from HARISH BANJARE to Everyone12:18
#include<stdio.h> int sum(long int a, int b) { return a+b; } int main() { unsigned long long int a=89999999999; int b=1; unsigned long long int result = sum(a,b); printf(" % lld ",result); }
from Padmapriya Selvam to Everyone12:18
int sum(int a, int b) {return a+b;} int main() { long int a=8888888; long int b=1; printf(" % d ", sum(a,b)); }
from Samruddhi Bhapkar to Everyone12:19
int sum(int a,int b){ int diff=INT_MAX-a; if(diff>=b){ return (a+b); }else{ printf(" Can \ 't calculate"); exit(0); } } from Bhavani Beenaveni to everyone: 12:16 PM int sum(int a , int b) { return a+b; } int main() { long int a= 123456789; long int b= 123456; printf("%ld",sum(a,b)); }
from Rama Krishna Kowsik to Everyone12:19
#include <stdio.h> int sum(int a , int b) { int c=a+b; if((a>0 && b>0 && c<0) || (a<0 && b<0 && c>0)) printf("Overflow occured"); else return c; } int main() { printf("%d",(sum(10000000000,10))); return 0; }
from RESHMA to Everyone12:19
int sum(int a,int b){int c=a+b; return c;}int main() { long int a=86767568; long int b=1;printf("%ld",c);}
from Shaik Aameena Mohammadi to Everyone12:19
#include<stdio.h> int sum(long int a, long int b) { return a + b; } int main() { long long int a=5644564498; long long int b=1; long result=sum(a,b); printf("%ld",result); }
from Kalyanam Venumadhav to Everyone12:19
#include<stdio.h> int sum(long int a, int b) { return a+b; } int main() { unsigned long long int a=89999999999; int b=1; unsigned long long int result = sum(a,b); printf("%lld",result); }
from Tabbassum Fairoz Pasha to Everyone12:19
#include<stdio.h> long sum(long a,long b) { return a+b; } int main() { long a=8888888888888; long b=2; printf("%ld",sum(a,b)); }
from Narasimha Reddy Kandukuri to Everyone12:20
#include<stdio.h> int sum(long long int a, long long int b){ return (a + b); } int main() { long long int a=1523113153; long long int b=1; printf("%lld",sum(a,b)); }
from Gopireddy tatiparthi to Everyone12:21
int sum(int a,int b){ int diff=INT_MAX-a; if(diff>=b){ return (a+b); }else{ printf("Can\'t calculate"); exit(0); } }
from CHINNA DEEPTHI to Everyone12:21
#include<stdio.h> int sum(int x, int y) { return (x+y)*1LL; } int main() { printf("%lld/n",(long long)sum(1089879877,20)); }
from Priyanka Sharma to Everyone12:21
int sum(long int a, int b) { return a+b; } int main() { unsigned long long int a=89999999999; int b=1; unsigned long long int result = sum(a,b); printf("%lld",result); }
from Yalla Lakshmi Sai Bapiraju to Everyone12:22
int sum(int a, int b) { return (a+b)*1LL; } int main() { printf("%lld/n",(long long)sum(548828252525,150)); }
from satya kanchumarthi to Everyone12:22
#include<stdio.h> int sum(long long int a, long long int b){ return (a + b); } int main() { long long int a=666688125; long long int b=1; printf("%lld",sum(a,b)); }

