

DAY 04 : ASSIGNMENTS
________________________________________________________________

1. Reading Assignments

	|-- StudyMaterial4
    
	    Reading Assignment I 							[ MUST ]
			
			The C Programming Language, 2nd Edition
				By Brian Kernigham and Dennis Ritchie
			
			Study Following Chapters
			
			1. Chapter 4 : Functions And Program Structure
			2. Chapter 5 : Pointers And Arrays
			3. Chapter 6 : Structures

			Experiment Code Examples In Book

	    Reading Assignment II 							[ MUST ]
			Thinking In C++, Volume I, 2nd Edition
				By Bruce Eckel

			Study Following Chapters
			
			1. Chapter 2: Making And Using Objects

			Experiment Code Examples In Book

2.  Experiment And Revise Code Examples
    
    |-- StudyMaterial4
	    |-- CPlusPlusCode
	    |   |-- 02.GetttingStartedC++.cpp
	    |   |-- Assignments.cpp
	    |   |-- Hello.c
	    |   |-- Hello.cpp
	    |   |-- SomeData.txt
	    |   `-- SomeDataDuplicate.txt
	    `-- References
	        `-- ThinkingInC++.V1.2E.pdf


DAY 05 : ASSIGNMENTS
________________________________________________________________

1. Reading Assignments

    |-- StudyMaterial5       

	    Reading Assignment I 							[ MUST ]
			
			The C Programming Language, 2nd Edition
				By Brian Kernigham and Dennis Ritchie
			
			Study Following Chapters
			
			1. Chapter 4 : Functions And Program Structure
			2. Chapter 5 : Pointers And Arrays
			3. Chapter 6 : Structures

			Experiment Code Examples In Book

	    Reading Assignment III 							[ MUST ]
			Thinking In C++, Volume I, 2nd Edition
				By Bruce Eckel

			Study Following Chapters
			
			1. Chapter 2: Making And Using Objects
			2. Chapter 3: The C In C++
			3. Chapter 4: Data Abstraction

			Experiment Code Examples In Book


2.  Experiment And Revise Code Examples
    
    |-- StudyMaterial5
    
		|-- 02.GetttingStartedC++.cpp
		|-- 03.CandC++AllCodeSamples.cpp
		|-- 03.CandC++Relationship.cpp
		|-- 04.DataAbstractions.cpp
		|-- Assignments.cpp
		|-- Hello.c
		|-- Hello.cpp
		|-- SomeData.txt
		|-- SomeDataDuplicate.txt
		|-- Sum.c
		|-- Sum.c~
		|-- SumSubmitted.c
		|-- WhatIsDataType.txt
		|-- commandLineArgs.cpp
		|-- printBinary.cpp
		|-- printBinary.h
		|-- require.h
		`-- wordsList.txt


DAY 06 : ASSIGNMENTS
________________________________________________________________

1. Reading Assignments

    |-- StudyMaterial6       

2.  Experiment And Revise Code Examples
    
    |-- StudyMaterial6

3.  Practice Code Examples

    |-- StudyMaterial6
    

DAY 07 : ASSIGNMENTS
________________________________________________________________

1. Reading Assignments

    |-- StudyMaterial7       

2.  Experiment And Revise Code Examples
    
    |-- StudyMaterial7

3.  Practice Code Examples

    |-- StudyMaterial7
    

DAY 08 : ASSIGNMENTS
________________________________________________________________

1. Reading Assignments

    |-- StudyMaterial8       

2.  Experiment And Revise Code Examples
    
    |-- StudyMaterial8

3.  Practice Code Examples

    |-- StudyMaterial8
    
