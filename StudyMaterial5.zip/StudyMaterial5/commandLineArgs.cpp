
#include <iostream>
#include <cstdlib>
using namespace std;

int main(int argc, char* argv[]) {
	// argc Will Contains Command Line Arguments Count
	// argv Array Will Contains Command Line Arguments

	cout << "argc Value Is : " << argc << endl;
	for(int i = 1; i < argc; i++)
		cout << argv[i] << endl;
		// cout << atoi(argv[i]) << endl;
} ///:~


