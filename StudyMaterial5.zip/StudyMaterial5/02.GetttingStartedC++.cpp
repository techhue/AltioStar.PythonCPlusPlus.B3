

// EXPERIMENT FOLLOWING CODE BY TYPING LINE BY LINE ON PYTHON SHELL

//   >>>>>>> MOMENT COMPLETED, RAISE YOUR HAND!!!  <<<<<<<<<


#include <iostream>
#include <cstdlib>
#include <string>
#include <fstream>
#include <vector>


using namespace std;

//________________________________________________________

// Declaration & definition examples
extern int i; // Declaration without definition
extern float f(float); // Function declaration

float b;  // Declaration & definition

float f(float a) {  // Definition
	return a + 1.0;
}

int i; // Definition
int h(int x) { // Declaration & definition
	return x + 1;
}

void playWithDeclaratiosAndDefinitions() {
	b = 1.0;
	i = 2;
	f(b);
	h(i);
} 

//________________________________________________________

// Function Doesn't Take Any Argument and Return Nothing
void helloWorld() {
	cout << "Hello World!!!";
}

//________________________________________________________

void playWithStream() {
	// Specifying formats with manipulators:
	cout << "a number in decimal: "
			 << dec << 15 << endl;
	cout << "in octal: " << oct << 15 << endl;
	cout << "in hex: " << hex << 15 << endl;
	cout << "a floating-point number: "
			 << 3.14159 << endl;
	cout << "non-printing char (escape): "
			 << char(27) << endl;
	cout << "non-printing char (escape): "
			 << char(65) << endl;
	cout << "non-printing char (escape): "
			 << char(97) << endl;
} ///:~


//________________________________________________________


void characterArrayConcatenation() {
	cout << "This is far too long to put on a "
		"single line but it can be broken up with "
		"no ill effects\nas long as there is no "
		"punctuation separating adjacent character "
		"arrays.\n";
} ///:~

//________________________________________________________


void  playWithTypeConversion() {
	int number;
	cout << "Enter a decimal number: ";
	cin >> number;
	
	cout << "value in octal = 0" 
			 << oct << number << endl;
	cout << "value in hex = 0x" 
			 << hex << number << endl;
	// cout << "value in bin = " 
	// 		 << bin << number << endl;

} ///:~


//________________________________________________________

// #include <cstdlib>

void playWithRunningSystemCommands() {
	system("Hello");
	system("ls");
	system("ls -l");	
} ///:~


//________________________________________________________

// #include <string>

void playWithStrings() {
	// s1 And s2 Are Declared
	string s1, s2; // Empty strings

	cout << s1 + s2 + "!" << endl;

	string s3 = "Hello, World."; // Initialized
	
	string s4("I am"); // Also initialized
	
	// Initialising s2
	s2 = "Today"; // Assigning to a string
	
	s1 = s3 + " " + s4; // Combining strings
	s1 += " 8 "; // Appending to a string
	
	cout << s1 + s2 + "!" << endl;
} ///:~

//________________________________________________________

// #include <string>
// #include <fstream>

// Copy one file to another, a line at a time

void playWithFileDuplication() {
	ifstream in("SomeData.txt"); // Open for reading
	ofstream out("SomeDataDuplicate.txt"); // Open for writing
	string s;

	while( getline( in, s )) // Discards newline char
		out << s << "\n"; // ... must add it back

} ///:~


//________________________________________________________

// #include <string>
// #include <iostream>
// #include <fstream>

void playWithReadingFileIntoString() {
	ifstream in("SomeData.txt");
	string s, line;

	while( getline(in, line) )
		s += line + "\n";
	cout << s;
} ///:~


//________________________________________________________

// #include <string>
// #include <iostream>
// #include <fstream>
// #include <vector>

void playWithReadingFileIntoVector() {
	vector<string> v;
	ifstream in("SomeData.txt");
	string line;

	while( getline(in, line) )
		v.push_back(line); // Add the line to the end
	// Add line numbers:
	for(int i = 0; i < v.size(); i++)
		cout << i << ": " << v[i] << endl;
} ///:~


//________________________________________________________

void playWithSplittingIntoWords() {
	
	vector<string> words;

	ifstream in("wordsList.txt");
	string word;

	while( in >> word )
		words.push_back(word);

	for(int i = 0; i < words.size(); i++)
		cout << words[i] << endl;
} ///:~


//________________________________________________________

void playWithVectorWithInt() {
	vector<int> v;

	for(int i = 0; i < 10; i++)
		v.push_back(i);
	
	for(int i = 0; i < v.size(); i++)
		cout << v[i] << ", ";
	
	cout << endl;
	
	for(int i = 0; i < v.size(); i++)
		v[i] = v[i] * 10; // Assignment  
	
	for(int i = 0; i < v.size(); i++)
		cout << dec << v[i] << ", ";
	
	cout << endl;
} ///:~

//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________

int main() {
	cout << "\nFunction : helloWorld" << endl ;
	helloWorld();

	cout << "\nFunction : playWithDeclaratiosAndDefinitions" << endl ;
	playWithDeclaratiosAndDefinitions();

	cout << "\nFunction : playWithStream" << endl ;
	playWithStream();

	cout << "\nFunction : characterArrayConcatenation" << endl ;
	characterArrayConcatenation();

	cout << "\nFunction : playWithTypeConversion" << endl ;
	playWithTypeConversion();

	cout << "\nFunction : playWithRunningSystemCommands" << endl ;
	playWithRunningSystemCommands();

	cout << "\nFunction : playWithStrings" << endl ;
	playWithStrings();

	cout << "\nFunction : playWithFileDuplication" << endl ;
	playWithFileDuplication();

	cout << "\nFunction : playWithReadingFileIntoString" << endl ;
	playWithReadingFileIntoString();

	cout << "\nFunction : playWithReadingFileIntoVector" << endl ;
	playWithReadingFileIntoVector();

	cout << "\nFunction : playWithSplittingIntoWords" << endl ;
	playWithSplittingIntoWords();

	cout << "\nFunction : playWithVectorWithInt" << endl ;
	playWithVectorWithInt();

	// cout << "\nFunction :" << endl ;
	// cout << "\nFunction :" << endl ;
	// cout << "\nFunction :" << endl ;
	// cout << "\nFunction :" << endl ;
	// cout << "\nFunction :" << endl ;
	// cout << "\nFunction :" << endl ;
	// cout << "\nFunction :" << endl ;
	// cout << "\nFunction :" << endl ;
	// cout << "\nFunction :" << endl ;
	// cout << "\nFunction :" << endl ;
}
