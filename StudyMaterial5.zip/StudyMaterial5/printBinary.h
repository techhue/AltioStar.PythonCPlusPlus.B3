
void printBinary(const unsigned char val);
