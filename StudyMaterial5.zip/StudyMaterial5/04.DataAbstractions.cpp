
// What Are The Things We Can Improve In Following Code?
// What All Bugs There In The Code?
// How The Memory Management Working In This Code?


// #include "CLib.h"
#include <iostream>
#include <cassert> 
#include <fstream>
#include <string>
#include "require.h"

using namespace std;


// CLib.h
// _____________________________________________________

typedef struct CStashTag {
	int size;      // Size of each space
	int quantity;  // Number of storage spaces
	int next;      // Next empty space
	// Dynamically allocated array of bytes:
	unsigned char* storage;
} CStash;

void initialize(CStash* s, int size);
void cleanup(CStash* s);
int add(CStash* s, const void* element);
void* fetch(CStash* s, int index);
int count(CStash* s);
void inflate(CStash* s, int increase);

//CLib.cpp
// _____________________________________________________

// Quantity of elements to add
// when increasing storage:

const int increment = 100;

void initialize(CStash* s, int sz) {
	s->size = sz;
	s->quantity = 0;
	s->storage = 0;
	s->next = 0;
}

int add(CStash* s, const void* element) {
	if(s->next >= s->quantity) //Enough space left?
		inflate(s, increment);
	// Copy element into storage,
	// starting at next empty space:
	int startBytes = s->next * s->size;
	unsigned char* e = (unsigned char*)element;
	for(int i = 0; i < s->size; i++)
		s->storage[startBytes + i] = e[i];
	s->next++;
	return(s->next - 1); // Index number
}

void* fetch(CStash* s, int index) {
	// Check index boundaries:
	assert(0 <= index);
	if(index >= s->next)
		return 0; // To indicate the end
	// Produce pointer to desired element:
	return &(s->storage[index * s->size]);
}

int count(CStash* s) {
	return s->next;  // Elements in CStash
}

void inflate(CStash* s, int increase) {
	assert(increase > 0);
	int newQuantity = s->quantity + increase;
	int newBytes = newQuantity * s->size;
	int oldBytes = s->quantity * s->size;
	unsigned char* b = new unsigned char[newBytes];
	for(int i = 0; i < oldBytes; i++)
		b[i] = s->storage[i]; // Copy old to new
	delete [](s->storage); // Old storage
	s->storage = b; // Point to new memory
	s->quantity = newQuantity;
}

void cleanup(CStash* s) {
	if(s->storage != 0) {
	 cout << "freeing storage" << endl;
	 delete []s->storage;
	}
} ///:~


void playWithCStashStructure() {
	// Define variables at the beginning
	// of the block, as in C:
	CStash intStash, stringStash;
	int i;
	char* cp;
	ifstream in;
	string line;
	const int bufsize = 80;
	// Now remember to initialize the variables:
	initialize(&intStash, sizeof(int));

	for(i = 0; i < 20; i++)
		add(&intStash, &i);

	for(i = 0; i < count(&intStash); i++)
		cout << "fetch(&intStash, " << i << ") = "
				 << *(int*)fetch(&intStash, i)
				 << endl;
	// Holds 80-character strings:
	initialize(&stringStash, sizeof(char)*bufsize);
	in.open("wordsList.txt");
	assert(in);
	while(getline(in, line))
		add(&stringStash, line.c_str());
	i = 0;
	while((cp = (char*)fetch(&stringStash,i++))!=0)
		cout << "fetch(&stringStash, " << i << ") = "
				 << cp << endl;
	cleanup(&intStash);
	cleanup(&stringStash);
} ///:~


//________________________________________________________
//________________________________________________________
// #include "CppLib.h"
// #include <iostream>
// #include <cassert>
// using namespace std;
// #include "CppLib.h"
// #include "../require.h"
// #include <fstream>
// #include <iostream>
// #include <string>
// using namespace std;

// C++ Structure and Classes Are Same 
// Except Structure Members Public And Class Members Are Private
//		By Default

// CppLib.h
struct Stash {
	int size;      // Size of each space
	int quantity;  // Number of storage spaces
	int next;      // Next empty space
	 // Dynamically allocated array of bytes:
	unsigned char* storage;

	// Functions!
	void initialize(int size);
	void cleanup();
	int add(const void* element);
	void* fetch(int index);
	int count();
	void inflate(int increase);
}; ///:~


// CppLib.cpp
// Quantity of elements to add
// when increasing storage:
// const int increment = 100;

void Stash::initialize(int sz) {
	size = sz;
	quantity = 0;
	storage = 0;
	next = 0;
}

int Stash::add(const void* element) {
	if(next >= quantity) // Enough space left?
		inflate(increment);
	// Copy element into storage,
	// starting at next empty space:
	int startBytes = next * size;
	unsigned char* e = (unsigned char*)element;
	for(int i = 0; i < size; i++)
		storage[startBytes + i] = e[i];
	next++;
	return(next - 1); // Index number
}

void* Stash::fetch(int index) {
	// Check index boundaries:
	assert(0 <= index);
	if(index >= next)
		return 0; // To indicate the end
	// Produce pointer to desired element:
	return &(storage[index * size]);
}

int Stash::count() {
	return next; // Number of elements in CStash
}

void Stash::inflate(int increase) {
	assert(increase > 0);
	int newQuantity = quantity + increase;
	int newBytes = newQuantity * size;
	int oldBytes = quantity * size;
	unsigned char* b = new unsigned char[newBytes];
	for(int i = 0; i < oldBytes; i++)
		b[i] = storage[i]; // Copy old to new
	delete []storage; // Old storage
	storage = b; // Point to new memory
	quantity = newQuantity;
}

void Stash::cleanup() {
	if(storage != 0) {
		cout << "freeing storage" << endl;
		delete []storage;
	}
} ///:~



void playWithStashStructure() {
	Stash intStash;
	intStash.initialize(sizeof(int));
	
	for(int i = 0; i < 20; i++)
		intStash.add(&i);
	for(int j = 0; j < intStash.count(); j++)
		cout << "intStash.fetch(" << j << ") = "
				 << *(int*)intStash.fetch(j)
				 << endl;
	// Holds 80-character strings:
	Stash stringStash;
	const int bufsize = 80;
	stringStash.initialize(sizeof(char) * bufsize);
	ifstream in("wordsList.txt");
	assure(in, "wordsList.txt");
	string line;
	while(getline(in, line))
		stringStash.add(line.c_str());
	int k = 0;
	char* cp;
	while((cp =(char*)stringStash.fetch(k++)) != 0)
		cout << "stringStash.fetch(" << k << ") = "
				 << cp << endl;
	intStash.cleanup();
	stringStash.cleanup();
} ///:~


//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________

int main() {
	cout << "\nFunction : playWithCStashStructure" << endl ;
	playWithCStashStructure();

	cout << "\nFunction : playWithStashStructure" << endl ;
	playWithStashStructure();

	// cout << "\nFunction : " << endl ;
	// cout << "\nFunction : " << endl ;
	// cout << "\nFunction : " << endl ;
	// cout << "\nFunction : " << endl ;
	// cout << "\nFunction : " << endl ;
	// cout << "\nFunction : " << endl ;
	// cout << "\nFunction : " << endl ;
	// cout << "\nFunction : " << endl ;
	// cout << "\nFunction : " << endl ;
	// cout << "\nFunction : " << endl ;
	// cout << "\nFunction : " << endl ;
	// cout << "\nFunction : " << endl ;
	// cout << "\nFunction : " << endl ;
	// cout << "\nFunction : " << endl ;
	// cout << "\nFunction : " << endl ;
	// cout << "\nFunction : " << endl ;
	// cout << "\nFunction : " << endl ;
	// cout << "\nFunction : " << endl ;
	// cout << "\nFunction : " << endl ;

}



