
#include <iostream>
#include <string>
#include <cassert>  // Contains the macro
#include <iostream>

#include "printBinary.h"

using namespace std;

//________________________________________________________


// All possible combinations of basic data types, 
// specifiers, pointers and references

void f1(char c, int i, float f, double d);

void f2(short int si, long int li, long double ld);

void f3(unsigned char uc, unsigned int ui, 
  unsigned short int usi, unsigned long int uli);

void f4(char* cp, int* ip, float* fp, double* dp);

void f5(short int* sip, long int* lip, 
  long double* ldp);

void f6(unsigned char* ucp, unsigned int* uip, 
  unsigned short int* usip, 
  unsigned long int* ulip);

void f7(char& cr, int& ir, float& fr, double& dr);

void f8(short int& sir, long int& lir, 
  long double& ldr);

void f9(unsigned char& ucr, unsigned int& uir, 
  unsigned short int& usir, 
  unsigned long int& ulir);

//________________________________________________________

// Programmers Interprets Data Representation
// int a = 65;
// printf(" %c %d %f %x", a, a, a, a );

//________________________________________________________

void playWithArrayAddresses() {
  int a[10];

  cout << "sizeof(int) = "<< sizeof(int) << endl;

  for(int i = 0; i < 10; i++)
	cout << "&a[" << i << "] = " << (long)&a[i] << endl;
} ///:~


//________________________________________________________

// #include <iostream>
// #include <string>
// using namespace std;

void initializeArray1(int a[], int size) {
  for(int i = 0; i < size; i++)
	a[i] = i * i - i;
}

void initializeArray2(int* a, int size) {
  for(int i = 0; i < size; i++)
	a[i] = i * i + i;
}

void print(int a[], string name, int size) {
	for(int i = 0; i < size; i++)
		cout << name << "[" << i << "] = "  << a[i] << endl;
}

void playWithArrayArguments() {
  int a[5], b[5];

  // Probably garbage values:
  print(a, "a", 5);
  print(b, "b", 5);
  
  // Initialize the arrays:
  initializeArray1(a, 5);
  initializeArray1(b, 5);

  print(a, "a", 5);
  print(b, "b", 5);
  
  // Notice the arrays are always modified:
  // Arrays Are Pass By Reference
  initializeArray2(a, 5);
  initializeArray2(b, 5);
  print(a, "a", 5);
  print(b, "b", 5);
} ///:~

//________________________________________________________


void playWIthArrayIdentifier() {
	int a[10];
	cout << "a = " << a << endl;
	cout << "&a[0] =" << &a[0] << endl;
} ///:~

//________________________________________________________

// #include <cassert>  // Contains the macro

void playWithAssert() {
	int i = 100;
	// assert(i != 100); // Fails
	assert(i == 100); // Fails

} ///:~

//________________________________________________________



// #include <iostream>
void printBinary(const unsigned char val) {
  for(int i = 7; i >= 0; i--)
    if(val & (1 << i))
      std::cout << "1";
    else
      std::cout << "0";
} ///:~



//________________________________________________________

// #include "printBinary.h"
// #include <iostream>

// A macro to save typing:
#define PR(STR, EXPR) \
	cout << STR; printBinary(EXPR); cout << endl;  

void playWithBinaryOperators() {
	unsigned int getval;
	unsigned char a, b;
	cout << "Enter a number between 0 and 255: ";
	cin >> getval; a = getval;
	PR("a in binary: ", a);
	cout << "Enter a number between 0 and 255: ";
	cin >> getval; b = getval;
	PR("b in binary: ", b);
	PR("a | b = ", a | b);
	PR("a & b = ", a & b);
	PR("a ^ b = ", a ^ b);
	PR("~a = ", ~a);
	PR("~b = ", ~b);
	// An interesting bit pattern:
	unsigned char c = 0x5A; 
	PR("c in binary: ", c);
	a |= c;
	PR("a |= c; a = ", a);
	b &= c;
	PR("b &= c; b = ", b);
	b ^= a;
	PR("b ^= a; b = ", b);
} ///:~

//________________________________________________________


void playWithRelationalOperators() {
	int i,j;
	cout << "Enter an integer: ";
	cin >> i;
	cout << "Enter another integer: ";
	cin >> j;
	cout << "i > j is " << (i > j) << endl;
	cout << "i < j is " << (i < j) << endl;
	cout << "i >= j is " << (i >= j) << endl;
	cout << "i <= j is " << (i <= j) << endl;
	cout << "i == j is " << (i == j) << endl;
	cout << "i != j is " << (i != j) << endl;
	cout << "i && j is " << (i && j) << endl;
	cout << "i || j is " << (i || j) << endl;
	cout << " (i < 10) && (j < 10) is "
		 << ((i < 10) && (j < 10))  << endl;
} ///:~

//________________________________________________________


void playWithVoidCasting() {
	int i = 99;
	void* vp = &i;

	// error: ‘void*’ is not a pointer-to-object type
	// cout << *vp ;

	cout << * ( (int *) vp )  << endl ;

	// Can't dereference a void pointer:
	// *vp = 3; // Compile-time error
	// Must cast back to int before dereferencing:

	*( (int*)vp ) = 3;

	int ii = * ( (int *) vp ) ;
	cout << ii << endl ;

} ///:~

//________________________________________________________


void removeHat(char cat) {
	for(char c = 'A'; c < cat; c++)
		cout << "  ";
		
	if(cat <= 'Z') {
		cout << "cat " << cat << endl;
		removeHat(cat + 1); // Recursive call
	} else
		cout << "VOOM!!!" << endl;
}

void playWithRecursion() {
	removeHat('A');
} ///:~


//________________________________________________________


void playWithASCIICodes() {
	for(int i = 0; i < 128; i = i + 1)
	if (i != 26)  // ANSI Terminal Clear screen
		cout << " value: " << i 
			 << " character: " 
			 << char(i) // Type conversion
			 << endl;
} ///:~


//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________



int main() {
	cout << "\nFunction : playWithArrayAddresses" << endl ;
	playWithArrayAddresses();

	cout << "\nFunction : playWithArrayArguments" << endl ;
	playWithArrayArguments();

	cout << "\nFunction : playWIthArrayIdentifier" << endl ;
	playWIthArrayIdentifier();

	cout << "\nFunction : playWithAssert" << endl ;
	playWithAssert();

	cout << "\nFunction : playWithBinaryOperators" << endl ;
	playWithBinaryOperators();

	cout << "\nFunction : playWithRelationalOperators" << endl ;
	playWithRelationalOperators();

	cout << "\nFunction : playWithVoidCasting" << endl ;
	playWithVoidCasting();

	cout << "\nFunction : playWithRecursion" << endl ;
	playWithRecursion();

	cout << "\nFunction : playWithASCIICodes" << endl ;
	playWithASCIICodes();

	// cout << "\nFunction : " << endl ;
	// cout << "\nFunction : " << endl ;
	// cout << "\nFunction : " << endl ;
	// cout << "\nFunction : " << endl ;
	// cout << "\nFunction : " << endl ;
	// cout << "\nFunction : " << endl ;
	// cout << "\nFunction : " << endl ;
	// cout << "\nFunction : " << endl ;
	// cout << "\nFunction : " << endl ;
	// cout << "\nFunction : " << endl ;
	// cout << "\nFunction : " << endl ;
	// cout << "\nFunction : " << endl ;
	// cout << "\nFunction : " << endl ;
	// cout << "\nFunction : " << endl ;
	// cout << "\nFunction : " << endl ;
	// cout << "\nFunction : " << endl ;
	// cout << "\nFunction : " << endl ;
	// cout << "\nFunction : " << endl ;
	// cout << "\nFunction : " << endl ;
	// cout << "\nFunction : " << endl ;
	// cout << "\nFunction : " << endl ;

}
