
#include <stdio.h>
#include <limits.h>


// Complete Following Function In C Language
// BAD CODE
int sumBad1(int a, int b) {
	return a + b;
}	

// BAD CODE
int sumBad2(int a,int b) { return (a+b) % (1000000007); }


// Write Sum Following Function In C Language
//		Which Will Return Valid Arithematic Integer Sum
// 		Or
//		Print Cann't Calculate Valid Sum For Given a And b Values

int sum(int a, int b) {

}	

// GOOD CODE	
int sumValid(signed int si_a, signed int si_b) {
	signed int sum;
	if (((si_b > 0) && (si_a > (INT_MAX - si_b))) ||
			((si_b < 0) && (si_a < (INT_MIN - si_b)))) {
			printf("Can't Calculate Sum");
	} else {
		sum = si_a + si_b;
		return sum;
	}
}


int main ()
{
	int a = 88888888;
	int b = 1;
	int result = 0;

	result = sum (a, b);
	printf (" \n Result : %d", result);

	a = 2147483647;
	b = 1;

	result = sum (a, b);
	printf (" \n Result : %d", result);
}

